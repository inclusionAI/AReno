# Dataset attribution and license

Source dataset: Databricks, Inc., **databricks-dolly-15k**,2023. This preparation uses the ModelScope mirror `AI-ModelScope/databricks-dolly-15k`, revision `40789acc12fc986e9145f87d159f19e2f1d75c6a`, original JSONL SHA256 `2df9083338b4abd6bceb5635764dab5d833b393b55759dffb0959b6fcbf794ec`.

Dataset and this transformed distribution: [Creative Commons Attribution-ShareAlike3.0 Unported](https://creativecommons.org/licenses/by-sa/3.0/legalcode). Copyright2023 Databricks, Inc. Reference passages may include Wikipedia material, copyright Wikipedia editors and contributors, under the same license. Keep attribution and share-alike terms with redistributed adaptations.

Original owner documentation: https://github.com/databrickslabs/dolly and https://www.databricks.com/blog/2023/04/12/dolly-first-open-commercially-viable-instruction-tuned-llm . ModelScope's pinned dataset card is retained at `../raw/README.md`; complete download provenance and hashes are in `../provenance.json`.

Changes made here: removed16 exact normalized full-example duplicates, removed outer field whitespace, rendered instruction/context/response headings, assigned deterministic disjoint reference-context/instruction groups to train/validation/test, and stored seed0/1/2 training orders. Examples are not token-truncated, and no model-generated data have been added. These are exploratory local splits, not an official benchmark split or a statement of article-level disjointness.
