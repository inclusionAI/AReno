# Overnight experiment snapshot

Generated 2026-10-29T17:26:39.607581+08:00. Guardian status: {'complete': 9}.
Guardian PID 1712267; alive=True; status age 0.3 seconds.

These are preregistered condition comparisons, not an ensemble or a test-set model selection. Incomplete/failed/unpaired three-seed groups receive no quality verdict. The ≤2% validation-loss target is specific to each matched data/budget/forward-backward contract.

## sft / frontier-confirm1024-selected-precision / native-backward / 1024 updates

| Condition | Qualified seeds | Mean val loss | Relative to baseline | Fixed-job test mean (seeds) | ≤2% gate |
|---|---|---:|---:|---:|---|
| adam8 | [0, 1, 2] | 2.1834 | -2.01% | — [] | PASS |
| adamw | [0, 1, 2] | 2.2280 | 0.00% | — [] | PASS |
| galore | [0, 1, 2] | 2.1773 | -2.28% | — [] | PASS |

## Per-job progress and compute

| Job | Status | Accepted updates | Val loss | Normal / refresh s | Normal / refresh allocated GiB | Normal / refresh reserved GiB | Native logp max |
|---|---|---:|---:|---:|---:|---:|---:|
| confirm1024__adamw__s0 | complete | 1024/1024 | 2.2239 | 0.4809 / — | 12.08 / — | 13.42 / — | 0.0000000 |
| confirm1024__adam8__s0 | complete | 1024/1024 | 2.1837 | 0.4660 / — | 8.45 / — | 9.84 / — | 0.0000000 |
| confirm1024__galore__s0 | complete | 1024/1024 | 2.1770 | 0.5017 / 2.8763 | 8.28 / 8.17 | 9.59 / 9.11 | 0.0000000 |
| confirm1024__adamw__s1 | complete | 1024/1024 | 2.2320 | 0.4805 / — | 12.07 / — | 13.37 / — | 0.0000000 |
| confirm1024__adam8__s1 | complete | 1024/1024 | 2.1826 | 0.4662 / — | 8.45 / — | 9.83 / — | 0.0000000 |
| confirm1024__galore__s1 | complete | 1024/1024 | 2.1776 | 0.5031 / 2.8178 | 8.28 / 8.14 | 9.60 / 8.90 | 0.0000000 |
| confirm1024__adamw__s2 | complete | 1024/1024 | 2.2282 | 0.4791 / — | 12.07 / — | 13.30 / — | 0.0000000 |
| confirm1024__adam8__s2 | complete | 1024/1024 | 2.1838 | 0.4649 / — | 8.45 / — | 9.79 / — | 0.0000000 |
| confirm1024__galore__s2 | complete | 1024/1024 | 2.1774 | 0.4980 / 2.7828 | 8.26 / 8.09 | 9.53 / 8.83 | 0.0000000 |

## Learning monitors (descriptive only)

| Job | Latest monitor update | Monitor loss | Change from initial monitor | Trailing train batch-mean | Monitor minus train | Clip fraction |
|---|---:|---:|---:|---:|---:|---:|
| confirm1024__adamw__s0 | 1024 | 2.1070 | -0.4313 | 2.0612 | 0.0458 | 1.000 |
| confirm1024__adam8__s0 | 1024 | 2.0711 | -0.4671 | 2.0310 | 0.0401 | 1.000 |
| confirm1024__galore__s0 | 1024 | 2.0617 | -0.4766 | 2.0179 | 0.0438 | 1.000 |
| confirm1024__adamw__s1 | 1024 | 2.1090 | -0.4293 | 2.0925 | 0.0164 | 1.000 |
| confirm1024__adam8__s1 | 1024 | 2.0698 | -0.4685 | 2.0489 | 0.0209 | 1.000 |
| confirm1024__galore__s1 | 1024 | 2.0605 | -0.4778 | 2.0423 | 0.0182 | 1.000 |
| confirm1024__adamw__s2 | 1024 | 2.1065 | -0.4317 | 2.0592 | 0.0473 | 1.000 |
| confirm1024__adam8__s2 | 1024 | 2.0697 | -0.4686 | 2.0267 | 0.0430 | 1.000 |
| confirm1024__galore__s2 | 1024 | 2.0597 | -0.4786 | 2.0148 | 0.0449 | 1.000 |

## Audit notes

- Native profiles use per-update sums of microbatch time and maxima of peaks. Legacy averaged metrics are accepted only for a single microbatch. Compute throughput includes actor scoring and training, excludes validation monitoring, logging, checkpointing and initialization; attempt wall time is separate.
- Refresh/normal peaks are allocator peaks, not isolated solver workspace or whole-device memory. Contaminated accepted steps are excluded from performance aggregates.
- The trailing train readout averages batch token-means. Monitor-minus-trailing-train is descriptive, not a statistically estimated generalization gap. Monitor curves never choose a winner or replace independent full-fold endpoints.
- Native CUDA backward nondeterminism remains a separate trajectory limitation. No tolerance is widened here. Three seeds do not support a multiple-comparison significance claim.
- Exactly two frozen wrapper versions are accepted as training-equivalent only after full SHA and AST checks: v2 skips the final redundant recovery checkpoint. Their checkpoint-I/O/wall times are not equivalent; unknown wrapper differences remain blocked.
