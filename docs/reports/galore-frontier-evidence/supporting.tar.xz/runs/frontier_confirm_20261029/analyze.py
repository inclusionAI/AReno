"""Reuse the reviewed strict analyzer without modifying its frozen evidence."""
import importlib.util
from pathlib import Path
source = Path(__file__).resolve().parent.parent / "overnight_20261029/analyze.py"
spec = importlib.util.spec_from_file_location("reviewed_overnight_analysis", source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
if __name__ == "__main__":
    result = module.run(Path(__file__).resolve().parent)
    print({"counts": result["status_counts"], "input_errors": result["input_errors"]}, flush=True)
