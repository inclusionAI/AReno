"""Independent paired-history, retained-checkpoint and performance endpoint audit."""

import hashlib
import json
import math
import statistics
from datetime import UTC, datetime
from pathlib import Path

import torch

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def read(path):
    return json.loads(Path(path).read_text())


def rows(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines()]


def digest(path):
    with Path(path).open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def main():
    torch.set_num_threads(4)
    torch.set_float32_matmul_precision("highest")
    states = read(HERE / "status.json")["jobs"]
    analysis = read(HERE / "analysis.json")
    assert len(states) == 9 and not analysis["input_errors"]
    assert all(state["status"] == "complete" for state in states.values())
    result = {"status": "passed", "timestamp": datetime.now(UTC).isoformat(),
              "input_errors": [], "jobs": [], "quality": {}, "paired_seeds": [],
              "retained_candidate_bases": [], "model_files_hashed": 0,
              "original_flagged_evaluations": []}
    histories, scores = {}, {}
    for key, state in states.items():
        method, seed = key.split("__")[1:]
        seed = int(seed[1:])
        assert len(state["attempts"]) == 3
        assert all(a["returncode"] == 0 for a in state["attempts"])
        assert not state["attempts"][0]["contaminated"]
        assert not state["attempts"][2]["contaminated"]
        if state["attempts"][1]["contaminated"]:
            assert key == "confirm1024__galore__s0"
            recheck = read(HERE / "acceptance/clean-eval-s0/acceptance.json")
            assert recheck["status"] == "passed" and recheck["all_three_validation_summaries_exact"]
            assert recheck["source_sha256"] == state["resolved_source_sha256"]
            result["original_flagged_evaluations"].append({
                "job": key, "original_full_state_eval_contaminated": True,
                "foreign_at_exit": state.get("foreign_at_exit"),
                "training_and_independent_weights_only_eval_uncontaminated": True,
                "idle_gpu_full_state_recheck_exact": True,
                "original_flag_preserved": True,
                "performance_scope": "flagged evaluation timing is not used for performance",
            })
        train = read(state["train_summary_file"])
        assert train["start_step"] == 0 and train["next_step"] == 1024
        history = rows(Path(state["train_summary_file"]).parent / "steps.jsonl")
        assert [r["step"] for r in history] == list(range(1024))
        assert all(r["update_optimizer_steps"] == 1 and r["logp_abs_diff_mean"] == 0 for r in history)
        full, model = read(state["eval_summary_file"]), read(state["model_eval_summary_file"])
        assert full["status"] == model["status"] == "complete"
        assert full["restored_sdk_step"] == 1023
        assert full["validation"]["examples"] == model["validation"]["examples"] == 708
        assert full["validation"]["target_tokens"] == model["validation"]["target_tokens"] == 52181
        delta = abs(full["validation"]["loss"] - model["validation"]["loss"])
        assert delta <= 1e-6
        checkpoint = Path(state["final_checkpoint"])
        audit = read(checkpoint / "optimizer-retention.json")
        for name, expected in state["checkpoint_model_sha256"].items():
            assert digest(checkpoint / name) == expected, (key, name)
            result["model_files_hashed"] += 1
        if method == "galore":
            assert audit["status"] == "retained_after_export_verification"
            assert digest(checkpoint / "training_state.pt") == audit["sha256"]
            payload = torch.load(checkpoint / "training_state.pt", mmap=True, weights_only=True, map_location="cpu")
            assert payload["global_step"] == 1024
            optimizer = payload["optimizer"]
            assert optimizer["hyperparameters"]["scale"] == 1.0
            assert optimizer["backend_policy"]["master"] == "bf16-rne-low16-packedcarry-finite-reject-v1"
            count, maximum, maximum64 = 0, 0.0, 0.0
            float32_observations = []
            for item in optimizer["state"]:
                if not item:
                    continue
                assert item["master"].dtype == torch.float32
                basis = item.get("basis")
                if basis is not None:
                    gram = basis @ basis.T if basis.shape[0] == 128 else basis.T @ basis
                    error = (gram - torch.eye(128)).abs().max().item()
                    q = basis.T if basis.shape[0] == 128 else basis
                    accurate = q.double()
                    error64 = (accurate.T @ accurate - torch.eye(128, dtype=torch.float64)).abs().max().item()
                    assert math.isfinite(error64) and error64 <= 1e-6, (key, count, error64)
                    if error > 1e-6:
                        float32_observations.append({"basis_index": count, "float32_gram_error": error,
                                                     "float64_gram_error": error64})
                    count += 1
                    maximum = max(maximum, error)
                    maximum64 = max(maximum64, error64)
            assert count == 113
            result["retained_candidate_bases"].append({"job": key, "count": count,
                "max_float32_gram_error": maximum, "max_float64_gram_error": maximum64,
                "float32_accumulation_boundary_observations": float32_observations,
                "measurement_note": "Stored FP32 bases unmodified; FP64 dot checks their geometric Gram with the same1e-6 bound. Original FP32 diagnostic and its one over-bound observation retained; no FP32 update-reference tolerance changed.",
                "state_sha256": audit["sha256"]})
        else:
            assert audit["status"] == "pruned_after_export_verification"
            assert not (checkpoint / "training_state.pt").exists()
        histories[method, seed], scores[method, seed] = history, full["validation"]["loss"]
        result["jobs"].append({"id": key, "loss": full["validation"]["loss"], "dual_reload_loss_abs_diff": delta,
                               "target_tokens": sum(r["target_tokens"] for r in history), "native_max": 0})
    for seed in range(3):
        for method in ("adam8", "galore"):
            for a, b in zip(histories["adamw", seed], histories[method, seed], strict=True):
                assert all(a[k] == b[k] for k in ("step", "sample_indices", "batch_sha256", "target_tokens"))
        result["paired_seeds"].append({"seed": seed, "matched_steps": 1024,
                                      "galore_minus_8bit_loss": scores["galore", seed] - scores["adam8", seed]})
    for method in ("adamw", "adam8", "galore"):
        values = [scores[method, seed] for seed in range(3)]
        result["quality"][method] = {"mean": statistics.mean(values), "sample_std": statistics.stdev(values), "per_seed": values}
    result["galore_vs_8bit_loss_percent"] = 100 * (result["quality"]["galore"]["mean"] / result["quality"]["adam8"]["mean"] - 1)
    baseline = ROOT / "runs/frontier_round_20261029/performance-model-owned-s2"
    selected = ROOT / "runs/frontier_round_20261029/performance-selected-s1"
    assert read(selected / "RUN_MANIFEST.json")["status"] == "complete"
    references = read(selected / "BASELINE_REFERENCES.json")
    assert digest(baseline / "RUN_MANIFEST.json") == references["manifest_sha256"]
    assert (baseline / "common.py").read_bytes() == (selected / "common.py").read_bytes()
    assert read(selected / "AST_EQUIVALENCE.json")["whole_module_ast_equal_after_exact_five_guard_metadata_normalizations"]
    performance, perf_rows = {}, {}
    for method in ("adamw", "adam8", "galore"):
        directory = (selected if method == "galore" else baseline) / "outputs" / method
        summary = read(directory / "summary.json")
        history = rows(directory / "steps.jsonl")
        assert summary["status"] == "complete" and summary["completed_updates"] == 402
        assert summary["measured_updates"] == 400 and len(history) == 402
        assert summary["native_logp_abs_diff_max"] == 0
        if method != "galore":
            for name, expected in references["methods"][method]["files"].items():
                assert digest(directory / name) == expected
        perf_rows[method] = history
        measured = summary["all"]
        performance[method] = {"allocated_gib": measured["allocated_peak_bytes"] / 2**30,
                               "reserved_gib": measured["reserved_peak_bytes"] / 2**30,
                               "score_train_ms": measured["score_plus_train_s"]["mean"] * 1000,
                               "target_tokens_per_second": measured["target_tokens_per_wall_second"]}
    for method in ("adam8", "galore"):
        for a, b in zip(perf_rows["adamw"], perf_rows[method], strict=True):
            assert all(a[k] == b[k] for k in ("step", "sample_indices", "batch_sha256", "target_tokens"))
    result["performance"] = performance
    result["selected_vs_8bit_performance"] = {
        "allocated_reduction_percent": 100 * (1 - performance["galore"]["allocated_gib"] / performance["adam8"]["allocated_gib"]),
        "step_time_increase_percent": 100 * (performance["galore"]["score_train_ms"] / performance["adam8"]["score_train_ms"] - 1),
        "throughput_change_percent": 100 * (performance["galore"]["target_tokens_per_second"] / performance["adam8"]["target_tokens_per_second"] - 1),
        "scope": "same GPU0, identical common and exact guard/metadata AST equivalence; distinct entries; one timing replicate"}
    (HERE / "COMPLETED_AUDIT.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: value for key, value in result.items() if key != "jobs"}, indent=2))


if __name__ == "__main__":
    main()
