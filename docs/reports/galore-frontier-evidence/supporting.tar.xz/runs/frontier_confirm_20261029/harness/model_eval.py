"""Independent weights-only evaluation; it never loads optimizer training state."""

from pathlib import Path
import hashlib

from common import encode, evaluate, metadata, parser, setup, trainer, write


def main():
    args = parser(__doc__).parse_args()
    log = setup(args, "model_eval")
    checkpoint = args.checkpoint_dir
    info = metadata(args)
    info["model_only"] = True
    info["model_only_entry_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    write(args.output_dir / "metadata.json", info)
    args.model = str(checkpoint)
    engine = trainer(args, resume=False)
    try:
        engine.init()
        rows, stats = encode(engine.get_tokenizer(), args, "validation")
        result = {"status": "complete", "model_only": True, "validation": evaluate(engine, rows, args.micro_batch)}
        result["validation"]["encoding"] = stats
        write(args.output_dir / "summary.json", result)
        log.info("%s", result)
    finally:
        engine.close()


if __name__ == "__main__":
    main()
