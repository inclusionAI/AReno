"""Exact entry equivalence after five explicit precision guards/metadata changes."""

import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
OLD = HERE.parent / "performance-model-owned-s2"


def expression(source):
    return ast.parse(source, mode="eval").body


def dump(node):
    return ast.dump(node, include_attributes=False)


def normalize(path, selected):
    tree = ast.parse(path.read_text())
    main = next(
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "main"
    )
    changes = []
    for node in ast.walk(main):
        if isinstance(node, ast.If) and "args.scale" in ast.unparse(node.test):
            actual_scale = 1 if selected else 2
            expected = expression(
                f"args.rank != 128 or args.gap != 200 or args.scale != {actual_scale} or args.retained"
            )
            assert dump(node.test) == dump(expected)
            assert len(node.body) == 1 and isinstance(node.body[0], ast.Expr)
            assert ast.unparse(node.body[0].value.func) == "p.error"
            assert (
                node.body[0].value.args[0].value
                == f"registered rank128/gap200/scale{actual_scale}/transport required"
            )
            changes.append("preflight_rank_gap_scale_transport_guard")
            node.test = expression(
                "args.rank != 128 or args.gap != 200 or args.scale != 2 or args.retained"
            )
            node.body[0].value.args[0] = ast.Constant(
                "registered rank128/gap200/scale2/transport required"
            )
        if (
            isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and node.targets[0].id == "expected_flag"
        ):
            expected = expression(
                '"0"' if selected else '"1" if args.optimizer == "galore" else "0"'
            )
            assert dump(node.value) == dump(expected)
            node.value = expression('"1" if args.optimizer == "galore" else "0"')
            changes.append("explicit_master_environment_guard")
        if (
            isinstance(node, ast.Assert)
            and isinstance(node.test, ast.BoolOp)
            and any(
                isinstance(child, ast.Subscript)
                and isinstance(child.value, ast.Name)
                and child.value.id == "result"
                and isinstance(child.slice, ast.Constant)
                and child.slice.value == "galore_master_bytes"
                for child in ast.walk(node.test)
            )
        ):
            expected = expression(
                'result["galore_master_bytes"] > 0 and result["optimizer_model_owned_master_enabled"] == 0'
                if selected
                else 'result["galore_master_bytes"] == 0 and result["optimizer_model_owned_master_enabled"] == 1'
            )
            assert dump(node.test) == dump(expected)
            node.test = expression(
                'result["galore_master_bytes"] == 0 and result["optimizer_model_owned_master_enabled"] == 1'
            )
            changes.append("observed_precision_policy_guard_only")
        if isinstance(node, ast.Dict):
            for index, key in enumerate(node.keys):
                if not isinstance(key, ast.Constant):
                    continue
                if key.value == "authoritative_master_policy":
                    label = (
                        "strict-fp32-master-compact-lossless"
                        if selected
                        else "native-model-dtype-rne-after-each-update"
                    )
                    expected = expression(
                        f'{label!r} if args.optimizer == "galore" else "unchanged-native-control"'
                    )
                    assert dump(node.values[index]) == dump(expected)
                    node.values[index] = expression(
                        '"native-model-dtype-rne-after-each-update" if args.optimizer == "galore" else "unchanged-native-control"'
                    )
                    changes.append("master_policy_metadata_only")
                if key.value == (
                    "all_galore_master_bytes_positive"
                    if selected
                    else "all_galore_master_bytes_zero"
                ):
                    operator = ">" if selected else "=="
                    expected = expression(
                        f'all(r.get("galore_master_bytes") {operator} 0 for r in rows) if args.optimizer == "galore" else None'
                    )
                    assert dump(node.values[index]) == dump(expected)
                    node.keys[index] = ast.Constant("all_galore_master_bytes_zero")
                    node.values[index] = expression(
                        'all(r.get("galore_master_bytes") == 0 for r in rows) if args.optimizer == "galore" else None'
                    )
                    changes.append("summary_precision_metadata_only")
    assert len(changes) == 5 and len(set(changes)) == 5
    return tree, changes


def main():
    previous, _ = normalize(OLD / "train_perf.py", False)
    selected, changes = normalize(HERE / "train_perf.py", True)
    assert dump(previous) == dump(selected), (
        "unexpected entry change outside five explicit guard/metadata regions"
    )
    common_equal = (HERE / "common.py").read_bytes() == (OLD / "common.py").read_bytes()
    assert common_equal

    def sha(path):
        return hashlib.sha256(path.read_bytes()).hexdigest()

    result = {
        "status": "pass",
        "same_execution_entry": False,
        "baseline_entry_sha256": sha(OLD / "train_perf.py"),
        "selected_entry_sha256": sha(HERE / "train_perf.py"),
        "common_byte_identical": True,
        "common_sha256": sha(HERE / "common.py"),
        "whole_module_ast_equal_after_exact_five_guard_metadata_normalizations": True,
        "whitelisted_changes": changes,
        "normalized_ast_sha256": hashlib.sha256(dump(previous).encode()).hexdigest(),
        "scope": "same training/scoring/batching/math/timing code; scale/mode guards and descriptive precision metadata intentionally differ",
    }
    (HERE / "AST_EQUIVALENCE.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
