"""CPU mocked path smoke; no training checkpoints and no CUDA calls."""

import json
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import patch

import train_perf
from areno.api import TrainSequence

HERE = Path(__file__).resolve().parent


class Engine:
    def __init__(self):
        self._ctx = SimpleNamespace(global_step=-1)
        self.closed = False

    def init(self):
        pass

    def get_tokenizer(self):
        return None

    def score_logprobs(self, role, rows, **kwargs):
        return [[-1.0] * len(x) for x in rows]

    def train(self, batch, loss_fn, mini_bs):
        self._ctx.global_step += 1
        i = self._ctx.global_step
        return dict(
            loss=1.0,
            logp_abs_diff_mean=0.0,
            update_optimizer_steps=1,
            update_refresh_any=float(i % 200 == 0),
            update_cuda_time_s=0.1,
            update_optimizer_time_s=0.02,
            update_optimizer_cpu_s=0.001,
            update_optimizer_launch_wall_s=0.002,
            update_worker_cpu_s=0.01,
            optimizer_model_owned_master_enabled=0,
            galore_master_bytes=1000,
            update_peak_allocated_bytes=100,
            update_peak_reserved_bytes=120,
        )

    def close(self):
        self.closed = True


engine = Engine()
output = HERE / "cpu-smoke"
args = [
    "train_perf.py",
    "--data-dir",
    "/mnt2/ling/areno-galore/runs/experiments/overnight_20261029_data/data",
    "--model",
    "/mnt2/ling/areno-galore/models/Qwen3-0.6B",
    "--checkpoint-dir",
    str(HERE / "NEVER_WRITE_CHECKPOINT"),
    "--output-dir",
    str(output),
    "--scale",
    "1",
]
examples = [
    TrainSequence(
        tokens=[1, 2, 3],
        prompt_len=1,
        logprobs=[],
        scalar_advantage=1.0,
        reward=0,
        eos_token_id=3,
    )
    for _ in range(5)
]
with (
    patch.object(sys, "argv", args),
    patch.object(train_perf.common, "trainer", return_value=engine),
    patch.object(
        train_perf.common, "encode", return_value=(examples, {"mocked_cpu": True})
    ),
    patch.object(
        train_perf.torch.cuda, "get_device_name", return_value="CPU_MOCK_NO_CUDA"
    ),
):
    train_perf.main()
s = json.loads((output / "summary.json").read_text())
assert (
    engine.closed
    and s["completed_updates"] == 402
    and s["measured_updates"] == 400
    and s["refresh_steps"] == [200, 400]
)
assert not (HERE / "NEVER_WRITE_CHECKPOINT").exists()
assert not list(HERE.rglob("*.pt")) and not list(HERE.rglob("*.safetensors"))
print(
    "PASS: mocked402 updates, warm2/measured400, measured refresh200/400, native0, no checkpoints or evaluation"
)
