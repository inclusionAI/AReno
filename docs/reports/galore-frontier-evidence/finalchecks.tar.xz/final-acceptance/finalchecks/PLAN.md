# Final issue #593 delivery

Scope: finish the official single-GPU GaLore acceptance and make the local PR
reviewable. User requested prioritizing the project requirements over further
8-bit performance hill climbing. Nothing is published or messaged remotely.

The prior research -> experiment -> checklist cycle is complete: all registered
structural experiments were attempted, diagnosed and retained. No new
hyperparameter sweep or change of dataset/model/quality gate is scheduled.

1. Freeze strict FP32-master r128/gap200/scale1, keep historical e1 candidate.
   Verify: final-versus-experiment valid-path bit equivalence, bidirectional
   checkpoint loading, independent FP32 reference and policy regression tests.
2. Run actual public Trainer save/restore with production gap200 and two resumed
   updates crossing refresh200. Verify canonical state, clocks, next batch,
   endpoint probes, native SFT diagnostic and one update per public call.
   This is an engineering run, excluded from the 1024-update quality budget.
3. Evaluate the already fixed nine trained endpoints on the fixed test split.
   Verify frozen inputs/scorer/source and complete row/target counts. No retuning
   from test feedback; this historical split is not an untouched holdout.
4. Run final-source CPU keyword suite and relevant CUDA reference/kernel tests;
   pinned repository formatting, lint and changed-file hooks.
5. Bundle portable raw evidence, update current/historical reports and usage,
   record acceptance matrix, local commit and patch verification.

Hardware: GPU0/CPU36-39 production resume; GPU1/CPU40-43 fixed test evaluations;
GPU2/CPU44-47 mathematical/semantic checks; GPU3/CPU52-55 repository suite.
Every CUDA process uses the shared project GPU lock; no foreign jobs stopped.
All files, environments and caches stay below /mnt2/ling. Shared environment is
frozen; no package changes. Current free disk approximately41GiB before the new
engineering checkpoint, within the existing budget.

Performance: retain the completed same-GPU 400-step comparison. It reports
GaLore slower than8-bit and the small allocated-memory advantage honestly.
Only run a bounded final-source confirmation if it resolves a real provenance
gap; no kernel redesign blocks delivery.
