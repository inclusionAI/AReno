"""BailingMoE V3 causal-LM adapter.

Targets the BailingMoeV3ForCausalLM HF family (``model_type ==
"bailing_hybrid"``). The architecture interleaves two attention flavours
and a sparse mixture-of-experts MLP:
    * Attention layers alternate between ``BailingSoftmaxAttention`` (a
      classic GQA / optional MLA-style low-rank KV pathway running on flash
      attention) and ``BailingLinearAttention`` (a chunked lightning-attention
      / seg_la recurrent linear attention with ALiBi-style slope biases). The
      pattern is governed by ``layer_group_size``: every group_size-th layer
      is softmax, all others are linear; the trailing layers always run
      softmax to anchor positions.
    * The MLP is either a dense SwiGLU (``BailingDenseMLP``) for the leading
      ``first_k_dense_replace`` layers, or a sparse ``BailingSparseMoeBlock``
      for the remainder.
    * The MoE router (``BailingGate``) uses sigmoid scoring with a learnable
      per-expert bias and SGLang-style biased grouped top-k routing: experts
      are partitioned into ``n_group`` groups, top ``topk_group`` groups win,
      then top ``num_experts_per_tok`` experts inside the winning groups
      score the token. The bias is updated online during training to balance
      load.
    * Experts are stored in ``BailingGroupedExperts`` as fused 3D weights
      (``[local_experts, out, in]``) for ``areno_grouped_linear`` /
      ``areno_moe_topk_permute`` / fused-MoE inference kernels. Expert
      parallelism is collapsed into the TP group (each rank owns
      ``num_experts / world_size`` experts) and routing uses
      ``all_reduce`` to sum back the per-rank contributions.
    * An optional ``shared_experts`` dense MLP runs unconditionally on every
      token and is added to the routed output.
    * Inference uses a separate ``_forward_fused_moe`` path that stacks the
      per-expert gate/up/down weights into contiguous w1/w2 buffers and runs
      ``areno_fused_experts``; training keeps the permute/unpermute path
      so autograd can flow through.
"""

from __future__ import annotations

import math
from collections.abc import Sequence
from pathlib import Path
from typing import Any

import torch
import torch.distributed as dist
from torch import nn
from torch.nn import functional as F

from areno.accel import (
    areno_grouped_linear,
    areno_grouped_topk_router,
    areno_linear,
    areno_moe_topk_permute,
    areno_moe_unpermute,
    areno_sigmoid,
    areno_silu,
)
from areno.accel.kda import areno_kda_chunk, areno_kda_recurrent_update
from areno.accel.ops import (
    FusedMoeConfig,
    SegLaMeta,
    areno_fused_experts,
    areno_silu_and_mul,
    chunk_lightning_attn,
    log_once,
    seg_la_fwd,
)
from areno.engine.checkpoints.common import (
    build_checkpoint_policy_plan,
    load_checkpoint_weights,
    save_checkpoint_weights,
)
from areno.engine.config import ModelConfig, _parse_dtype
from areno.engine.layers.attention_backend.infer import FlashAttnInferBackend, build_infer_attention_backend
from areno.engine.layers.attention_backend.train import build_train_attention_backend
from areno.engine.layers.linear import (
    ColumnParallelLinear,
    RowParallelLinear,
    _shard_range,
    mark_tensor_parallel_parameter,
    projection_dtype,
)
from areno.engine.layers.norm import GroupRMSNormSigmoidGate, RMSNorm
from areno.engine.layers.rotary import PartialRotaryEmbedding
from areno.engine.layers.vocab import VocabParallelEmbedding, VocabParallelLMHead
from areno.engine.parallel.collectives import (
    all_reduce,
    copy_to_tensor_parallel_region,
    gather_from_sequence_parallel_region,
    is_sequence_parallel_active,
    scatter_to_sequence_parallel_region,
    sequence_parallel_region,
)
from areno.engine.parallel.context import get_tp_context
from areno.engine.runtime.metadata import InferMeta, TrainMeta
from areno.engine.runtime.recompute import checkpoint_layer, should_checkpoint_layer
from areno.engine.runtime.routing_replay import resolve_sigmoid_routes
from areno.models._shared.dynamo_wrappers import (
    _areno_depthwise_causal_conv1d_silu_decode_no_compile,
    _areno_depthwise_causal_conv1d_silu_no_compile,
    _areno_packed_depthwise_causal_conv1d_silu_no_compile,
    _fla_causal_conv1d_no_compile,
    _require_fla_gdn,
)
from areno.models.bailing_v3.checkpoint import CHECKPOINT_SPEC
from areno.models.base import CausalLMOutput, ModelAdapter


def _recurrent_cache_slots(infer_meta: InferMeta) -> torch.Tensor:
    if infer_meta.recurrent_slots is not None:
        return infer_meta.recurrent_slots.long()
    if infer_meta.block_table is None:
        raise RuntimeError("Bailing V3 recurrent attention inference requires recurrent_slots or block_table")
    return infer_meta.block_table[:, 0].long()


class BailingDenseMLP(nn.Module):
    """Plain SwiGLU MLP used for shared experts and for the first
    ``first_k_dense_replace`` decoder layers (before MoE kicks in)."""

    def __init__(self, config: ModelConfig, intermediate_size: int):
        super().__init__()
        self.gate_proj = ColumnParallelLinear(config.hidden_size, intermediate_size, bias=False)
        self.up_proj = ColumnParallelLinear(config.hidden_size, intermediate_size, bias=False)
        self.down_proj = RowParallelLinear(intermediate_size, config.hidden_size, bias=False)
        _cast_linear_weights(self.gate_proj, config.dtype)
        _cast_linear_weights(self.up_proj, config.dtype)
        _cast_linear_weights(self.down_proj, config.dtype)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        proj_input = x.to(dtype=projection_dtype(self.gate_proj))
        gate = self.gate_proj(proj_input)
        up = self.up_proj(proj_input)
        # Fused SiLU(gate) * up kernel — same as areno_silu_and_mul but reused
        # under torch._dynamo.disable so eager and compiled paths agree.
        hidden = _areno_silu_pair_no_compile(gate, up)
        return self.down_proj(hidden)


class BailingGate(nn.Module):
    """Sigmoid-scored biased grouped top-k MoE router.

    Produces, for every token, ``top_k`` expert indices and renormalized
    routing weights. The bias is added to the per-expert logit *before* the
    group/top-k pruning step (the "noaux_tc" variant of grouped routing);
    during training the bias is updated to push load back towards balance.
    """

    def __init__(self, config: ModelConfig, routing_layer_slot: int):
        super().__init__()
        if config.score_function != "sigmoid":
            raise ValueError(f"BailingGate only supports sigmoid scoring, got {config.score_function!r}")
        if not config.moe_router_enable_expert_bias:
            raise ValueError("BailingGate requires expert bias for biased grouped topk")
        if not config.norm_topk_prob:
            raise ValueError("BailingGate requires norm_topk_prob=True")
        self.top_k = config.num_experts_per_tok
        self.num_experts = int(config.num_experts or 0)
        self.n_group = config.n_group
        self.topk_group = config.topk_group
        self.routed_scaling_factor = config.routed_scaling_factor
        self.router_dtype = config.moe_router_dtype
        self.routing_layer_slot = routing_layer_slot
        # Router projection: hidden_size -> num_experts logits. Replicated
        # across TP ranks (sequence-parallel on the input side) so every rank
        # sees identical routing decisions and accumulates the gradient via
        # all-reduce.
        self.weight = nn.Parameter(torch.empty(self.num_experts, config.hidden_size, dtype=self.router_dtype))
        mark_tensor_parallel_parameter(self.weight, False, sequence_parallel=True, tp_grad_allreduce=True)
        self.bias_update_rate = config.moe_router_bias_update_rate
        self.expert_parallel_size = 1
        # Per-step token-per-expert counter used to drive bias updates at the
        # end of an optimizer step. ``expert_bias`` is the slowly-updated
        # canonical value, ``local_expert_bias`` is the snapshot used by the
        # kernel each forward pass.
        self.register_buffer(
            "local_tokens_per_expert", torch.zeros(self.num_experts, dtype=torch.float32), persistent=False
        )
        self.register_buffer("expert_bias", torch.zeros(self.num_experts), persistent=False)
        self.register_buffer("local_expert_bias", torch.zeros(self.num_experts), persistent=False)

    @torch._dynamo.disable
    def forward(
        self, hidden_states: torch.Tensor, num_padding_tokens: int = 0
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        x = hidden_states.view(-1, hidden_states.shape[-1])
        # Promote to router_dtype (typically fp32) for numerical stability of
        # the sigmoid/top-k selection.
        logits = _areno_linear_no_compile(x.to(dtype=self.weight.dtype), self.weight)
        topk_idx, topk_weight = self._forward_grouped_topk(logits)
        topk_idx, topk_weight = resolve_sigmoid_routes(
            self.routing_layer_slot,
            logits,
            topk_idx,
            topk_weight,
        )
        if torch.is_grad_enabled():
            # Only track load when training; eval calls keep counters cold.
            routed_tokens = topk_idx[:-num_padding_tokens] if num_padding_tokens else topk_idx
            _accumulate_tokens_per_expert(self.local_tokens_per_expert, routed_tokens, self.num_experts)
        return topk_idx, topk_weight.float(), logits

    @torch._dynamo.disable
    def _forward_grouped_topk(self, logits: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        log_once("areno_grouped_topk_router", "using ARENO grouped router topk kernel")
        return _areno_grouped_topk_router_no_compile(
            logits,
            self.local_expert_bias.to(device=logits.device, dtype=torch.float32),
            self.top_k,
            self.n_group,
            self.topk_group,
        )

    @torch.no_grad()
    def finalize_expert_bias(self, tp_group, dp_group) -> None:
        """Apply the per-step bias update and reset the token counter.

        Called once per training step from the trainer. The token counts are
        summed across data-parallel replicas, then nudged towards balance
        using a signed step (``sign(mean - tokens) * rate``); finally the
        zero-mean projection keeps the bias from drifting unboundedly.
        """
        del tp_group
        tokens_per_expert = self.local_tokens_per_expert
        if dist.is_available() and dist.is_initialized():
            if dp_group is not None:
                dist.all_reduce(tokens_per_expert, op=dist.ReduceOp.SUM, group=dp_group)
        if self.bias_update_rate != 0.0:
            mean_tokens = tokens_per_expert.mean(dim=-1, keepdim=True)
            offset = mean_tokens - tokens_per_expert
            # Under-loaded experts get a positive nudge, over-loaded a negative
            # one. Re-center to mean zero to avoid drift.
            self.expert_bias.add_(torch.sign(offset) * self.bias_update_rate)
            self.expert_bias.sub_(self.expert_bias.mean())
        self.local_expert_bias.copy_(self.expert_bias)
        tokens_per_expert.zero_()


@torch._dynamo.disable
def _accumulate_tokens_per_expert(tokens_per_expert: torch.Tensor, topk_idx: torch.Tensor, num_experts: int) -> None:
    """Histogram top-k expert assignments into ``tokens_per_expert`` (in place)."""
    with torch.no_grad():
        tokens_per_expert.add_(
            torch.bincount(topk_idx.reshape(-1), minlength=num_experts).to(
                device=tokens_per_expert.device,
                dtype=tokens_per_expert.dtype,
            )
        )


class BailingSparseMoeBlock(nn.Module):
    """Sparse MoE block: router -> permute -> grouped experts -> unpermute,
    plus an optional dense shared-expert pathway.

    Training and inference take different code paths: training keeps the
    autograd-friendly permute/unpermute split, inference uses the fused
    ``areno_fused_experts`` kernel over stacked w1/w2 weight tiles.
    """

    def __init__(self, config: ModelConfig, routing_layer_slot: int):
        super().__init__()
        self.config = config
        self.num_experts = int(config.num_experts or 0)
        self.num_experts_per_tok = config.num_experts_per_tok
        self.gate = BailingGate(config, routing_layer_slot)
        self.experts = BailingGroupedExperts(config)
        # Shared experts always run (no routing decision) — their intermediate
        # size scales with ``num_shared_experts``. Output is added to the
        # routed result post-reduce.
        self.shared_experts = (
            BailingDenseMLP(config, config.moe_intermediate_size * config.num_shared_experts)
            if config.num_shared_experts is not None
            else None
        )
        # Inference-only fused weight buffers, populated by
        # ``prepare_infer_weights``. w1 stacks the (gate, up) projections per
        # expert; w2 holds the per-expert down projection.
        self.register_buffer("_infer_gate_weight", torch.empty(0), persistent=False)
        self.register_buffer("_infer_up_weight", torch.empty(0), persistent=False)
        self.register_buffer("_infer_down_weight", torch.empty(0), persistent=False)
        self.register_buffer("_infer_w1_weight", torch.empty(0), persistent=False)
        self.register_buffer("_infer_w2_weight", torch.empty(0), persistent=False)
        self._infer_weights_ready = False
        self._fused_moe_config = FusedMoeConfig(
            num_experts=self.experts.local_num_experts,
            hidden_size=self.config.hidden_size,
            intermediate_size=self.config.moe_intermediate_size,
            top_k=self.num_experts_per_tok,
            routed_scaling_factor=self.config.routed_scaling_factor,
        )

    def route(self, hidden_states: torch.Tensor, num_padding_tokens: int = 0) -> tuple[torch.Tensor, torch.Tensor]:
        """Compute routing once so activation recompute can reuse it."""

        if is_sequence_parallel_active():
            hidden_states = gather_from_sequence_parallel_region(hidden_states)
        with sequence_parallel_region(False):
            topk_idx, topk_weight, _ = self.gate(hidden_states, num_padding_tokens)
        return topk_idx, topk_weight

    def forward_with_routes(
        self,
        hidden_states: torch.Tensor,
        topk_idx: torch.Tensor,
        topk_weight: torch.Tensor,
    ) -> torch.Tensor:
        """Run routed and shared experts with a fixed routing decision."""

        moe_sequence_parallel = is_sequence_parallel_active()
        sequence_parallel_hidden_states = hidden_states
        if moe_sequence_parallel:
            hidden_states = gather_from_sequence_parallel_region(hidden_states)
        bsz, seqlen, hidden = hidden_states.shape
        expert_input = hidden_states.to(dtype=projection_dtype(self.experts.linear_fc1))
        with sequence_parallel_region(False):
            flat = expert_input.view(-1, hidden)
            if not self.training and getattr(self.experts.linear_fc1, "quantized_weight", None) is not None:
                out = self._forward_nf4_moe(flat, topk_idx, topk_weight).view(bsz, seqlen, hidden)
            elif self.training or not self._infer_weights_ready:
                # Permute/unpermute path is autograd-friendly.
                out = self.experts(flat, topk_idx, topk_weight).view(bsz, seqlen, hidden)
            else:
                # Inference: fused-MoE kernel over the stacked w1/w2 weights.
                out = self._forward_fused_moe(flat, topk_idx, topk_weight).view(bsz, seqlen, hidden)
        if moe_sequence_parallel:
            out = scatter_to_sequence_parallel_region(out)
        if self.shared_experts is not None:
            shared_input = sequence_parallel_hidden_states if moe_sequence_parallel else hidden_states
            out = out + self.shared_experts(shared_input)
        return out

    def forward(self, hidden_states: torch.Tensor, num_padding_tokens: int = 0) -> torch.Tensor:
        # Preserve the single-gather path used when activation recomputation
        # is disabled. The split route/experts methods intentionally gather
        # independently so checkpointed expert recompute can start from the
        # local SP shard.
        moe_sequence_parallel = is_sequence_parallel_active()
        sequence_parallel_hidden_states = hidden_states
        if moe_sequence_parallel:
            hidden_states = gather_from_sequence_parallel_region(hidden_states)
        bsz, seqlen, hidden = hidden_states.shape
        expert_input = hidden_states.to(dtype=projection_dtype(self.experts.linear_fc1))
        with sequence_parallel_region(False):
            topk_idx, topk_weight, _ = self.gate(hidden_states, num_padding_tokens)
            flat = expert_input.view(-1, hidden)
            if not self.training and getattr(self.experts.linear_fc1, "quantized_weight", None) is not None:
                out = self._forward_nf4_moe(flat, topk_idx, topk_weight).view(bsz, seqlen, hidden)
            elif self.training or not self._infer_weights_ready:
                out = self.experts(flat, topk_idx, topk_weight).view(bsz, seqlen, hidden)
            else:
                out = self._forward_fused_moe(flat, topk_idx, topk_weight).view(bsz, seqlen, hidden)
        if moe_sequence_parallel:
            out = scatter_to_sequence_parallel_region(out)
        if self.shared_experts is not None:
            shared_input = sequence_parallel_hidden_states if moe_sequence_parallel else hidden_states
            out = out + self.shared_experts(shared_input)
        return out

    @torch.no_grad()
    def prepare_infer_weights(self) -> None:
        """Stack per-expert weights into contiguous fused tiles for inference.

        ``_infer_w1_weight`` concatenates (gate, up) per expert so the fused
        kernel does one matmul per expert. ``_infer_w2_weight`` mirrors the
        down projection. Buffers are reused across calls if the shape/device
        already match to avoid reallocating on every weight refresh.
        """
        if getattr(self.experts.linear_fc1, "quantized_weight", None) is not None:
            self.clear_infer_weights()
            return
        gate_weights, up_weights, down_weights = self.experts.inference_weights()
        self._infer_gate_weight = self._updated_infer_weight(
            self._infer_gate_weight, gate_weights.to(dtype=self.config.dtype).contiguous()
        )
        self._infer_up_weight = self._updated_infer_weight(
            self._infer_up_weight, up_weights.to(dtype=self.config.dtype).contiguous()
        )
        self._infer_down_weight = self._updated_infer_weight(
            self._infer_down_weight, down_weights.to(dtype=self.config.dtype).contiguous()
        )
        # w1 = [gate || up] along the intermediate dim so SiLU(gate) * up can
        # be folded into a single fused kernel call.
        self._infer_w1_weight = self._updated_infer_weight(
            self._infer_w1_weight,
            torch.cat((self._infer_gate_weight, self._infer_up_weight), dim=1).contiguous(),
        )
        self._infer_w2_weight = self._updated_infer_weight(self._infer_w2_weight, self._infer_down_weight.contiguous())
        self._infer_weights_ready = True

    @torch.no_grad()
    def _updated_infer_weight(self, current: torch.Tensor, value: torch.Tensor) -> torch.Tensor:
        # Reuse the existing storage when possible — important when the trainer
        # keeps swapping weights in and out (e.g. for evaluation cycles).
        if current.shape == value.shape and current.device == value.device and current.dtype == value.dtype:
            current.copy_(value)
            return current
        return value

    @torch.no_grad()
    def clear_infer_weights(self) -> None:
        """Drop the fused inference tiles and reclaim memory."""
        device = self._infer_gate_weight.device
        dtype = self._infer_gate_weight.dtype
        self._infer_gate_weight = torch.empty(0, device=device, dtype=dtype)
        self._infer_up_weight = torch.empty(0, device=device, dtype=dtype)
        self._infer_down_weight = torch.empty(0, device=device, dtype=dtype)
        self._infer_w1_weight = torch.empty(0, device=device, dtype=dtype)
        self._infer_w2_weight = torch.empty(0, device=device, dtype=dtype)
        self._infer_weights_ready = False

    @torch._dynamo.disable
    def _forward_nf4_moe(self, flat, topk_idx, topk_weight):
        from areno.accel.kernels.nf4_moe import nf4_experts

        local_idx, local_weight = self.experts.local_routes(topk_idx, topk_weight)
        out = nf4_experts(
            flat,
            self.experts.linear_fc1.quantized_weight,
            self.experts.linear_fc2.quantized_weight,
            local_idx,
            local_weight,
            self.experts.lora_slots if self.experts.has_active_lora() else {},
            self._fused_moe_config,
        )
        return all_reduce(out)

    def _forward_fused_moe(self, flat: torch.Tensor, topk_idx: torch.Tensor, topk_weight: torch.Tensor) -> torch.Tensor:
        if self._infer_w1_weight.numel() == 0:
            raise RuntimeError("fused MoE inference weights are not prepared")
        log_once("areno_fused_moe", "using areno fused MoE expert kernel")
        # Drop routes pointing at experts owned by other ranks (their weight
        # is zero, so they contribute nothing locally) and remap global expert
        # ids into the local 0..local_num_experts-1 range.
        local_idx, local_weight = self.experts.local_routes(topk_idx, topk_weight)
        out = _areno_fused_experts_no_compile(
            flat.contiguous(),
            self._infer_w1_weight,
            self._infer_w2_weight,
            local_weight.float(),
            local_idx.int(),
            self._fused_moe_config,
        )
        # Sum each rank's owned-expert contribution back together.
        return all_reduce(out)


class BailingGroupedExperts(nn.Module):
    """Bank of MoE expert FFNs stored as a single fused 3D weight tensor.

    Expert parallelism is piggy-backed on the TP group: each rank owns
    ``local_num_experts = num_experts / world_size`` consecutive experts.
    The grouped-linear kernel takes ``tokens_per_expert`` and runs one fused
    GEMM per expert without materialising per-expert slices.
    """

    def __init__(self, config: ModelConfig):
        super().__init__()
        ctx = get_tp_context()
        self.config = config
        self.num_experts = int(config.num_experts or 0)
        if self.num_experts % ctx.world_size != 0:
            raise ValueError(f"num_experts={self.num_experts} must be divisible by TP/EP size={ctx.world_size}")
        # Contiguous slab of experts owned by this rank.
        self.local_num_experts = self.num_experts // ctx.world_size
        self.local_expert_start = ctx.rank * self.local_num_experts
        self.local_expert_end = self.local_expert_start + self.local_num_experts
        self.hidden_size = config.hidden_size
        self.intermediate_size = config.moe_intermediate_size
        # fc1 = [gate || up] fused into ``2 * intermediate_size`` rows so
        # SiLU(gate) * up can collapse into a single kernel; fc2 is the down
        # projection back to hidden size.
        self.linear_fc1 = _build_grouped_linear(
            self.local_num_experts,
            self.hidden_size,
            2 * self.intermediate_size,
            dtype=config.dtype,
        )
        self.linear_fc2 = _build_grouped_linear(
            self.local_num_experts,
            self.intermediate_size,
            self.hidden_size,
            dtype=config.dtype,
        )
        self.lora_slots = nn.ModuleDict()
        # Expert weights are sharded by EP (collapsed into TP); flag them as
        # not-TP/not-SP so the standard TP collectives leave them alone.
        for param in self.parameters():
            mark_tensor_parallel_parameter(param, False, sequence_parallel=False)

    def install_lora_component(self, component: str, slot: nn.Module) -> None:
        self.lora_slots[component] = slot

    def has_lora(self) -> bool:
        return bool(self.lora_slots)

    def has_active_lora(self) -> bool:
        return self.has_lora() and next(iter(self.lora_slots.values())).enabled

    def forward(self, flat: torch.Tensor, topk_idx: torch.Tensor, topk_weight: torch.Tensor) -> torch.Tensor:
        return self._forward_fused_permute(flat, topk_idx, topk_weight)

    def _forward_fused_permute(
        self, flat: torch.Tensor, topk_idx: torch.Tensor, topk_weight: torch.Tensor
    ) -> torch.Tensor:
        log_once("areno_moe_permute", "using fused MoE permute/unpermute kernels")
        # Permute: group tokens by destination expert, keeping only routes for
        # locally-owned experts. ``tokens_per_expert`` is a 1D count used to
        # offset the grouped GEMM.
        x, sorted_route_weight, sorted_token_idx, tokens_per_expert = _areno_moe_topk_permute_no_compile(
            flat,
            topk_idx,
            topk_weight.float(),
            self.local_expert_start,
            self.local_num_experts,
        )
        if x.shape[0] == 0:
            # Every TP/DP replica must produce gradients for the same parameter
            # set even when this rank owns no active routes.
            zero = topk_weight.sum().to(dtype=projection_dtype(self.linear_fc1)) * 0
            if self.linear_fc1.weight is not None:
                zero = zero + self.linear_fc1.weight.reshape(-1)[0] * 0 + self.linear_fc2.weight.reshape(-1)[0] * 0
            if self.has_active_lora():
                for slot in self.lora_slots.values():
                    zero = zero + slot.lora_A.reshape(-1)[0] * 0 + slot.lora_B.reshape(-1)[0] * 0
            return all_reduce(flat.new_zeros(flat.shape) + zero)
        hidden, _ = _grouped_linear_forward(self.linear_fc1, x.contiguous(), tokens_per_expert)
        if self.has_active_lora():
            gate, up = hidden.chunk(2, dim=-1)
            if "gate_proj" in self.lora_slots:
                gate = gate + self.lora_slots["gate_proj"](x, tokens_per_expert)
            if "up_proj" in self.lora_slots:
                up = up + self.lora_slots["up_proj"](x, tokens_per_expert)
            hidden = torch.cat((gate, up), dim=-1)
        # Apply routing weight before fc2 so it stays inside the fp32 reduction.
        hidden = (
            _areno_silu_and_mul_no_compile(hidden) * sorted_route_weight.unsqueeze(-1).to(dtype=hidden.dtype)
        ).contiguous()
        expert_out, _ = _grouped_linear_forward(self.linear_fc2, hidden, tokens_per_expert)
        if self.has_active_lora() and "down_proj" in self.lora_slots:
            expert_out = expert_out + self.lora_slots["down_proj"](hidden, tokens_per_expert)
        # Unpermute back to original (batch, seq) order, then scale and reduce.
        if self.has_lora():
            out = _areno_moe_unpermute_no_compile(
                expert_out.float(), sorted_token_idx, merging_probs=None, restore_shape=flat.shape
            ).to(dtype=flat.dtype)
        else:
            out = _areno_moe_unpermute_no_compile(
                expert_out, sorted_token_idx, merging_probs=None, restore_shape=flat.shape
            )
        return all_reduce(out * self.config.routed_scaling_factor)

    def local_routes(self, topk_idx: torch.Tensor, topk_weight: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Mask routes that miss locally-owned experts and remap ids to 0-based local."""
        local_mask = (topk_idx >= self.local_expert_start) & (topk_idx < self.local_expert_end)
        local_idx = (topk_idx - self.local_expert_start).clamp(0, self.local_num_experts - 1)
        return local_idx, topk_weight * local_mask.to(dtype=topk_weight.dtype)

    @torch.no_grad()
    def copy_expert(
        self, expert_id: int, gate: torch.Tensor, up: torch.Tensor, down: torch.Tensor, rank: int, world_size: int
    ) -> None:
        """Copy one expert's HF weights into the appropriate local slot."""
        del rank, world_size
        if expert_id < self.local_expert_start or expert_id >= self.local_expert_end:
            return
        local_expert_id = expert_id - self.local_expert_start
        fc1_weight = _grouped_weight(self.linear_fc1, local_expert_id)
        # Concatenate gate+up along the output dim to match fc1's fused layout.
        fc1_weight.copy_(torch.cat((gate, up), dim=0).to(dtype=fc1_weight.dtype))
        fc2_weight = _grouped_weight(self.linear_fc2, local_expert_id)
        fc2_weight.copy_(down.to(dtype=fc2_weight.dtype))

    @torch.no_grad()
    def expert_weights(self) -> tuple[list[torch.Tensor], list[torch.Tensor], list[torch.Tensor]]:
        """Return per-local-expert (gate, up, down) views for fused-MoE prep."""
        gate_weights = []
        up_weights = []
        down_weights = []
        for expert_id in range(self.local_num_experts):
            fc1_weight = _grouped_weight(self.linear_fc1, expert_id).detach()
            # Split the fused gate||up tile back into the two halves.
            gate, up = fc1_weight.chunk(2, dim=0)
            gate_weights.append(gate)
            up_weights.append(up)
            down_weights.append(_grouped_weight(self.linear_fc2, expert_id).detach())
        return gate_weights, up_weights, down_weights

    @torch.no_grad()
    def inference_weights(self) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Build derived fused-rollout weights without modifying the frozen base."""

        gate_weights, up_weights, down_weights = self.expert_weights()
        merged = {
            "gate_proj": torch.stack(gate_weights, dim=0),
            "up_proj": torch.stack(up_weights, dim=0),
            "down_proj": torch.stack(down_weights, dim=0),
        }
        if self.has_active_lora():
            for component, weight in merged.items():
                if component not in self.lora_slots:
                    continue
                slot = self.lora_slots[component]
                delta = torch.bmm(slot.lora_B, slot.lora_A)
                weight.add_(delta.mul_(slot.scale))
        return merged["gate_proj"], merged["up_proj"], merged["down_proj"]

    @torch.no_grad()
    def full_expert_weights(self) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor] | None:
        """Gather all experts onto DP rank 0 for checkpoint saving (None elsewhere)."""
        gate_weights, up_weights, down_weights = self.expert_weights()
        gate = _gather_expert_parallel_tensor(torch.stack(gate_weights, dim=0))
        up = _gather_expert_parallel_tensor(torch.stack(up_weights, dim=0))
        down = _gather_expert_parallel_tensor(torch.stack(down_weights, dim=0))
        if gate is None or up is None or down is None:
            return None
        return gate, up, down

    @torch.no_grad()
    def offload_to_cpu(self) -> None:
        """Move all expert params to CPU (used during inference-only phases)."""
        if getattr(self.linear_fc1, "quantized_weight", None) is not None:
            return  # Rollout uses the same packed base and live adapters.
        for param in self.parameters():
            param.data = param.data.to(device="cpu")

    @torch.no_grad()
    def onload_to_device(self, device: torch.device) -> None:
        """Restore params to the target device for training."""
        for param in self.parameters():
            if param.device != device:
                param.data = param.data.to(device=device)


def _build_grouped_linear(num_gemms: int, in_features: int, out_features: int, *, dtype: torch.dtype) -> nn.Module:
    return ArenoGroupedLinear(num_gemms, in_features, out_features, dtype=dtype)


class ArenoGroupedLinear(nn.Module):
    """Fused per-expert linear: ``(num_gemms, out, in)`` weight + per-expert
    token counts driving ``areno_grouped_linear``."""

    def __init__(self, num_gemms: int, in_features: int, out_features: int, *, dtype: torch.dtype):
        super().__init__()
        self.num_gemms = num_gemms
        self.in_features = in_features
        self.out_features = out_features
        self.weight = nn.Parameter(torch.empty(num_gemms, out_features, in_features, dtype=dtype))

    def forward(self, x: torch.Tensor, tokens_per_expert: torch.Tensor | Sequence[int]) -> torch.Tensor:
        quantized = getattr(self, "quantized_weight", None)
        if quantized is not None:
            from areno.accel.nf4 import nf4_grouped_linear

            return nf4_grouped_linear(x, quantized, tokens_per_expert)
        if isinstance(tokens_per_expert, torch.Tensor):
            if tokens_per_expert.numel() != self.num_gemms:
                raise ValueError(f"expected {self.num_gemms} expert token counts, got {tokens_per_expert.numel()}")
            if x.shape[0] == 0:
                # Avoid invoking the kernel on an empty batch — return a fresh
                # empty tensor with the right out feature dim.
                return x.new_empty((0, self.out_features))
            return areno_grouped_linear(x.contiguous(), self.weight, tokens_per_expert)
        if len(tokens_per_expert) != self.num_gemms:
            raise ValueError(f"expected {self.num_gemms} expert token counts, got {len(tokens_per_expert)}")
        offset = sum(tokens_per_expert)
        if offset != x.shape[0]:
            raise ValueError(f"tokens_per_expert sums to {offset}, but input has {x.shape[0]} rows")
        if offset == 0:
            # Avoid invoking the kernel on an empty batch — return a fresh
            # empty tensor with the right out feature dim.
            return x.new_empty((0, self.out_features))
        return areno_grouped_linear(x.contiguous(), self.weight, tokens_per_expert)


def _grouped_linear_forward(
    module: nn.Module, x: torch.Tensor, tokens_per_expert: torch.Tensor | Sequence[int]
) -> tuple[torch.Tensor, torch.Tensor | None]:
    out = module(x, tokens_per_expert)
    if isinstance(out, tuple):
        return out
    return out, None


@torch._dynamo.disable
def _areno_silu_no_compile(x: torch.Tensor) -> torch.Tensor:
    return areno_silu(x)


@torch._dynamo.disable
def _areno_sigmoid_no_compile(x: torch.Tensor) -> torch.Tensor:
    return areno_sigmoid(x)


@torch._dynamo.disable
def _areno_grouped_topk_router_no_compile(
    logits: torch.Tensor,
    expert_bias: torch.Tensor,
    top_k: int,
    num_groups: int,
    topk_group: int,
) -> tuple[torch.Tensor, torch.Tensor]:
    return areno_grouped_topk_router(logits, expert_bias, top_k, num_groups, topk_group)


@torch._dynamo.disable
def _areno_linear_no_compile(x: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:
    return areno_linear(x, weight, None)


def _cast_linear_weights(module: nn.Module, dtype: torch.dtype) -> None:
    weight = getattr(module, "weight", None)
    if isinstance(weight, nn.Parameter):
        weight.data = weight.data.to(dtype=dtype)
    bias = getattr(module, "bias", None)
    if isinstance(bias, nn.Parameter):
        bias.data = bias.data.to(dtype=dtype)


@torch._dynamo.disable
def _areno_silu_pair_no_compile(gate: torch.Tensor, up: torch.Tensor) -> torch.Tensor:
    return areno_silu_and_mul(torch.cat((gate, up), dim=-1))


@torch._dynamo.disable
def _areno_silu_and_mul_no_compile(x: torch.Tensor) -> torch.Tensor:
    return areno_silu_and_mul(x)


@torch._dynamo.disable
def _areno_moe_topk_permute_no_compile(
    flat: torch.Tensor,
    topk_idx: torch.Tensor,
    topk_weight: torch.Tensor,
    local_expert_start: int,
    local_num_experts: int,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
    return areno_moe_topk_permute(flat, topk_idx, topk_weight, local_expert_start, local_num_experts)


@torch._dynamo.disable
def _areno_moe_unpermute_no_compile(
    expert_out: torch.Tensor,
    sorted_token_idx: torch.Tensor,
    *,
    merging_probs: None,
    restore_shape: tuple[int, int],
) -> torch.Tensor:
    del merging_probs
    return areno_moe_unpermute(expert_out, sorted_token_idx, restore_shape)


def _gather_expert_parallel_tensor(tensor: torch.Tensor) -> torch.Tensor | None:
    ctx = get_tp_context()
    if ctx.dp_rank != 0:
        return None
    local = tensor.detach().contiguous()
    if ctx.world_size == 1:
        return local.cpu()
    if ctx.rank == 0:
        chunks = [torch.empty_like(local) for _ in range(ctx.world_size)]
        dist.gather(local, gather_list=chunks, dst=ctx.dp_rank * ctx.world_size, group=ctx.group)
        return torch.cat(chunks, dim=0).cpu()
    dist.gather(local, dst=ctx.dp_rank * ctx.world_size, group=ctx.group)
    return None


def _grouped_weight(module: nn.Module, expert_id: int) -> torch.Tensor:
    weight = getattr(module, f"weight{expert_id}", None)
    if weight is not None:
        return weight
    weights = getattr(module, "weight", None)
    if isinstance(weights, torch.Tensor) and weights.dim() == 3:
        return weights[expert_id]
    if isinstance(weights, list | tuple | nn.ParameterList):
        return weights[expert_id]
    raise AttributeError(f"cannot find grouped expert weight for expert {expert_id}")


def _parse_bool(value: Any, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        lowered = value.strip().lower()
        if lowered in {"1", "true", "yes", "on"}:
            return True
        if lowered in {"0", "false", "no", "off"}:
            return False
    return bool(value)


class BailingSoftmaxAttention(nn.Module):
    """Softmax attention layer with either GQA (fused QKV projection) or
    MLA-style low-rank KV pathway.

    When ``kv_lora_rank`` is set the layer follows the DeepSeek-V2-style MLA
    factorisation: Q is computed normally, K/V come from a low-rank
    compressed KV projection, RoPE is applied to a dedicated ``qk_rope_head_dim``
    slice while the rest of QK uses non-rope ``qk_nope_head_dim`` channels.
    """

    def __init__(self, config: ModelConfig, layer_idx: int):
        super().__init__()
        self.lora_slots = nn.ModuleDict()
        ctx = get_tp_context()
        self.layer_idx = layer_idx
        # Head-dim split: rope vs non-rope channels on Q/K, plus separate V dim.
        self.qk_nope_head_dim = config.qk_nope_head_dim or config.head_dim
        self.qk_rope_head_dim = config.qk_rope_head_dim or int(config.head_dim * config.partial_rotary_factor)
        self.v_head_dim = config.v_head_dim or config.head_dim
        self.head_dim = self.qk_nope_head_dim + self.qk_rope_head_dim
        self.num_heads = config.num_attention_heads
        self.num_kv_heads = config.num_key_value_heads
        # Per-rank head counts (TP sharded).
        self.local_heads = self.num_heads // ctx.world_size
        self.local_kv_heads = self.num_kv_heads // ctx.world_size
        self.q_lora_rank = config.q_lora_rank
        self.kv_lora_rank = config.kv_lora_rank
        self.query_key_value = None
        self.q_proj = None
        self.q_a_proj = None
        self.q_a_layernorm = None
        self.q_b_proj = None
        self.kv_a_proj_with_mqa = None
        self.kv_a_layernorm = None
        self.kv_b_proj = None
        if self.kv_lora_rank is None:
            # Standard GQA: one fused QKV projection.
            self.num_qkv_heads = self.num_heads + 2 * self.num_kv_heads
            self.local_qkv_heads = self.local_heads + 2 * self.local_kv_heads
            self.query_key_value = ColumnParallelLinear(
                config.hidden_size, self.num_qkv_heads * config.head_dim, bias=config.qkv_bias
            )
            _cast_linear_weights(self.query_key_value, config.dtype)
            self.query_layernorm = RMSNorm(config.head_dim, config.rms_norm_eps) if config.qk_norm else None
            self.key_layernorm = RMSNorm(config.head_dim, config.rms_norm_eps) if config.qk_norm else None
        else:
            # MLA: Q has full per-head projection, KV goes through a shared
            # low-rank bottleneck (``kv_a_proj_with_mqa``) plus a per-head
            # decompression (``kv_b_proj``). The ``kv_a`` output also carries
            # the rope channels in its tail (``qk_rope_head_dim`` cols).
            if self.q_lora_rank is None:
                self.q_proj = ColumnParallelLinear(
                    config.hidden_size,
                    self.num_heads * self.head_dim,
                    bias=False,
                    input_grad_allreduce=False,
                )
                _cast_linear_weights(self.q_proj, config.dtype)
            else:
                self.q_a_proj = nn.Linear(config.hidden_size, self.q_lora_rank, bias=False)
                _cast_linear_weights(self.q_a_proj, config.dtype)
                mark_tensor_parallel_parameter(
                    self.q_a_proj.weight, False, sequence_parallel=True, tp_grad_allreduce=True
                )
                self.q_a_layernorm = RMSNorm(self.q_lora_rank, config.rms_norm_eps)
                self.q_b_proj = ColumnParallelLinear(
                    self.q_lora_rank,
                    self.num_heads * self.head_dim,
                    bias=False,
                    input_grad_allreduce=False,
                )
                _cast_linear_weights(self.q_b_proj, config.dtype)
            self.kv_a_proj_with_mqa = nn.Linear(
                config.hidden_size, self.kv_lora_rank + self.qk_rope_head_dim, bias=False
            )
            _cast_linear_weights(self.kv_a_proj_with_mqa, config.dtype)
            mark_tensor_parallel_parameter(
                self.kv_a_proj_with_mqa.weight, False, sequence_parallel=True, tp_grad_allreduce=True
            )
            self.kv_a_layernorm = RMSNorm(self.kv_lora_rank, config.rms_norm_eps)
            self.kv_b_proj = ColumnParallelLinear(
                config.kv_lora_rank,
                self.num_heads * (self.qk_nope_head_dim + self.v_head_dim),
                bias=False,
                input_grad_allreduce=False,
            )
            _cast_linear_weights(self.kv_b_proj, config.dtype)
            self.query_layernorm = None
            self.key_layernorm = None
        self.g_proj = (
            ColumnParallelLinear(config.hidden_size, self.num_heads, bias=False) if config.attn_output_gate else None
        )
        if self.g_proj is not None:
            _cast_linear_weights(self.g_proj, config.dtype)
        self.dense = RowParallelLinear(self.num_heads * self.v_head_dim, config.hidden_size, bias=config.use_bias)
        _cast_linear_weights(self.dense, config.dtype)
        # Rotary embedding applied only on the qk_rope_head_dim slice.
        self.rope = PartialRotaryEmbedding(
            self.qk_rope_head_dim,
            config.max_position_embeddings,
            config.rope_theta,
            1.0,
            is_neox_style=False,
        )
        self.attn_backend = config.attn_backend
        self.train_backend = build_train_attention_backend(self.attn_backend)
        self.infer_backend: FlashAttnInferBackend | None = None
        # KV cache slots populated by the runtime at engine setup.
        self.k_cache = torch.tensor([])
        self.v_cache = torch.tensor([])

    def install_lora_component(self, component: str, slot: nn.Module) -> None:
        """Attach an adapter to one replicated MLA projection."""

        self.lora_slots[component] = slot

    def _with_lora(self, component: str, x: torch.Tensor, output: torch.Tensor) -> torch.Tensor:
        slot = self.lora_slots[component] if component in self.lora_slots else None
        return output + slot(x) if slot is not None and slot.enabled else output

    def forward(
        self,
        hidden_states: torch.Tensor,
        position_ids: torch.Tensor,
        train_meta: TrainMeta | None,
        infer_meta: InferMeta | None,
    ) -> torch.Tensor:
        hidden_states = hidden_states.to(dtype=projection_dtype(self.dense))
        q, k, v = self._project(hidden_states, position_ids)
        bsz, seqlen = q.shape[:2]
        if infer_meta is not None:
            # Lazily build the inference backend so weight-only training paths
            # don't pay the cost.
            if self.infer_backend is None:
                self.infer_backend = build_infer_attention_backend(self.attn_backend)
            out = self.infer_backend(q, k, v, self.k_cache, self.v_cache, infer_meta)
        else:
            out = self.train_backend(q, k, v, train_meta)
        if self.g_proj is not None:
            gate = _areno_sigmoid_no_compile(self.g_proj(hidden_states)).view(bsz, seqlen, self.local_heads, 1)
            out = out * gate
        return self.dense(out.contiguous().view(bsz, seqlen, self.local_heads * self.v_head_dim))

    def _project(
        self, hidden_states: torch.Tensor, position_ids: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        if self.kv_lora_rank is None:
            # Standard GQA path: split fused QKV, optional per-head norm, rope
            # on the trailing qk_rope_head_dim channels only.
            assert self.query_key_value is not None
            qkv = self.query_key_value(hidden_states)
            bsz, seqlen = qkv.shape[:2]
            qkv = qkv.view(bsz, seqlen, self.local_heads + 2 * self.local_kv_heads, self.head_dim)
            q, k, v = qkv.split([self.local_heads, self.local_kv_heads, self.local_kv_heads], dim=-2)
            if self.query_layernorm is not None:
                q = self.query_layernorm(q)
                k = self.key_layernorm(k)
            q_rope, k_rope = self.rope(q[..., -self.qk_rope_head_dim :], k[..., -self.qk_rope_head_dim :], position_ids)
            return (
                torch.cat((q[..., : self.qk_nope_head_dim], q_rope), dim=-1),
                torch.cat((k[..., : self.qk_nope_head_dim], k_rope), dim=-1),
                v,
            )

        # MLA path: split Q into nope/rope chunks, decompress KV from the
        # shared low-rank rep, then re-attach a broadcast rope channel.
        assert self.kv_a_proj_with_mqa is not None and self.kv_a_layernorm is not None and self.kv_b_proj is not None
        mla_input = hidden_states if is_sequence_parallel_active() else copy_to_tensor_parallel_region(hidden_states)
        if self.q_lora_rank is None:
            assert self.q_proj is not None
            q = self.q_proj(mla_input)
        else:
            assert self.q_a_proj is not None and self.q_a_layernorm is not None and self.q_b_proj is not None
            q_a = self._with_lora("q_a_proj", mla_input, self.q_a_proj(mla_input))
            q = self.q_b_proj(self.q_a_layernorm(q_a))
        bsz, seqlen = q.shape[:2]
        q = q.view(bsz, seqlen, self.local_heads, self.head_dim)
        q_nope, q_rope = q.split([self.qk_nope_head_dim, self.qk_rope_head_dim], dim=-1)
        kv_a = self._with_lora("kv_a_proj_with_mqa", mla_input, self.kv_a_proj_with_mqa(mla_input))
        compressed_kv, k_rope = kv_a.split([self.kv_lora_rank, self.qk_rope_head_dim], dim=-1)
        if is_sequence_parallel_active():
            k_rope = gather_from_sequence_parallel_region(k_rope)
        kv = self.kv_b_proj(self.kv_a_layernorm(compressed_kv)).view(
            bsz, seqlen, self.local_heads, self.qk_nope_head_dim + self.v_head_dim
        )
        k_nope, v = kv.split([self.qk_nope_head_dim, self.v_head_dim], dim=-1)
        q_rope, k_rope = self.rope(q_rope, k_rope.unsqueeze(2), position_ids)
        # Single rope channel is broadcast over all heads (MQA-style).
        k_rope = k_rope.expand(-1, -1, self.local_heads, -1)
        return torch.cat((q_nope, q_rope), dim=-1), torch.cat((k_nope, k_rope), dim=-1), v

    def set_kv_cache(self, k_cache: torch.Tensor, v_cache: torch.Tensor) -> None:
        self.k_cache = k_cache
        self.v_cache = v_cache

    def clear_kv_cache(self) -> None:
        self.k_cache = torch.tensor([])
        self.v_cache = torch.tensor([])
        self.infer_backend = None

    def reset_kv_cache(self) -> None:
        return None


class BailingLinearAttention(nn.Module):
    """Linear-attention layer using chunked lightning-attn (training) or
    ``seg_la`` recurrent kernels (inference).

    Each layer carries a per-head ALiBi-style decay slope plus an optional
    SiLU on QKV. A sigmoid-gated RMSNorm on the output (``g_norm`` /
    ``g_proj``) acts as the layer-output gating mechanism, mirroring the
    Lightning-Attention / Minimax linear attention paper recipe.
    """

    def __init__(self, config: ModelConfig, layer_idx: int):
        super().__init__()
        ctx = get_tp_context()
        self.layer_idx = layer_idx
        self.num_heads = config.num_attention_heads
        self.local_heads = self.num_heads // ctx.world_size
        # Linear attention treats Q/K/V symmetrically (same head count).
        self.num_kv_heads = self.num_heads
        self.num_qkv_heads = 3 * self.num_heads
        self.local_qkv_heads = 3 * self.local_heads
        self.head_dim = config.head_dim
        self.num_layers = config.num_hidden_layers
        self.scaling = self.head_dim**-0.5
        self.linear_scale = config.linear_scale
        self.linear_silu = config.linear_silu
        # Fused QKV projection. ``g_proj`` produces the output gate.
        self.query_key_value = ColumnParallelLinear(
            config.hidden_size, self.num_qkv_heads * self.head_dim, bias=config.qkv_bias
        )
        self.dense = RowParallelLinear(self.num_heads * self.head_dim, config.hidden_size, bias=config.use_bias)
        self.g_proj = ColumnParallelLinear(config.hidden_size, self.num_heads * self.head_dim, bias=False)
        self.group_norm_size = config.group_norm_size
        if self.group_norm_size > 1:
            # Grouped RMSNorm + sigmoid gate fused into one kernel — used when
            # the model exposes a coarser head-group granularity.
            self.g_norm = GroupRMSNormSigmoidGate(
                self.num_heads * self.head_dim,
                self.group_norm_size,
                ctx.world_size,
                config.rms_norm_eps,
            )
        else:
            # Plain per-rank RMSNorm; the sigmoid gate is applied outside.
            self.g_norm = RMSNorm(
                self.local_heads * self.head_dim,
                config.rms_norm_eps,
                tensor_model_parallel=True,
                sequence_parallel=False,
                tp_grad_allreduce=False,
            )
        self.query_layernorm = RMSNorm(self.head_dim, config.rms_norm_eps) if config.qk_norm else None
        self.key_layernorm = RMSNorm(self.head_dim, config.rms_norm_eps) if config.qk_norm else None
        self.rope = PartialRotaryEmbedding(
            config.head_dim,
            config.max_position_embeddings,
            config.rope_theta,
            config.partial_rotary_factor,
            is_neox_style=True,
        )
        if config.linear_backend != "seg_la":
            raise ValueError(
                f"BailingMoeV2_5ForCausalLM expects linear_backend='seg_la', got {config.linear_backend!r}"
            )
        # Per-head decay slope (ALiBi-like, head- and layer-dependent) used as
        # the gating factor in the recurrent state update.
        self.register_buffer(
            "slope",
            _build_slope_tensor(
                self.local_heads,
                config.num_attention_heads,
                layer_idx,
                config.num_hidden_layers,
                ctx.rank,
                ctx.world_size,
            ),
            persistent=False,
        )
        # Recurrent state cache populated at engine setup; shape is
        # ``[num_slots, local_heads, head_dim, head_dim]``.
        self.state_cache = torch.tensor([])

    def forward(
        self,
        hidden_states: torch.Tensor,
        position_ids: torch.Tensor,
        train_meta: TrainMeta | None,
        infer_meta: InferMeta | None,
    ) -> torch.Tensor:
        qkv = self.query_key_value(hidden_states)
        bsz, seqlen = qkv.shape[:2]
        if self.linear_silu:
            qkv = _areno_silu_no_compile(qkv)
        qkv = qkv.view(bsz, seqlen, 3 * self.local_heads, self.head_dim)
        q, k, v = qkv.split([self.local_heads, self.local_heads, self.local_heads], dim=-2)
        if self.query_layernorm is not None:
            q = self.query_layernorm(q)
            k = self.key_layernorm(k)
        q, k = self.rope(q, k, position_ids)
        if self.linear_scale:
            q = q * self.scaling
        if infer_meta is not None:
            out = self._forward_infer(q, k, v, infer_meta)
        else:
            out = self._forward_train(q, k, v, train_meta)
        out = out.to(hidden_states.dtype).reshape(bsz, seqlen, -1)
        gate = self.g_proj(hidden_states)
        if self.group_norm_size > 1:
            # Fused norm+sigmoid-gate kernel.
            out = self.g_norm(out, gate)
        else:
            out = self.g_norm(out) * _areno_sigmoid_no_compile(gate)
        return self.dense(out.to(hidden_states.dtype))

    def _forward_train(
        self, q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, train_meta: TrainMeta | None
    ) -> torch.Tensor:
        # Packed sequences need ``cu_seqlens`` so the chunked kernel can
        # respect document boundaries; otherwise fall back to dense path.
        if train_meta is None or not train_meta.packed or train_meta.cu_seqlens is None:
            return self._forward_full(q, k, v)
        cu_seqlens = train_meta.cu_seqlens.to(device=q.device, dtype=torch.int32)
        return self._forward_lightning(q, k, v, cu_seqlens=cu_seqlens)

    def _forward_full(self, q: torch.Tensor, k: torch.Tensor, v: torch.Tensor) -> torch.Tensor:
        return self._forward_lightning(q, k, v, cu_seqlens=None)

    def _forward_lightning(
        self, q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, cu_seqlens: torch.Tensor | None
    ) -> torch.Tensor:
        log_once("chunk_lightning_attn", "using chunk lightning attention training kernel")
        k = k.to(dtype=q.dtype)
        v = v.to(dtype=q.dtype)
        # g_gamma = -slope feeds the gated decay; chunked impl runs an
        # efficient block-recurrent pass without materialising the full
        # attention matrix.
        out, _ = chunk_lightning_attn(
            q,
            k,
            v,
            g_gamma=-self.slope,
            layer_idx=self.layer_idx,
            num_layers=self.num_layers,
            initial_state=None,
            output_final_state=False,
            cu_seqlens=cu_seqlens,
            head_first=False,
        )
        return out

    def _forward_infer(self, q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, infer_meta: InferMeta) -> torch.Tensor:
        if infer_meta.block_table is None:
            raise RuntimeError("linear attention inference requires block_table")
        if self.state_cache.numel() == 0:
            raise RuntimeError("linear attention inference requires recurrent state cache")
        slots = _recurrent_cache_slots(infer_meta)
        if infer_meta.mode == "decode":
            return self._forward_decode(q, k, v, slots)
        if infer_meta.mode == "prefill":
            if infer_meta.cu_seqlens is None:
                raise RuntimeError("linear attention prefill requires cu_seqlens")
            return self._forward_prefill(q, k, v, slots, infer_meta.cu_seqlens)
        raise ValueError(f"unsupported inference mode: {infer_meta.mode}")

    def _forward_decode(self, q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, slots: torch.Tensor) -> torch.Tensor:
        log_once("seg_la_decode", "using seg_la linear attention decode kernel")
        # Decode runs one token per request; flatten to (batch, heads, dim)
        # and supply unit-stride offsets and "scale=1" gating per request.
        q_flat = q.reshape(-1, self.local_heads, self.head_dim).contiguous()
        k_flat = k.reshape(-1, self.local_heads, self.head_dim).contiguous()
        v_flat = v.reshape(-1, self.local_heads, self.head_dim).contiguous()
        batch = q_flat.shape[0]
        q_offsets = torch.arange(batch + 1, device=q.device, dtype=torch.int32)
        # s_scales=True -> apply the previously-stored state for decode.
        s_scales = torch.ones(batch, device=q.device, dtype=torch.bool)
        out = self._forward_seg_la(q_flat, k_flat, v_flat, self.state_cache, slots.to(torch.int32), q_offsets, s_scales)
        return out.view_as(q)

    def _forward_prefill(
        self, q: torch.Tensor, k: torch.Tensor, v: torch.Tensor, slots: torch.Tensor, cu_seqlens: torch.Tensor
    ) -> torch.Tensor:
        q_flat = q.reshape(-1, self.local_heads, self.head_dim)
        k_flat = k.reshape(-1, self.local_heads, self.head_dim)
        v_flat = v.reshape(-1, self.local_heads, self.head_dim)
        log_once("seg_la_prefill", "using seg_la linear attention prefill kernel")
        batch = slots.numel()
        # Prefill starts from zero state, so s_scales=False (no prior state).
        s_scales = torch.zeros(batch, device=q.device, dtype=torch.bool)
        return self._forward_seg_la(
            q_flat.contiguous(),
            k_flat.contiguous(),
            v_flat.contiguous(),
            self.state_cache,
            slots.to(torch.int32),
            cu_seqlens.to(device=q.device, dtype=torch.int32),
            s_scales,
        ).view_as(q)

    def _forward_seg_la(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        state: torch.Tensor,
        slots: torch.Tensor,
        q_offsets: torch.Tensor,
        s_scales: torch.Tensor,
    ) -> torch.Tensor:
        q_lengths = q_offsets.diff()
        meta = SegLaMeta(
            batch_size=int(slots.numel()),
            max_q_length=0,
            q_offsets=q_offsets,
            s_offsets=slots,
            q_lengths=q_lengths,
            s_scales=s_scales,
            mask=None,
        )
        return _seg_la_fwd_no_compile(
            q=q,
            k=k,
            v=v,
            s=state,
            decay_scales=self.slope.to(device=q.device, dtype=torch.float32),
            meta=meta,
        )

    def set_state_cache(self, state_cache: torch.Tensor) -> None:
        self.state_cache = state_cache

    def clear_kv_cache(self) -> None:
        self.state_cache = torch.tensor([])

    @torch.no_grad()
    def reset_kv_cache(self) -> None:
        # Zero the recurrent state but keep the buffer (re-allocation is
        # expensive on hot reload).
        if self.state_cache.numel() > 0:
            self.state_cache.zero_()


@torch._dynamo.disable
def _seg_la_fwd_no_compile(**kwargs) -> torch.Tensor:
    return seg_la_fwd(**kwargs)


@torch._dynamo.disable
def _areno_fused_experts_no_compile(*args, **kwargs) -> torch.Tensor:
    return areno_fused_experts(*args, **kwargs)


class BailingKDAAttention(nn.Module):
    """Bailing V3 Kimi Delta Attention layout.

    The checkpoint stores separate Q/K/V, beta, forget-gate, output-gate, and
    causal-conv tensors under ``attention.*``. Runtime execution reuses the
    existing AReno/FLA gated-delta path used by other hybrid adapters.
    """

    def __init__(self, config: ModelConfig, layer_idx: int):
        super().__init__()
        ctx = get_tp_context()
        self.layer_idx = layer_idx
        self.num_heads = config.num_attention_heads
        self.local_heads = self.num_heads // ctx.world_size
        self.head_dim = config.head_dim
        self.v_head_dim = config.v_head_dim or config.head_dim
        self.proj_dim = self.num_heads * self.head_dim
        self.local_proj_dim = self.local_heads * self.head_dim
        self.conv_kernel_size = config.linear_conv_kernel_dim
        self.kda_safe_gate = config.kda_safe_gate
        self.kda_lower_bound = config.kda_lower_bound

        self.q_proj = ColumnParallelLinear(config.hidden_size, self.proj_dim, bias=False)
        self.k_proj = ColumnParallelLinear(config.hidden_size, self.proj_dim, bias=False)
        self.v_proj = ColumnParallelLinear(config.hidden_size, self.proj_dim, bias=False)
        self.f_proj = ColumnParallelLinear(config.hidden_size, self.proj_dim, bias=False)
        self.g_proj = ColumnParallelLinear(config.hidden_size, self.proj_dim, bias=False)
        self.b_proj = ColumnParallelLinear(config.hidden_size, self.num_heads, bias=False)
        for proj in (self.q_proj, self.k_proj, self.v_proj, self.f_proj, self.g_proj, self.b_proj):
            _cast_linear_weights(proj, config.dtype)
        self.q_conv1d_weight = nn.Parameter(torch.empty(self.local_proj_dim, 1, self.conv_kernel_size))
        self.k_conv1d_weight = nn.Parameter(torch.empty(self.local_proj_dim, 1, self.conv_kernel_size))
        self.v_conv1d_weight = nn.Parameter(torch.empty(self.local_proj_dim, 1, self.conv_kernel_size))
        mark_tensor_parallel_parameter(self.q_conv1d_weight, True, sequence_parallel=True)
        mark_tensor_parallel_parameter(self.k_conv1d_weight, True, sequence_parallel=True)
        mark_tensor_parallel_parameter(self.v_conv1d_weight, True, sequence_parallel=True)
        self.dt_bias = nn.Parameter(torch.empty(self.local_proj_dim, dtype=torch.float32))
        self.A_log = nn.Parameter(torch.empty(self.local_heads, dtype=torch.float32))
        mark_tensor_parallel_parameter(self.dt_bias, True, sequence_parallel=True)
        mark_tensor_parallel_parameter(self.A_log, True, sequence_parallel=True)
        self.o_norm_weight = nn.Parameter(torch.ones(self.head_dim))
        self.o_proj = RowParallelLinear(self.proj_dim, config.hidden_size, bias=False)
        _cast_linear_weights(self.o_proj, config.dtype)
        self.scale = self.head_dim**-0.5
        self.eps = config.rms_norm_eps
        self.state_cache = torch.tensor([])
        self.conv_cache = torch.tensor([])
        self.register_buffer("_infer_lora_A", torch.empty(0), persistent=False)
        self._infer_lora_rank = 0

    @torch.no_grad()
    def prepare_lora_infer_weights(self) -> None:
        """Pack the five KDA LoRA A projections for single-adapter inference."""

        projections = (self.q_proj, self.k_proj, self.v_proj, self.f_proj, self.g_proj)
        slots = tuple(projection.lora_slot for projection in projections)
        if any(slot is None or not slot.enabled for slot in slots):
            self._infer_lora_A = self._infer_lora_A.new_empty(0)
            self._infer_lora_rank = 0
            return
        value = torch.cat(tuple(slot.lora_A for slot in slots), dim=0).contiguous()
        if (
            self._infer_lora_A.shape == value.shape
            and self._infer_lora_A.device == value.device
            and self._infer_lora_A.dtype == value.dtype
        ):
            self._infer_lora_A.copy_(value)
        else:
            self._infer_lora_A = value
        self._infer_lora_rank = slots[0].rank

    @torch.no_grad()
    def clear_lora_infer_weights(self) -> None:
        self._infer_lora_A = self._infer_lora_A.new_empty(0)
        self._infer_lora_rank = 0

    def _project_qkvfg(
        self, hidden_states: torch.Tensor, infer_meta: InferMeta | None
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        projections = (self.q_proj, self.k_proj, self.v_proj, self.f_proj, self.g_proj)
        slots = tuple(projection.lora_slot for projection in projections)
        use_packed_lora = (
            infer_meta is not None
            and self._infer_lora_A.numel() > 0
            and getattr(self.q_proj, "quantized_weight", None) is None
            and all(slot is not None and slot.enabled for slot in slots)
        )
        if not use_packed_lora:
            return tuple(projection(hidden_states) for projection in projections)

        packed_hidden = F.linear(hidden_states, self._infer_lora_A)
        lora_inputs = packed_hidden.split(self._infer_lora_rank, dim=-1)
        return tuple(
            areno_linear(hidden_states, projection.weight, projection.bias)
            + F.linear(lora_input, slot.lora_B) * slot.scale
            for projection, slot, lora_input in zip(projections, slots, lora_inputs, strict=True)
        )

    @torch._dynamo.disable
    def forward(
        self,
        hidden_states: torch.Tensor,
        position_ids: torch.Tensor,
        train_meta: TrainMeta | None,
        infer_meta: InferMeta | None,
    ) -> torch.Tensor:
        del position_ids
        hidden_states = hidden_states.to(dtype=projection_dtype(self.q_proj))
        q, k, v, f, gate = self._project_qkvfg(hidden_states, infer_meta)
        batch, seqlen = q.shape[:2]
        q = self._causal_conv(q, self.q_conv1d_weight, 0, train_meta, infer_meta)
        k = self._causal_conv(k, self.k_conv1d_weight, 1, train_meta, infer_meta)
        v = self._causal_conv(v, self.v_conv1d_weight, 2, train_meta, infer_meta)
        q = q.to(dtype=hidden_states.dtype)
        k = k.to(dtype=hidden_states.dtype)
        v = v.to(dtype=hidden_states.dtype)
        f = f.view(batch, seqlen, self.local_heads, self.head_dim)
        gate = gate.view(batch, seqlen, self.local_heads, self.head_dim)
        beta = self.b_proj(hidden_states).view(batch, seqlen, self.local_heads)
        q = q.view(batch, seqlen, self.local_heads, self.head_dim)
        k = k.view(batch, seqlen, self.local_heads, self.head_dim)
        v = v.view(batch, seqlen, self.local_heads, self.v_head_dim)
        if infer_meta is not None:
            out = self._forward_infer(q, k, v, f, beta, infer_meta)
        else:
            out = self._forward_train(q, k, v, f, beta, train_meta)
        out = _rmsnorm_sigmoid_gate(out, gate, self.o_norm_weight, self.eps)
        return self.o_proj(out.reshape(batch, seqlen, self.local_proj_dim).to(dtype=hidden_states.dtype))

    def _causal_conv(
        self,
        x: torch.Tensor,
        weight: torch.Tensor,
        cache_idx: int,
        train_meta: TrainMeta | None,
        infer_meta: InferMeta | None,
    ) -> torch.Tensor:
        if infer_meta is not None:
            return self._causal_conv_infer(x, weight, cache_idx, infer_meta)
        if train_meta is not None and train_meta.packed and train_meta.cu_seqlens is not None:
            if x.shape[0] != 1:
                raise ValueError("packed Bailing V3 KDA causal-conv expects flattened input with batch size 1")
            return _areno_packed_depthwise_causal_conv1d_silu_no_compile(x, weight, train_meta.cu_seqlens)
        _require_fla_gdn()
        return _fla_causal_conv1d_no_compile(x, weight=weight.squeeze(1), activation="silu")

    def _causal_conv_infer(
        self, x: torch.Tensor, weight: torch.Tensor, cache_idx: int, infer_meta: InferMeta
    ) -> torch.Tensor:
        if infer_meta.block_table is None:
            raise RuntimeError("Bailing V3 KDA inference requires block_table")
        if self.conv_cache.numel() == 0:
            raise RuntimeError("Bailing V3 KDA inference requires conv state cache")
        slots = _recurrent_cache_slots(infer_meta)
        if infer_meta.mode == "decode":
            current = x.reshape(-1, x.shape[-1])
            history = self.conv_cache.index_select(0, slots)[:, cache_idx].to(dtype=current.dtype)
            out = _areno_depthwise_causal_conv1d_silu_decode_no_compile(current, history, weight)
            window = torch.cat((history, current.unsqueeze(-1)), dim=-1)
            self.conv_cache[slots, cache_idx] = window[:, :, 1:].detach().to(dtype=self.conv_cache.dtype)
            return out.view(x.shape)
        if infer_meta.mode == "prefill":
            if infer_meta.cu_seqlens is None:
                raise RuntimeError("Bailing V3 KDA prefill requires cu_seqlens")
            return self._causal_conv_infer_prefill(x, weight, cache_idx, infer_meta.cu_seqlens, slots)
        raise ValueError(f"unsupported inference mode: {infer_meta.mode}")

    @torch._dynamo.disable
    def _causal_conv_infer_prefill(
        self,
        x: torch.Tensor,
        weight: torch.Tensor,
        cache_idx: int,
        cu_seqlens: torch.Tensor,
        slots: torch.Tensor,
    ) -> torch.Tensor:
        out = torch.empty_like(x)
        cu = cu_seqlens.to(device=x.device, dtype=torch.long)
        for idx, slot in enumerate(slots):
            start, end = int(cu[idx].item()), int(cu[idx + 1].item())
            segment = x[:, start:end]
            out[:, start:end] = _areno_depthwise_causal_conv1d_silu_no_compile(segment, weight)
            tail = segment.reshape(-1, x.shape[-1])[-(self.conv_kernel_size - 1) :]
            cache = torch.zeros(x.shape[-1], self.conv_kernel_size - 1, device=x.device, dtype=self.conv_cache.dtype)
            cache[:, -tail.shape[0] :] = tail.transpose(0, 1).to(dtype=self.conv_cache.dtype)
            self.conv_cache[slot, cache_idx] = cache
        return out

    def _forward_train(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        g: torch.Tensor,
        beta: torch.Tensor,
        train_meta: TrainMeta | None,
    ) -> torch.Tensor:
        cu = (
            train_meta.cu_seqlens.to(device=q.device, dtype=torch.long)
            if train_meta is not None and train_meta.packed and train_meta.cu_seqlens is not None
            else None
        )
        return self._forward_prefill(q, k, v, g, beta, cu, None, None, output_final_state=False)[0]

    def _forward_prefill(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        raw_gate: torch.Tensor,
        raw_beta: torch.Tensor,
        cu_seqlens: torch.Tensor | None,
        initial_state: torch.Tensor | None,
        state_indices: torch.Tensor | None,
        *,
        output_final_state: bool,
    ) -> tuple[torch.Tensor, torch.Tensor | None]:
        return areno_kda_chunk(
            q,
            k,
            v,
            raw_gate=raw_gate,
            beta=_areno_sigmoid_no_compile(raw_beta).to(dtype=q.dtype),
            initial_state=initial_state,
            state_indices=state_indices,
            output_final_state=output_final_state,
            scale=self.scale,
            cu_seqlens=cu_seqlens,
            a_log=self.A_log.float(),
            dt_bias=self.dt_bias.float(),
            lower_bound=float(self.kda_lower_bound)
            if self.kda_safe_gate and self.kda_lower_bound is not None
            else None,
            use_qk_l2norm_in_kernel=True,
        )

    def _forward_infer(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        f: torch.Tensor,
        beta: torch.Tensor,
        infer_meta: InferMeta,
    ) -> torch.Tensor:
        if infer_meta.block_table is None:
            raise RuntimeError("Bailing V3 KDA inference requires block_table")
        if self.state_cache.numel() == 0:
            raise RuntimeError("Bailing V3 KDA inference requires recurrent state cache")
        slots = _recurrent_cache_slots(infer_meta)
        initial_state = self.state_cache.index_select(0, slots).to(device=q.device)
        cu = (
            torch.arange(slots.numel() + 1, device=q.device, dtype=torch.long)
            if infer_meta.mode == "decode"
            else infer_meta.cu_seqlens.to(device=q.device, dtype=torch.long)
            if infer_meta.cu_seqlens is not None
            else None
        )
        if cu is None:
            raise RuntimeError("Bailing V3 KDA inference requires cu_seqlens")
        state_indices = torch.arange(slots.numel(), device=q.device, dtype=torch.long)
        if infer_meta.mode == "prefill":
            out, final_state = self._forward_prefill(
                q,
                k,
                v,
                f,
                beta,
                cu,
                initial_state,
                state_indices,
                output_final_state=True,
            )
            if final_state is None:
                raise RuntimeError("KDA prefill did not return final state")
            self.state_cache[slots] = final_state.detach().to(dtype=self.state_cache.dtype)
            return out
        beta = beta.to(dtype=q.dtype)
        out = areno_kda_recurrent_update(
            q=q,
            k=k,
            v=v,
            # SGLang's recurrent KDA kernel expects the raw gate as
            # [batch, tokens, heads * head_dim]. Keeping it 4D makes the
            # kernel interpret the head stride as the token stride, so every
            # packed sequence after the first reads gates from the wrong row.
            raw_gate=f.flatten(2),
            beta=beta,
            state=initial_state,
            state_indices=state_indices,
            scale=self.scale,
            cu_seqlens=cu,
            a_log=self.A_log.float(),
            dt_bias=self.dt_bias.float(),
            lower_bound=float(self.kda_lower_bound)
            if self.kda_safe_gate and self.kda_lower_bound is not None
            else None,
            use_qk_l2norm_in_kernel=True,
        )
        self.state_cache[slots] = initial_state.detach().to(dtype=self.state_cache.dtype)
        return out

    def set_state_cache(self, state_cache: torch.Tensor, conv_cache: torch.Tensor) -> None:
        self.state_cache = state_cache
        self.conv_cache = conv_cache

    def clear_kv_cache(self) -> None:
        self.state_cache = torch.tensor([])
        self.conv_cache = torch.tensor([])

    @torch.no_grad()
    def reset_kv_cache(self) -> None:
        if self.state_cache.numel() > 0:
            self.state_cache.zero_()
        if self.conv_cache.numel() > 0:
            self.conv_cache.zero_()


class BailingDecoderLayer(nn.Module):
    """One Bailing decoder layer: pre-norm attention (softmax or linear) +
    pre-norm MLP (dense or MoE).

    ``_is_softmax_layer`` decides which attention flavour this layer runs:
    every ``layer_group_size``-th layer (and the trailing tail) is softmax,
    the rest are linear. ``first_k_dense_replace`` controls how many leading
    layers use the dense SwiGLU MLP before MoE kicks in.
    """

    def __init__(self, config: ModelConfig, layer_idx: int):
        super().__init__()
        self.layer_idx = layer_idx
        self.attention_layer_type = "attention" if _is_softmax_layer(config, layer_idx) else "linear_attention"
        self.input_layernorm = RMSNorm(config.hidden_size, config.rms_norm_eps)
        self.post_attention_layernorm = RMSNorm(config.hidden_size, config.rms_norm_eps)
        self.attention = (
            BailingSoftmaxAttention(config, layer_idx)
            if self.attention_layer_type == "attention"
            else BailingKDAAttention(config, layer_idx)
        )
        # Dense MLP for the warmup layers, sparse MoE for the rest.
        self.mlp = (
            BailingSparseMoeBlock(config, layer_idx - config.first_k_dense_replace)
            if config.num_experts is not None and layer_idx >= config.first_k_dense_replace
            else BailingDenseMLP(config, config.intermediate_size)
        )

    def _attention_block(
        self,
        hidden_states: torch.Tensor,
        position_ids: torch.Tensor,
        train_meta: TrainMeta | None,
        infer_meta: InferMeta | None,
    ) -> torch.Tensor:
        return self.attention(self.input_layernorm(hidden_states), position_ids, train_meta, infer_meta)

    def _dense_mlp_block(self, hidden_states: torch.Tensor) -> torch.Tensor:
        return self.mlp(self.post_attention_layernorm(hidden_states))

    def forward(
        self,
        hidden_states: torch.Tensor,
        position_ids: torch.Tensor,
        train_meta: TrainMeta | None,
        infer_meta: InferMeta | None,
    ) -> torch.Tensor:
        # Checkpoint attention for every Ling/Bailing V3 layer. Sparse MoE
        # routing remains outside recomputation so its load counters are not
        # accumulated twice and rollout-replayed routes stay authoritative.
        residual = hidden_states
        hidden_states = residual + checkpoint_layer(
            self._attention_block,
            hidden_states,
            position_ids,
            train_meta,
            infer_meta,
            train_meta=train_meta,
            infer_meta=infer_meta,
        )
        residual = hidden_states
        if isinstance(self.mlp, BailingSparseMoeBlock):
            mlp_input = self.post_attention_layernorm(hidden_states)
            num_padding_tokens = train_meta.num_padding_tokens if train_meta is not None else 0
            if not should_checkpoint_layer(train_meta, infer_meta):
                return residual + self.mlp(mlp_input, num_padding_tokens)
            topk_idx, topk_weight = self.mlp.route(mlp_input, num_padding_tokens)
            return residual + checkpoint_layer(
                self.mlp.forward_with_routes,
                mlp_input,
                topk_idx,
                topk_weight,
                train_meta=train_meta,
                infer_meta=infer_meta,
            )
        return residual + checkpoint_layer(
            self._dense_mlp_block,
            hidden_states,
            train_meta=train_meta,
            infer_meta=infer_meta,
        )


class BailingMoeV3ForCausalLM(nn.Module):
    """Top-level Bailing-MoE V3 causal LM."""

    def __init__(self, config: ModelConfig):
        super().__init__()
        self.config = config
        self.word_embeddings = VocabParallelEmbedding(config.vocab_size, config.hidden_size, dtype=config.dtype)
        self.layers = nn.ModuleList([BailingDecoderLayer(config, i) for i in range(config.num_hidden_layers)])
        self.norm = RMSNorm(config.hidden_size, config.rms_norm_eps)
        # Bailing V3 checkpoints use an untied fp32 LM head. Keep the logits
        # projection in fp32 to match the reference implementation and avoid
        # bf16 overflow in the vocab softmax path.
        lm_head_dtype = torch.float32 if not config.tie_word_embeddings else config.dtype
        self.lm_head = VocabParallelLMHead(config.hidden_size, config.vocab_size, dtype=lm_head_dtype)

    def forward(
        self,
        input_ids: torch.Tensor,
        position_ids: torch.Tensor | None = None,
        train_meta: TrainMeta | None = None,
        infer_meta: InferMeta | None = None,
    ) -> CausalLMOutput:
        if position_ids is None:
            position_ids = torch.arange(input_ids.shape[1], device=input_ids.device).unsqueeze(0).expand_as(input_ids)
        hidden_states = self.word_embeddings(input_ids)
        use_sequence_parallel = bool(train_meta is not None and train_meta.sequence_parallel)
        if use_sequence_parallel:
            # SP shards the sequence dim before entering the layer stack.
            hidden_states = scatter_to_sequence_parallel_region(hidden_states)
        with sequence_parallel_region(use_sequence_parallel):
            for layer in self.layers:
                hidden_states = layer(hidden_states, position_ids, train_meta, infer_meta)
            hidden_states = self.norm(hidden_states)
            logits_input = hidden_states
            if self.lm_head.weight.dtype == torch.float32:
                logits_input = hidden_states.float()
            return CausalLMOutput(logits_shard=self.lm_head(logits_input), hidden_states=hidden_states)

    def set_kv_caches(
        self, kv_caches: list[tuple[torch.Tensor, torch.Tensor]], *, num_slots: int | None = None
    ) -> None:
        """Bind per-softmax-layer KV caches and pre-allocate per-linear-layer
        recurrent state cache.

        ``kv_caches`` lists KV pairs *only* for softmax layers (in order of
        appearance); linear layers get a fresh zero state of shape
        ``[num_slots, heads, head_dim, head_dim]`` sized from the first KV
        cache when ``num_slots`` is not provided explicitly.
        """
        device = kv_caches[0][0].device if kv_caches else next(self.parameters()).device
        num_slots = int(num_slots) if num_slots is not None else (int(kv_caches[0][0].shape[0]) if kv_caches else 1)
        softmax_idx = 0
        for layer in self.layers:
            if isinstance(layer.attention, BailingSoftmaxAttention):
                layer.attention.set_kv_cache(*kv_caches[softmax_idx])
                softmax_idx += 1
            elif isinstance(layer.attention, BailingKDAAttention):
                state = torch.zeros(
                    num_slots,
                    layer.attention.local_heads,
                    layer.attention.head_dim,
                    layer.attention.v_head_dim,
                    device=device,
                    dtype=torch.float32,
                )
                conv_state = torch.zeros(
                    num_slots,
                    3,
                    layer.attention.local_proj_dim,
                    layer.attention.conv_kernel_size - 1,
                    device=device,
                    dtype=torch.float32,
                )
                layer.attention.set_state_cache(state, conv_state)

    @torch.no_grad()
    def prepare_infer_weights(self) -> None:
        """Prepare KDA LoRA and fused-MoE inference views."""
        for layer in self.layers:
            if isinstance(layer.attention, BailingKDAAttention):
                layer.attention.prepare_lora_infer_weights()
            if isinstance(layer.mlp, BailingSparseMoeBlock):
                layer.mlp.prepare_infer_weights()

    @torch.no_grad()
    def clear_infer_weights(self) -> None:
        """Drop KDA LoRA and fused-MoE inference views before training."""
        for layer in self.layers:
            if isinstance(layer.attention, BailingKDAAttention):
                layer.attention.clear_lora_infer_weights()
            if isinstance(layer.mlp, BailingSparseMoeBlock):
                layer.mlp.clear_infer_weights()

    @torch.no_grad()
    def offload_train_weights(self) -> None:
        for layer in self.layers:
            if isinstance(layer.mlp, BailingSparseMoeBlock):
                layer.mlp.experts.offload_to_cpu()

    @torch.no_grad()
    def onload_train_weights(self, device: torch.device) -> None:
        for layer in self.layers:
            if isinstance(layer.mlp, BailingSparseMoeBlock):
                layer.mlp.experts.onload_to_device(device)

    @torch.no_grad()
    def finalize_router_expert_bias(self, tp_group, dp_group) -> None:
        """Apply the per-step router-bias update on every MoE layer."""
        for layer in self.layers:
            if isinstance(layer.mlp, BailingSparseMoeBlock):
                layer.mlp.gate.finalize_expert_bias(tp_group, dp_group)

    def allocate_kv_caches(
        self, num_blocks: int, block_size: int, device: torch.device
    ) -> list[tuple[torch.Tensor, torch.Tensor]]:
        """Allocate paged KV caches — only for softmax-attention layers."""
        caches = []
        for layer in self.layers:
            if not isinstance(layer.attention, BailingSoftmaxAttention):
                continue
            k_cache = torch.empty(
                num_blocks,
                block_size,
                layer.attention.local_kv_heads,
                layer.attention.head_dim,
                device=device,
                dtype=self.config.dtype,
            )
            v_cache = torch.empty(
                num_blocks,
                block_size,
                layer.attention.local_kv_heads,
                layer.attention.head_dim,
                device=device,
                dtype=self.config.dtype,
            )
            caches.append((k_cache, v_cache))
        return caches

    def clear_kv_caches(self) -> None:
        for layer in self.layers:
            layer.attention.clear_kv_cache()

    @torch.no_grad()
    def reset_kv_caches(self) -> None:
        for layer in self.layers:
            layer.attention.reset_kv_cache()

    @torch.no_grad()
    def reset_recurrent_cache_slots(self, slots: torch.Tensor) -> None:
        """Clear recurrent state before a released inference slot is reused."""

        slots = slots.to(device=next(self.parameters()).device, dtype=torch.long)
        for layer in self.layers:
            attn = layer.attention
            if isinstance(attn, (BailingLinearAttention, BailingKDAAttention)) and attn.state_cache.numel() > 0:
                attn.state_cache.index_fill_(0, slots, 0)
            if isinstance(attn, BailingKDAAttention) and attn.conv_cache.numel() > 0:
                attn.conv_cache.index_fill_(0, slots, 0)

    @torch.no_grad()
    def offload_kv_caches(self) -> None:
        for layer in self.layers:
            attn = layer.attention
            if isinstance(attn, BailingSoftmaxAttention):
                if attn.k_cache.numel() > 0:
                    attn.k_cache = attn.k_cache.to(device="cpu")
                if attn.v_cache.numel() > 0:
                    attn.v_cache = attn.v_cache.to(device="cpu")
                attn.infer_backend = None
            elif isinstance(attn, BailingKDAAttention):
                if attn.state_cache.numel() > 0:
                    attn.state_cache = attn.state_cache.to(device="cpu")
                if attn.conv_cache.numel() > 0:
                    attn.conv_cache = attn.conv_cache.to(device="cpu")

    @torch.no_grad()
    def onload_kv_caches(self, device: torch.device) -> bool:
        found = False
        for layer in self.layers:
            attn = layer.attention
            if isinstance(attn, BailingSoftmaxAttention):
                if attn.k_cache.numel() > 0:
                    found = True
                    if attn.k_cache.device != device:
                        attn.k_cache = attn.k_cache.to(device=device)
                if attn.v_cache.numel() > 0:
                    found = True
                    if attn.v_cache.device != device:
                        attn.v_cache = attn.v_cache.to(device=device)
            elif isinstance(attn, BailingKDAAttention):
                if attn.state_cache.numel() > 0:
                    found = True
                    if attn.state_cache.device != device:
                        attn.state_cache = attn.state_cache.to(device=device)
                if attn.conv_cache.numel() > 0:
                    found = True
                    if attn.conv_cache.device != device:
                        attn.conv_cache = attn.conv_cache.to(device=device)
        return found


class BailingMoeV3Adapter(ModelAdapter):
    """Model adapter binding HF Bailing-MoE V3 checkpoints to the areno runtime."""

    name = "bailing_moe_v3"

    def match_hf_config(self, hf_config: dict[str, Any]) -> bool:
        architectures = hf_config.get("architectures") or []
        model_type = str(hf_config.get("model_type", "")).lower()
        return "BailingMoeV3ForCausalLM" in architectures or model_type == "bailing_hybrid"

    def config_from_hf(self, hf_config: dict[str, Any]) -> ModelConfig:
        """Build a ``ModelConfig`` from a Bailing HF config dict.

        Bailing uses several alternate key spellings (SGLang lineage); we
        accept either ``num_experts``/``n_routed_experts``, ``n_group``/
        ``moe_router_num_groups``, ``score_function``/``scoring_func`` etc.
        and validate that the routing setup matches what ``BailingGate``
        actually implements (sigmoid scoring, expert bias enabled, top-k
        renormalization on).
        """
        dtype = _parse_dtype(hf_config.get("torch_dtype") or hf_config.get("dtype"))
        num_heads = int(hf_config["num_attention_heads"])
        head_dim = int(hf_config.get("head_dim", hf_config["hidden_size"] // num_heads))
        rotary_dim = int(hf_config.get("rotary_dim", hf_config.get("qk_rope_head_dim", head_dim)))
        num_experts = hf_config.get("num_experts", hf_config.get("n_routed_experts"))
        moe_intermediate_size = int(hf_config.get("moe_intermediate_size", hf_config.get("intermediate_size", 0)))
        num_experts_per_tok = int(hf_config.get("num_experts_per_tok", hf_config.get("moe_router_topk", 1)))
        n_group = int(hf_config.get("n_group", hf_config.get("moe_router_num_groups", 1)))
        topk_group = int(hf_config.get("topk_group", hf_config.get("moe_router_group_topk", 1)))
        routed_scaling_factor = float(
            hf_config.get("routed_scaling_factor", hf_config.get("moe_router_topk_scaling_factor", 1.0))
        )
        shared_size = hf_config.get("moe_shared_expert_intermediate_size")
        num_shared_experts = hf_config.get("num_shared_experts")
        if shared_size is not None and num_shared_experts is None:
            # Derive shared-expert count from total intermediate size when only
            # the aggregate is given.
            num_shared_experts = max(1, int(shared_size) // max(1, moe_intermediate_size))
        linear_backend = str(hf_config.get("linear_backend", "seg_la")).lower()
        score_function = str(
            hf_config.get(
                "score_function", hf_config.get("scoring_func", hf_config.get("moe_router_score_function", "sigmoid"))
            )
        ).lower()
        topk_method = str(hf_config.get("topk_method", "noaux_tc")).lower()
        moe_router_enable_expert_bias = _parse_bool(hf_config.get("moe_router_enable_expert_bias"), True)
        norm_topk_prob = _parse_bool(hf_config.get("norm_topk_prob"), True)
        moe_router_dtype = _parse_dtype(hf_config.get("moe_router_dtype") or "fp32")
        if score_function != "sigmoid":
            raise ValueError(f"BailingMoeV3 only supports score_function='sigmoid', got {score_function!r}")
        if not moe_router_enable_expert_bias:
            raise ValueError("BailingMoeV3 requires moe_router_enable_expert_bias=True to match biased grouped topk")
        if not norm_topk_prob:
            raise ValueError("BailingMoeV3 requires norm_topk_prob=True to match top-k renormalization")
        if topk_method not in {"noaux_tc", "group_limited_greedy"}:
            raise ValueError(f"unsupported BailingMoeV3 topk_method={topk_method!r}")
        return ModelConfig(
            model_type=self.name,
            vocab_size=int(hf_config["vocab_size"]),
            hidden_size=int(hf_config["hidden_size"]),
            intermediate_size=int(hf_config["intermediate_size"]),
            num_hidden_layers=int(hf_config["num_hidden_layers"]),
            num_attention_heads=num_heads,
            num_key_value_heads=int(hf_config.get("num_key_value_heads", num_heads)),
            head_dim=head_dim,
            rms_norm_eps=float(hf_config.get("rms_norm_eps", 1e-6)),
            rope_theta=float(hf_config.get("rope_theta", hf_config.get("rotary_base", 10000.0))),
            max_position_embeddings=int(hf_config.get("max_position_embeddings", 4096)),
            tie_word_embeddings=_parse_bool(hf_config.get("tie_word_embeddings"), False),
            qkv_bias=_parse_bool(hf_config.get("use_qkv_bias", hf_config.get("qkv_bias")), False),
            qk_norm=_parse_bool(hf_config.get("use_qk_norm"), True),
            dtype=dtype,
            hidden_act=str(hf_config.get("hidden_act", "silu")),
            use_bias=_parse_bool(hf_config.get("use_bias"), False),
            layer_group_size=int(hf_config.get("layer_group_size", 1)),
            partial_rotary_factor=float(hf_config.get("partial_rotary_factor", rotary_dim / head_dim)),
            num_experts=num_experts,
            num_experts_per_tok=num_experts_per_tok,
            n_group=n_group,
            topk_group=topk_group,
            routed_scaling_factor=routed_scaling_factor,
            first_k_dense_replace=int(hf_config.get("first_k_dense_replace", 0)),
            moe_intermediate_size=moe_intermediate_size,
            num_shared_experts=num_shared_experts,
            moe_router_enable_expert_bias=moe_router_enable_expert_bias,
            norm_topk_prob=norm_topk_prob,
            moe_router_dtype=moe_router_dtype,
            score_function=score_function,
            topk_method=topk_method,
            group_norm_size=int(
                hf_config.get(
                    "group_norm_size", hf_config.get("linear_attn_norm_group_size", hf_config.get("head_dim", 128))
                )
            ),
            num_nextn_predict_layers=int(hf_config.get("num_nextn_predict_layers", 0)),
            mtp_loss_scaling_factor=float(hf_config.get("mtp_loss_scaling_factor", 0.0)),
            qk_nope_head_dim=int(hf_config.get("qk_nope_head_dim", head_dim)),
            qk_rope_head_dim=int(hf_config.get("qk_rope_head_dim", rotary_dim)),
            v_head_dim=int(hf_config.get("v_head_dim", head_dim)),
            q_lora_rank=hf_config.get("q_lora_rank"),
            kv_lora_rank=hf_config.get("kv_lora_rank"),
            kda_safe_gate=_parse_bool(hf_config.get("kda_safe_gate"), False),
            kda_lower_bound=(
                float(hf_config["kda_lower_bound"]) if hf_config.get("kda_lower_bound") is not None else None
            ),
            no_kda_lora=_parse_bool(hf_config.get("no_kda_lora"), False),
            linear_backend=linear_backend,
            linear_scale=linear_backend == "minimax",
            linear_silu=_parse_bool(hf_config.get("use_linear_silu", hf_config.get("linear_silu")), False),
            attn_output_gate=str(hf_config.get("gated_attention_proj_granularity_type", "")).lower() == "head_wise",
            linear_conv_kernel_dim=int(hf_config.get("short_conv_kernel_size", 4)),
            linear_key_head_dim=head_dim,
            linear_value_head_dim=int(hf_config.get("v_head_dim", head_dim)),
            linear_num_key_heads=num_heads,
            linear_num_value_heads=num_heads,
            sequence_parallel=_parse_bool(hf_config.get("sequence_parallel"), True),
            moe_router_bias_update_rate=float(hf_config.get("moe_router_bias_update_rate", 0.0)),
        )

    def build(self, config: ModelConfig) -> nn.Module:
        return BailingMoeV3ForCausalLM(config)

    @torch.no_grad()
    def load_weights(self, model: nn.Module, model_path: str | Path) -> None:
        if not isinstance(model, BailingMoeV3ForCausalLM):
            raise TypeError(f"BailingMoeV3Adapter cannot load weights into {type(model)!r}")
        load_checkpoint_weights(model, model_path, CHECKPOINT_SPEC)

    @torch.no_grad()
    def save_weights(self, model: nn.Module, output_path: str | Path, source_path: str | Path | None) -> str | None:
        if not isinstance(model, BailingMoeV3ForCausalLM):
            raise TypeError(f"BailingMoeV3Adapter cannot save weights from {type(model)!r}")
        return save_checkpoint_weights(model, output_path, source_path, CHECKPOINT_SPEC)

    def build_policy_plan(self, model: nn.Module):
        return build_checkpoint_policy_plan(model, CHECKPOINT_SPEC)


def _is_softmax_layer(config: ModelConfig, layer_idx: int) -> bool:
    """Return True iff this layer should run softmax attention.

    Bailing groups layers into chunks of ``layer_group_size``: the last layer
    of each group is softmax, the rest are linear. Any trailing layers that
    don't fit a full group (when num_hidden_layers isn't divisible by
    layer_group_size) are also forced to softmax so attention always anchors
    the sequence end.
    """
    return (
        (layer_idx + 1) % config.layer_group_size == 0
        or layer_idx >= config.num_hidden_layers // config.layer_group_size * config.layer_group_size
    )


@torch._dynamo.disable
def _rmsnorm_sigmoid_gate(x: torch.Tensor, gate: torch.Tensor, weight: torch.Tensor, eps: float) -> torch.Tensor:
    """Apply per-head RMSNorm followed by a sigmoid output gate.

    This matches SGLang's ``FusedRMSNormGated(head_dim, activation="sigmoid")``
    for Bailing V3 KDA, where the same ``head_dim`` scale is shared by every
    local attention head.
    """

    inv_rms = torch.rsqrt(x.float().pow(2).mean(dim=-1, keepdim=True) + float(eps))
    return (
        (x * inv_rms.to(dtype=x.dtype))
        * weight.to(device=x.device, dtype=x.dtype).view(1, 1, 1, -1)
        * torch.sigmoid(gate.float()).to(dtype=x.dtype)
    )


def _build_slope_tensor(
    local_heads: int,
    total_heads: int,
    layer_idx: int,
    num_hidden_layers: int,
    rank: int,
    world_size: int,
) -> torch.Tensor:
    """Build the ALiBi-style decay slopes for one rank's local heads.

    The slope table follows the standard ALiBi recipe (geometric sequence
    starting at ``2^(-2^(-(log2(n)-3)))``), with a small per-layer linear
    decay so deeper layers attenuate slightly more slowly. The slice for
    this rank is the standard TP shard of the full per-head table.
    """

    def get_slopes(n: int) -> list[float]:
        def get_slopes_power_of_2(m: int) -> list[float]:
            start = 2 ** (-(2 ** -(math.log2(m) - 3)))
            return [start * start**i for i in range(m)]

        if math.log2(n).is_integer():
            return get_slopes_power_of_2(n)
        # Non-power-of-two head counts: take the next-smaller power-of-two
        # slopes and interleave the doubled sequence to fill the rest.
        closest_power_of_2 = 2 ** math.floor(math.log2(n))
        return (
            get_slopes_power_of_2(closest_power_of_2)
            + get_slopes(2 * closest_power_of_2)[0::2][: n - closest_power_of_2]
        )

    if total_heads != local_heads * world_size:
        raise ValueError(f"total_heads={total_heads} must equal local_heads * world_size={local_heads * world_size}")
    start, end = _shard_range(total_heads, rank, world_size)
    # Layer scaling: deeper layers get a slightly smaller multiplier; the
    # +1e-5 floor keeps the zero-layer single-layer case finite.
    layer_scale = 1 + 1e-5 if num_hidden_layers <= 1 else 1 - layer_idx / (num_hidden_layers - 1) + 1e-5
    return torch.tensor(get_slopes(total_heads)[start:end], dtype=torch.float32) * layer_scale
