"""Per-rank worker process for the areno TP/DP engine.

Each `ArenoWorker` owns one tensor-parallel shard of the model on a single
device and drives the four lifecycle phases of an RL step:

* rollout (prefill + paged-KV decode);
* reference / critic / reward scoring via swap-in `WorkerRole`s;
* training step (FP32 master weights, packed or padded);
* KV-cache lifecycle (allocate, reset, scratch block, CUDA-graph capture)
  and weight onload/offload between train and infer states.

The engine driver dispatches `Command` objects to `handle()`, which fans out
to the matching public method.
"""

from __future__ import annotations

import queue

import torch
import torch.distributed as dist

from areno import _configure_torch_runtime
from areno.adapters import initialize_lora
from areno.adapters.peft import export_peft_adapter, load_peft_adapter
from areno.api.backend.cuda.roles import RoleManager, WorkerRole
from areno.engine.checkpoints.training_state import load_training_state, save_training_state
from areno.engine.config import EngineConfig
from areno.engine.data import RolloutOutput
from areno.engine.data.sampling import _truncate_generated
from areno.engine.inference import InferCacheSpec, InferenceManager
from areno.engine.modeling import (
    build_model_on_device,
    build_optimizer,
    configure_multimodal_training,
    mark_galore_vocabulary_parameters,
    param_grad,
)
from areno.engine.parallel.context import get_tp_context
from areno.engine.policy_sync import policy_plan_metadata, transfer_policy_weights
from areno.engine.protocol import (
    Command,
    ExportAdapterPayload,
    Op,
    PolicySyncPayload,
    RolloutCacheProbePayload,
    RolloutPayload,
    SaveCheckpointPayload,
    WorkerResult,
)
from areno.engine.runtime.common import pad_rollout_rows
from areno.engine.runtime.decode_graph import DecodeGraph
from areno.engine.runtime.device import accelerator_module
from areno.engine.runtime.rollout import _empty_rollout
from areno.engine.training import TrainingManager
from areno.models.registry import load_model_weights, save_model_weights


class ArenoWorker:
    """Single-rank executor for model work.

    The worker owns exactly one model shard and one optimizer shard. Before
    rollout it prepares inference weights and may offload training-only weights;
    before training it reloads the authoritative train weights for backward and
    optimizer updates.
    """

    def __init__(self, config: EngineConfig):
        _configure_torch_runtime()
        self.config = config
        ctx = get_tp_context()
        self.device = ctx.device
        # Build the actor model directly on the shard's device, then wrap in
        # torch.compile so subsequent forward calls use the compiled graph.
        self.model = build_model_on_device(config, self.device)
        if config.model_path is not None and not config.dummy_load:
            load_model_weights(self.model, config.model, config.model_path)
        configure_multimodal_training(self.model, config.optimizer, trainable=config.role == "train")
        self.adapter_registry = (
            initialize_lora(self.model, config.lora, seed=config.lora_seed) if config.lora is not None else None
        )
        if config.lora is not None and config.lora.qlora:
            from areno.adapters.qlora import initialize_qlora

            if self.device.type != "cuda":
                raise ValueError("QLoRA requires CUDA")
            initialize_qlora(self.model)
        if config.runtime.compile_model:
            self.model = torch.compile(self.model)
        if self.adapter_registry is not None and config.lora.adapter_path is not None:
            load_peft_adapter(self.adapter_registry, config.lora.adapter_path)
        opt = config.optimizer
        if opt.galore_rank is not None and opt.galore_exclude_vocab:
            mark_galore_vocabulary_parameters(self.model)
        optimizer_parameters = (
            self.adapter_registry.parameters() if self.adapter_registry is not None else self.model.parameters()
        )
        self.optimizer = build_optimizer(optimizer_parameters, opt, ctx) if config.role == "train" else None
        self.grad_clip_norm = opt.grad_clip_norm
        self.base_lr = opt.lr
        self.min_lr = opt.min_lr
        self.lr_decay_steps = opt.lr_decay_steps
        self.lr_warmup_steps = opt.lr_warmup_steps
        self.lr_decay_style = opt.lr_decay_style
        self.multimodal_lr_schedules = {
            "tower": {
                "lr": opt.lr if opt.multimodal_tower_lr is None else opt.multimodal_tower_lr,
                "min_lr": opt.min_lr if opt.multimodal_tower_min_lr is None else opt.multimodal_tower_min_lr,
                "decay_steps": (
                    opt.lr_decay_steps
                    if opt.multimodal_tower_lr_decay_steps is None
                    else opt.multimodal_tower_lr_decay_steps
                ),
                "decay_style": (
                    opt.lr_decay_style
                    if opt.multimodal_tower_lr_decay_style is None
                    else opt.multimodal_tower_lr_decay_style
                ),
            },
            "projector": {
                "lr": opt.lr if opt.multimodal_projector_lr is None else opt.multimodal_projector_lr,
                "min_lr": opt.min_lr if opt.multimodal_projector_min_lr is None else opt.multimodal_projector_min_lr,
                "decay_steps": (
                    opt.lr_decay_steps
                    if opt.multimodal_projector_lr_decay_steps is None
                    else opt.multimodal_projector_lr_decay_steps
                ),
                "decay_style": (
                    opt.lr_decay_style
                    if opt.multimodal_projector_lr_decay_style is None
                    else opt.multimodal_projector_lr_decay_style
                ),
            },
        }
        self._global_step = 0
        # Paged-KV state: refreshed when the rollout spec changes.
        self._infer_batch_size = 0  # max concurrent sequences supported
        self._infer_cache_blocks = 0  # num_blocks + 1 (extra is scratch)
        self._scratch_block = 0  # index of the scratch block (last slot)
        self._max_cache_len = 0
        self._max_blocks_per_seq = 0
        # Per-bucket captured decode CUDA graphs; buckets that OOM during
        # capture get tracked in `_skipped` and fall back to eager forward.
        self._decode_graphs: dict[int, DecodeGraph] = {}
        self._decode_graph_skipped_buckets: set[int] = set()
        self._decode_graph_init_attempted = False
        # 5-tuple summarising the active cache config; used to decide whether
        # a new `_init_infer_cache` call can reuse the existing allocation.
        self._infer_cache_spec: tuple[int, int, int, int, int] | None = None
        self._train_state_ready = False
        self._actor_on_device = True
        # Agentic rollouts issue one inference request per tool-call turn. Keep
        # rollout-only state resident for the whole explicit session and apply
        # drop-rollout-state once at ROLLOUT_SESSION_END, not after every turn.
        self._rollout_session_active = False
        self._rollout_session_infer_weights_ready = False
        self._current_request_ids: list[int | None] = []
        self._policy_sync_plan = None
        self._policy_sync_metadata = None
        self._policy_sync_buffer = None
        self._loaded_policy_version = 0
        self.inference = InferenceManager(self)
        self.roles = RoleManager(self)
        self.training = TrainingManager(self) if config.role == "train" else None
        if config.role == "train" and opt.resume_training_state:
            if config.model_path is None:
                raise ValueError("resume_training_state requires a checkpoint model_path")
            load_training_state(self, config.model_path)
        if config.role == "train" and config.train_loss_fn is None:
            raise ValueError("ArenoEngine requires train_loss_fn")
        self.loss_fn = config.train_loss_fn

    def handle(self, cmd: Command):
        """Dispatch a `Command` to the matching method on this worker."""
        if cmd.op is Op.ENSURE_ROLES:
            return self.ensure_roles(cmd.payload)
        if cmd.op is Op.INFER_ROLLOUT:
            return self.infer_rollout(cmd.payload)
        if cmd.op is Op.PROBE_ROLLOUT_CACHE:
            return self.probe_rollout_cache(cmd.payload)
        if cmd.op is Op.ROLLOUT_SESSION_BEGIN:
            return self.rollout_session_begin(cmd.payload)
        if cmd.op is Op.ROLLOUT_SESSION_SYNC:
            return self.rollout_session_sync(cmd.payload)
        if cmd.op is Op.ROLLOUT_SESSION_END:
            return self.rollout_session_end(cmd.payload)
        if cmd.op is Op.TRAIN:
            if self.training is None:
                raise RuntimeError("rollout workers cannot execute training operations")
            return self.train(cmd.payload)
        if cmd.op is Op.SCORE_LOGPROBS:
            return self.score_logprobs(cmd.payload)
        if cmd.op is Op.SCORE_VALUES:
            return self.score_values(cmd.payload)
        if cmd.op is Op.SCORE_REWARDS:
            return self.score_rewards(cmd.payload)
        if cmd.op is Op.TRAIN_VALUES:
            return self.train_values(cmd.payload)
        if cmd.op is Op.SAVE_CHECKPOINT:
            return self.save_checkpoint(cmd.payload)
        if cmd.op is Op.EXPORT_ADAPTER:
            return self.export_adapter(cmd.payload)
        if cmd.op is Op.POLICY_SYNC_PLAN:
            return self.policy_sync_plan(cmd.payload)
        if cmd.op is Op.POLICY_SYNC_PUBLISH:
            return self.publish_policy(cmd.payload)
        if cmd.op is Op.POLICY_SYNC_RECEIVE:
            return self.receive_policy(cmd.payload)
        raise ValueError(f"unsupported areno op: {cmd.op}")

    def policy_sync_plan(self, payload: None):
        """Build canonical metadata before paired cross-partition collectives."""

        del payload
        if self.config.role == "rollout":
            self._prepare_policy_receive()
        else:
            self._prepare_actor_onloaded()
            self.model.onload_train_weights(self.device)
        return policy_plan_metadata(self)

    def publish_policy(self, payload: PolicySyncPayload) -> dict[str, object]:
        """Publish authoritative train shards to the rollout partition."""

        self._prepare_actor_onloaded()
        self.model.onload_train_weights(self.device)
        return transfer_policy_weights(self, payload)

    @torch.no_grad()
    def receive_policy(self, payload: PolicySyncPayload) -> dict[str, object]:
        """Replace rollout shards in place and rebuild inference weights."""

        self._prepare_policy_receive()
        result = transfer_policy_weights(self, payload)
        self.model.prepare_infer_weights()
        self.model.offload_train_weights()
        self._train_state_ready = False
        self._loaded_policy_version = payload.version
        if self.adapter_registry is not None:
            self.adapter_registry.version = payload.version
        return result

    def _prepare_policy_receive(self) -> None:
        """Release stale derived rollout state before receiving live weights."""

        self._prepare_actor_onloaded()
        self._release_decode_graphs()
        self._infer_cache_spec = None
        self.model.clear_infer_weights()
        self.model.clear_kv_caches()
        self.model.onload_train_weights(self.device)

    def ensure_roles(self, payload: dict) -> None:
        """Delegate non-actor role lifecycle to `RoleManager`."""
        return self.roles.ensure_roles(payload)

    def infer_rollout(self, payload: dict, finished_callback=None, refill_callback=None) -> RolloutOutput | None:
        """Delegate rollout generation to `InferenceManager`."""
        output = self.inference.infer_rollout(
            payload,
            finished_callback=finished_callback,
            refill_callback=refill_callback,
        )
        if output is not None and self.adapter_registry is not None:
            output.adapter_version = self.adapter_registry.version
        return output

    def probe_rollout_cache(self, payload: RolloutCacheProbePayload) -> float:
        """Allocate rollout KV cache and capture decode graphs without decoding."""

        accelerator = accelerator_module(self.device)
        if accelerator is not None:
            accelerator.synchronize(self.device)
            accelerator.reset_peak_memory_stats(self.device)
        self.inference._init_infer_cache(
            InferCacheSpec(
                max_running_seqs=int(payload.max_running_seqs),
                max_cache_len=int(payload.max_cache_len),
                num_blocks=int(payload.num_blocks),
                block_size=int(payload.block_size),
                max_blocks_per_seq=int(payload.max_blocks_per_seq),
            )
        )
        if accelerator is None:
            return 0.0
        accelerator.synchronize(self.device)
        total = accelerator.get_device_properties(self.device).total_memory
        peak = accelerator.max_memory_allocated(self.device)
        return float(peak) / float(total)

    def run_rollout_command(self, command: Command) -> list[tuple[int | None, RolloutOutput | None]]:
        """Run one rollout command and continuously refill from queued requests."""

        ctx = get_tp_context()
        payload = command.payload
        counts = [len(payload.prompts_by_dp[ctx.dp_rank])]
        request_ids = [command.request_id]
        return self.run_continuous_rollout_payload(payload, request_ids, counts)

    def run_continuous_rollout_payload(
        self,
        payload: RolloutPayload,
        request_ids: list[int | None],
        counts: list[int],
    ) -> list[tuple[int | None, RolloutOutput | None]]:
        """Run one rollout and append compatible queued requests while decoding."""

        ctx = get_tp_context()
        request_rows = _rollout_request_rows(counts)
        finished = [False] * sum(counts)
        finish_reasons = [""] * sum(counts)
        sent: set[int] = set()

        def send_empty_requests() -> None:
            for request_idx, count in enumerate(counts):
                if request_idx in sent or count != 0:
                    continue
                request_id = request_ids[request_idx]
                self._result_queue.put(
                    (
                        self._rank,
                        WorkerResult(
                            ok=True,
                            payload=self._stamp_adapter_version(_empty_rollout()) if ctx.is_rank0 else None,
                            request_id=request_id,
                        ),
                    )
                )
                self._current_request_ids = [
                    pending_id for pending_id in self._current_request_ids if pending_id != request_id
                ]
                sent.add(request_idx)

        def send_finished(
            rows: torch.Tensor,
            generated: torch.Tensor,
            logprobs: torch.Tensor,
            response_lens: torch.Tensor,
            finish_reason: str,
            truncate_stop_token_ids: tuple[int, ...],
            routing_buffer: torch.Tensor | None = None,
        ) -> None:
            for row in rows.detach().cpu().tolist():
                row_idx = int(row)
                if 0 <= row_idx < len(finished):
                    finished[row_idx] = True
                    finish_reasons[row_idx] = finish_reason
            for request_idx, row_ids in enumerate(request_rows):
                if request_idx in sent or not all(finished[row] for row in row_ids):
                    continue
                result_payload = None
                if ctx.is_rank0:
                    result_payload = _build_rollout_from_tensor_row_ids(
                        payload.prompts_by_dp[ctx.dp_rank],
                        generated,
                        logprobs,
                        response_lens,
                        finish_reasons,
                        row_ids,
                        truncate_stop_token_ids,
                        routing_buffer,
                    )
                    result_payload = self._stamp_adapter_version(result_payload)
                request_id = request_ids[request_idx]
                self._result_queue.put(
                    (self._rank, WorkerResult(ok=True, payload=result_payload, request_id=request_id))
                )
                self._current_request_ids = [
                    pending_id for pending_id in self._current_request_ids if pending_id != request_id
                ]
                sent.add(request_idx)

        send_empty_requests()

        def refill_waiting(state) -> list[int]:
            new_prompt_indices: list[int] = []
            while True:
                cmd = self._next_refill_command()
                if cmd is None:
                    break
                if cmd.op is not Op.INFER_ROLLOUT or not _rollout_payloads_compatible(payload, cmd.payload):
                    self._deferred_commands.append(cmd)
                    break
                new_payload = cmd.payload
                new_request_ids = [cmd.request_id]
                new_counts = [len(new_payload.prompts_by_dp[ctx.dp_rank])]
                prompts = [list(prompt) for prompt in new_payload.prompts_by_dp[ctx.dp_rank]]
                prompt_features = (
                    list(new_payload.prompt_features_by_dp[ctx.dp_rank])
                    if new_payload.prompt_features_by_dp is not None
                    else None
                )
                prompt_indices = list(new_payload.prompt_indices_by_dp[ctx.dp_rank])
                request_ids.extend(new_request_ids)
                counts.extend(new_counts)
                request_rows.append([])
                self._current_request_ids = [*self._current_request_ids, *new_request_ids]
                if not prompts:
                    send_empty_requests()
                    continue
                appended_rows = state.append_prompts(prompts, prompt_features)
                if payload.prompts_by_dp[ctx.dp_rank] is not state.prompts:
                    payload.prompts_by_dp[ctx.dp_rank].extend(prompts)
                if prompt_features is not None:
                    if payload.prompt_features_by_dp is None:
                        payload.prompt_features_by_dp = [[None for _ in rows] for rows in payload.prompts_by_dp]
                    payload.prompt_features_by_dp[ctx.dp_rank].extend(prompt_features)
                payload.prompt_indices_by_dp[ctx.dp_rank].extend(prompt_indices)
                request_rows[-1] = appended_rows
                new_prompt_indices.extend(prompt_indices)
                finished.extend(False for _ in prompts)
                finish_reasons.extend("" for _ in prompts)
            return new_prompt_indices

        output = self.infer_rollout(payload, finished_callback=send_finished, refill_callback=refill_waiting)
        parts = _split_rollout_output_by_rows(output, request_rows)
        return [
            (request_id, part)
            for idx, (request_id, part) in enumerate(zip(request_ids, parts, strict=True))
            if idx not in sent
        ]

    def _stamp_adapter_version(self, output: RolloutOutput) -> RolloutOutput:
        adapter_registry = getattr(self, "adapter_registry", None)
        if adapter_registry is not None:
            output.adapter_version = adapter_registry.version
        return output

    def _next_refill_command(self) -> Command | None:
        """Fetch the next queued command consistently across TP ranks."""

        ctx = get_tp_context()
        cmd = None
        if ctx.is_rank0:
            try:
                cmd = self._cmd_queue.get_nowait()
            except queue.Empty:
                cmd = None
        command_header = self._broadcast_tp_command_header(cmd)
        if command_header is None:
            return None
        if not ctx.is_rank0:
            # Rank 0 picked the command that the TP group will execute next.
            # Sibling ranks may have stale deferred commands after prior async
            # returns, so they must consume until the same request id appears
            # instead of blindly taking the next local queue item.
            cmd = self._pop_matching_refill_command(*command_header)
        return cmd

    def _broadcast_tp_command_header(self, cmd: Command | None) -> tuple[Op, int | None] | None:
        """Broadcast the TP-rank0 refill command identity."""

        ctx = get_tp_context()
        request_id = -1
        op_value = -1
        has_command = 0
        if cmd is not None:
            has_command = 1
            op_value = int(cmd.op.value)
            request_id = -1 if cmd.request_id is None else int(cmd.request_id)
        header = torch.tensor([has_command, op_value, request_id], device=ctx.device, dtype=torch.long)
        if ctx.world_size > 1:
            dist.broadcast(header, src=ctx.tp_global_rank(0), group=ctx.group)
        if int(header[0].item()) == 0:
            return None
        return Op(int(header[1].item())), None if int(header[2].item()) < 0 else int(header[2].item())

    def _pop_matching_refill_command(self, op: Op, request_id: int | None) -> Command:
        """Consume local commands until the TP-rank0 command is found."""

        while True:
            cmd = self._cmd_queue.get(timeout=5.0)
            if cmd.op is op and cmd.request_id == request_id:
                return cmd
            self._deferred_commands.append(cmd)

    def rollout_session_begin(self, payload: None) -> None:
        """Prepare actor state for one or more rollout calls."""

        del payload
        self._prepare_actor_onloaded()
        self._rollout_session_active = True
        self._rollout_session_infer_weights_ready = False

    def rollout_session_sync(self, payload: None) -> None:
        """Synchronize TP ranks before agentic request-driven rollout starts."""

        del payload
        ctx = get_tp_context()
        accelerator = accelerator_module(self.device)
        if accelerator is not None:
            accelerator.synchronize(self.device)
        if ctx.group is not None:
            if ctx.device.type == "cuda":
                dist.barrier(
                    group=ctx.group,
                    device_ids=[ctx.device.index if ctx.device.index is not None else torch.cuda.current_device()],
                )
            else:
                dist.barrier(group=ctx.group)
        if accelerator is not None:
            accelerator.synchronize(self.device)

    def rollout_session_end(self, payload: None) -> None:
        """Finalize rollout state before scoring or training starts."""

        del payload
        try:
            if not self.config.runtime.keep_rollout_state:
                self._drop_rollout_hbm()
            if self.config.role == "train":
                self._prepare_for_train()
        finally:
            self._rollout_session_active = False
            self._rollout_session_infer_weights_ready = False

    def _should_drop_rollout_hbm_after_infer(self) -> bool:
        """Return whether one inference call owns the rollout-state teardown."""

        return not self.config.runtime.keep_rollout_state and not self._rollout_session_active

    def _can_reuse_rollout_session_infer_weights(self) -> bool:
        """Return whether actor inference weights are unchanged within this session."""

        return self._rollout_session_active and self._rollout_session_infer_weights_ready

    def _mark_rollout_session_infer_weights_ready(self) -> None:
        if self._rollout_session_active:
            self._rollout_session_infer_weights_ready = True

    def _prepare_for_train(self) -> None:
        """Ensure the actor is on-device and train weights are loaded."""
        self._prepare_actor_onloaded()
        self.model.onload_train_weights(self.device)
        self._train_state_ready = True

    def _prepare_actor_onloaded(self) -> None:
        """Move the actor model + optimizer state back to `device` if offloaded."""
        if self._actor_on_device:
            return
        with torch.inference_mode(False), torch.no_grad():
            self.model.to(self.device)
            self.model.onload_train_weights(self.device)
            if self.optimizer is not None:
                mode, directory, batch_size = self._optimizer_offload_options()
                if mode == "disk":
                    # Keep mmap-backed state out of HBM. The optimizer step loads
                    # only its current bucket after TrainingManager starts prefetch.
                    self.optimizer.configure_state_offload(
                        mode=mode,
                        directory=directory,
                        batch_size=batch_size,
                    )
                else:
                    self.optimizer.onload_state(self.device)
        self._actor_on_device = True

    def _prepare_actor_for_inference(self) -> None:
        """Materialize actor inference weights without retaining source expert tiles."""

        self._prepare_actor_onloaded()
        self.model.onload_train_weights(self.device)
        self.model.prepare_infer_weights()
        self.model.offload_train_weights()
        self._train_state_ready = False

    def _prepare_actor_offloaded(self) -> None:
        """Push the actor to CPU and drop all HBM state, including decode graphs.

        Decode graphs and the KV cache are tied to specific HBM allocations,
        so offloading invalidates them and a future rollout must re-init.
        """
        if not self._actor_on_device:
            return
        self._release_decode_graphs()
        self._infer_cache_spec = None
        self.model.clear_infer_weights()
        self.model.clear_kv_caches()
        self.model.offload_train_weights()
        self.model.to("cpu")
        if self.optimizer is not None:
            mode, directory, batch_size = self._optimizer_offload_options()
            # Swapping in an auxiliary role always evicts actor optimizer HBM.
            # An explicit disk policy must retain its persistent mmap files;
            # otherwise preserve the historical CPU offload behavior.
            if mode == "none":
                mode = "cpu"
            self.optimizer.offload_state(mode=mode, directory=directory, batch_size=batch_size)
        self._train_state_ready = False
        self._actor_on_device = False
        accelerator = accelerator_module(self.device)
        if accelerator is not None:
            accelerator.empty_cache()

    def _optimizer_offload_options(self) -> tuple[str, str | None, int]:
        """Return the configured actor optimizer residency policy."""

        mode = getattr(self.config.runtime, "optimizer_state_offload", "none")
        if isinstance(mode, bool):
            mode = "cpu" if mode else "none"
        directory = getattr(self.config.runtime, "optimizer_state_offload_dir", None)
        batch_size = int(getattr(self.config.runtime, "optimizer_state_offload_batch_size", 1))
        return str(mode), directory, batch_size

    def _release_decode_graphs(self) -> None:
        """Drop captured decode CUDA graphs and release their cached memory."""

        self._decode_graphs.clear()
        self._decode_graph_skipped_buckets.clear()
        self._decode_graph_init_attempted = False
        accelerator = accelerator_module(self.device)
        if accelerator is not None:
            accelerator.empty_cache()

    @torch.no_grad()
    def _drop_rollout_hbm(self) -> None:
        """Release rollout-only GPU state while keeping CPU-reloadable handles."""

        self._release_decode_graphs()
        self.model.clear_infer_weights()
        offload_kv = getattr(self.model, "offload_kv_caches", None)
        if offload_kv is not None:
            offload_kv()
        self._train_state_ready = False
        accelerator = accelerator_module(self.device)
        if accelerator is not None:
            accelerator.empty_cache()

    @torch.inference_mode()
    def score_logprobs(self, payload: dict) -> list[list[float]] | None:
        """Delegate logprob scoring to `RoleManager`."""
        return self.roles.score_logprobs(payload)

    @torch.inference_mode()
    def score_values(self, payload: dict) -> list[list[float]] | None:
        """Delegate value scoring to `RoleManager`."""
        return self.roles.score_values(payload)

    @torch.inference_mode()
    def score_rewards(self, payload: dict) -> list[float] | None:
        """Delegate reward scoring to `RoleManager`."""
        return self.roles.score_rewards(payload)

    def train_values(self, payload: dict) -> dict | None:
        """Delegate critic value training to `RoleManager`."""
        return self.roles.train_values(payload)

    def train(self, payload: dict) -> list[dict | None]:
        """Delegate actor training to `TrainingManager`."""
        if self.training is None:
            raise RuntimeError("rollout workers cannot execute training operations")
        return self.training.train(payload)

    def _sync_role_grads(self, role: WorkerRole) -> None:
        """Sync a role's gradients across DP and TP groups.

        All optimizer residency modes keep the original full-gradient DP
        synchronization path.
        TP-replicated value-head params (`role_tp_average=True`) get averaged
        across TP; TP-sharded params marked with `tp_grad_allreduce` get summed.
        """
        ctx = get_tp_context()
        if ctx.dp_size > 1:
            for param in role.parameters():
                grad = param_grad(param)
                if grad is None:
                    continue
                dist.all_reduce(grad, op=dist.ReduceOp.SUM, group=ctx.dp_group)
                grad.div_(ctx.dp_size)
        if ctx.world_size > 1:
            for param in role.parameters():
                grad = param_grad(param)
                if grad is None:
                    continue
                if bool(getattr(param, "role_tp_average", False)):
                    dist.all_reduce(grad, op=dist.ReduceOp.SUM, group=ctx.group)
                    grad.div_(ctx.world_size)
                elif bool(getattr(param, "tp_grad_allreduce", False)):
                    dist.all_reduce(grad, op=dist.ReduceOp.SUM, group=ctx.group)

    def save_checkpoint(self, payload: SaveCheckpointPayload) -> dict | None:
        """Persist the actor's weights to disk (rank 0 returns the resolved path)."""
        self._prepare_actor_onloaded()
        path = save_model_weights(self.model, self.config.model, payload.path, self.config.model_path)
        if path is not None and (
            self.config.optimizer.galore_rank is not None or self.config.optimizer.save_training_state
        ):
            save_training_state(self, path)
        return {"path": path} if path is not None else None

    def export_adapter(self, payload: ExportAdapterPayload) -> dict | None:
        """Write the native adapter in standard PEFT format."""

        if self.adapter_registry is None:
            raise RuntimeError("export_adapter requires native LoRA")
        self._prepare_actor_onloaded()
        path = export_peft_adapter(
            self.adapter_registry,
            payload.path,
            base_model_name_or_path=(self.config.base_model_name_or_path or self.config.model_path),
        )
        return {"path": path} if path is not None else None


def _rollout_payloads_compatible(first: RolloutPayload, other: RolloutPayload) -> bool:
    """Return whether two rollout payloads can share one InferenceBatchState."""

    if other.cancel_flags is not None:
        return False
    return (
        first.max_new_tokens == other.max_new_tokens
        and first.max_cache_len >= other.max_cache_len
        and first.max_blocks_per_seq >= other.max_blocks_per_seq
        and first.eos_token_id == other.eos_token_id
        and first.sampling_params == other.sampling_params
        and first.block_size == other.block_size
        and first.decode_progress_interval_s == other.decode_progress_interval_s
        and (first.prompt_features_by_dp is None) == (other.prompt_features_by_dp is None)
        and first.cancel_flags is None
        and other.cancel_flags is None
        and first.cancel_indices_by_dp is None
        and other.cancel_indices_by_dp is None
    )


def _split_rollout_output(output: RolloutOutput | None, counts: list[int]) -> list[RolloutOutput | None]:
    """Split a merged worker rollout back into per-request outputs."""

    if output is None:
        return [None for _ in counts]
    parts = []
    offset = 0
    for count in counts:
        end = offset + count
        parts.append(_slice_rollout_output(output, offset, end))
        offset = end
    return parts


def _split_rollout_output_by_rows(
    output: RolloutOutput | None, request_rows: list[list[int]]
) -> list[RolloutOutput | None]:
    """Split a merged worker rollout by explicit state row ids."""

    if output is None:
        return [None for _ in request_rows]
    return [_slice_rollout_output_rows(output, rows) for rows in request_rows]


def _rollout_request_rows(counts: list[int]) -> list[list[int]]:
    """Return explicit state row ids for each request."""

    rows = []
    offset = 0
    for count in counts:
        end = offset + count
        rows.append(list(range(offset, end)))
        offset = end
    return rows


def _rollout_ranges(counts: list[int]) -> list[tuple[int, int]]:
    """Return half-open row ranges for each request in the active rollout."""

    ranges = []
    offset = 0
    for count in counts:
        end = offset + count
        ranges.append((offset, end))
        offset = end
    return ranges


def _build_rollout_from_tensor_row_ids(
    prompts: list[list[int]],
    generated: torch.Tensor,
    logprobs: torch.Tensor,
    response_lens: torch.Tensor,
    finish_reasons: list[str],
    row_ids: list[int],
    truncate_stop_token_ids: tuple[int, ...],
    routing_buffer: torch.Tensor | None = None,
) -> RolloutOutput:
    """Build a RolloutOutput for non-contiguous completed tensor rows."""

    if not row_ids:
        return _empty_rollout()
    prompt_ids = [prompts[row] for row in row_ids]
    lengths = response_lens[row_ids].detach().cpu().tolist()
    generated_rows = [
        row[: int(length)] for row, length in zip(generated[row_ids].detach().cpu().tolist(), lengths, strict=True)
    ]
    response_ids, truncated_finish_reasons = _truncate_generated(generated_rows, truncate_stop_token_ids)
    finish_reason = [finish_reasons[row] or truncated_finish_reasons[idx] for idx, row in enumerate(row_ids)]
    logprob_rows_cpu = logprobs[row_ids].detach().cpu().tolist()
    logprob_rows = [
        torch.tensor(row[: len(response)], dtype=torch.float32)
        for row, response in zip(logprob_rows_cpu, response_ids, strict=True)
    ]
    routed_experts = _completed_routing_rows(prompt_ids, response_ids, row_ids, routing_buffer)
    input_ids, attention_mask, response_mask, padded_logprobs = pad_rollout_rows(prompt_ids, response_ids, logprob_rows)
    return RolloutOutput(
        prompt_ids=prompt_ids,
        response_ids=response_ids,
        input_ids=input_ids,
        attention_mask=attention_mask,
        response_mask=response_mask,
        logprobs=padded_logprobs,
        finish_reason=finish_reason,
        metrics=None,
        routed_experts=routed_experts,
    )


def _completed_routing_rows(
    prompt_ids: list[list[int]],
    response_ids: list[list[int]],
    row_ids: list[int],
    routing_buffer: torch.Tensor | None,
) -> list[torch.Tensor] | None:
    """Materialize completed R3 rows without delaying continuous-batch replies."""

    if routing_buffer is None:
        return None
    expected = [max(len(prompt) + len(response) - 1, 0) for prompt, response in zip(prompt_ids, response_ids)]
    max_expected = max(expected, default=0)
    row_index = torch.tensor(row_ids, device=routing_buffer.device, dtype=torch.long)
    materialized = routing_buffer.index_select(0, row_index)[:, :max_expected].cpu()
    return [materialized[row, :count].contiguous() for row, count in enumerate(expected)]


def _build_rollout_from_tensor_rows(
    prompts: list[list[int]],
    generated: torch.Tensor,
    logprobs: torch.Tensor,
    response_lens: torch.Tensor,
    finish_reasons: list[str],
    start: int,
    end: int,
    truncate_stop_token_ids: tuple[int, ...],
) -> RolloutOutput:
    """Build a RolloutOutput for completed tensor rows before the full batch ends."""

    if start == end:
        return _empty_rollout()
    prompt_ids = prompts[start:end]
    lengths = response_lens[start:end].detach().cpu().tolist()
    generated_rows = [
        row[: int(length)] for row, length in zip(generated[start:end].detach().cpu().tolist(), lengths, strict=True)
    ]
    response_ids, truncated_finish_reasons = _truncate_generated(generated_rows, truncate_stop_token_ids)
    finish_reason = [finish_reasons[idx] or truncated_finish_reasons[idx - start] for idx in range(start, end)]
    logprob_rows_cpu = logprobs[start:end].detach().cpu().tolist()
    logprob_rows = [
        torch.tensor(row[: len(response)], dtype=torch.float32)
        for row, response in zip(logprob_rows_cpu, response_ids, strict=True)
    ]
    input_ids, attention_mask, response_mask, padded_logprobs = pad_rollout_rows(prompt_ids, response_ids, logprob_rows)
    return RolloutOutput(
        prompt_ids=prompt_ids,
        response_ids=response_ids,
        input_ids=input_ids,
        attention_mask=attention_mask,
        response_mask=response_mask,
        logprobs=padded_logprobs,
        finish_reason=finish_reason,
        metrics=None,
    )


def _slice_rollout_output(output: RolloutOutput, start: int, end: int) -> RolloutOutput:
    """Build a RolloutOutput view for rows [start, end)."""

    if start == end:
        return _empty_rollout()
    prompt_ids = output.prompt_ids[start:end]
    response_ids = output.response_ids[start:end]
    finish_reason = output.finish_reason[start:end]
    logprob_rows = [output.logprobs[idx, : len(output.response_ids[idx])].detach().cpu() for idx in range(start, end)]
    input_ids, attention_mask, response_mask, logprobs = pad_rollout_rows(prompt_ids, response_ids, logprob_rows)
    return RolloutOutput(
        prompt_ids=prompt_ids,
        response_ids=response_ids,
        input_ids=input_ids,
        attention_mask=attention_mask,
        response_mask=response_mask,
        logprobs=logprobs,
        finish_reason=finish_reason,
        metrics=output.metrics,
        adapter_version=output.adapter_version,
        routed_experts=output.routed_experts[start:end] if output.routed_experts is not None else None,
    )


def _slice_rollout_output_rows(output: RolloutOutput, rows: list[int]) -> RolloutOutput:
    """Build a RolloutOutput view for explicit row ids."""

    if not rows:
        return _empty_rollout()
    prompt_ids = [output.prompt_ids[row] for row in rows]
    response_ids = [output.response_ids[row] for row in rows]
    finish_reason = [output.finish_reason[row] for row in rows]
    logprob_rows = [output.logprobs[row, : len(output.response_ids[row])].detach().cpu() for row in rows]
    input_ids, attention_mask, response_mask, logprobs = pad_rollout_rows(prompt_ids, response_ids, logprob_rows)
    return RolloutOutput(
        prompt_ids=prompt_ids,
        response_ids=response_ids,
        input_ids=input_ids,
        attention_mask=attention_mask,
        response_mask=response_mask,
        logprobs=logprobs,
        finish_reason=finish_reason,
        metrics=output.metrics,
        adapter_version=output.adapter_version,
        routed_experts=[output.routed_experts[row] for row in rows] if output.routed_experts is not None else None,
    )
