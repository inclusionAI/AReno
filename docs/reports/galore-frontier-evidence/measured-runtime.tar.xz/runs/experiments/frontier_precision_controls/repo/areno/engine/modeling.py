"""Shared model construction and optimizer helpers for worker components."""

from __future__ import annotations

from pathlib import Path

import torch

from areno.engine.config import EngineConfig
from areno.engine.optim import AdamW4bit, AdamW8bit, AdamWFP32Master
from areno.models.registry import build_model


def param_grad(param: torch.nn.Parameter) -> torch.Tensor | None:
    """Return `main_grad` when available, otherwise autograd `.grad`."""

    main_grad = getattr(param, "main_grad", None)
    if isinstance(main_grad, torch.Tensor):
        return main_grad
    return param.grad


def build_model_on_device(config: EngineConfig, device: torch.device) -> torch.nn.Module:
    """Construct the model directly on `device` under the configured dtype."""

    old_dtype = torch.get_default_dtype()
    try:
        torch.set_default_dtype(config.model.dtype)
        with torch.device(device), skip_torch_init(enabled=config.model_path is not None and not config.dummy_load):
            model = build_model(config.model)
        if config.dummy_load:
            _zero_model_parameters(model)
        return model
    finally:
        torch.set_default_dtype(old_dtype)


class skip_torch_init:
    """Temporarily replace expensive torch init functions with no-ops."""

    def __init__(self, enabled: bool):
        self.enabled = enabled
        self._saved = {}

    def __enter__(self):
        if not self.enabled:
            return self
        self._saved = {
            "kaiming_uniform_": torch.nn.init.kaiming_uniform_,
            "uniform_": torch.nn.init.uniform_,
            "normal_": torch.nn.init.normal_,
        }
        torch.nn.init.kaiming_uniform_ = _noop_init
        torch.nn.init.uniform_ = _noop_init
        torch.nn.init.normal_ = _noop_init
        return self

    def __exit__(self, _exc_type, _exc, _tb):
        for name, fn in self._saved.items():
            setattr(torch.nn.init, name, fn)


def _noop_init(tensor: torch.Tensor, *_args, **_kwargs) -> torch.Tensor:
    """Replacement for `torch.nn.init.*` that returns the tensor unchanged."""

    return tensor


def _zero_model_parameters(model: torch.nn.Module) -> None:
    """Initialize dummy-loaded models deterministically with finite zeros."""

    with torch.no_grad():
        for param in model.parameters():
            param.zero_()


def unwrap_model(model: torch.nn.Module) -> torch.nn.Module:
    """Recursively unwrap `torch.compile`'s `_orig_mod` indirection."""

    original = getattr(model, "_orig_mod", None)
    if original is None:
        return model
    return unwrap_model(original)


def canonical_model_path(path: str | None) -> str | None:
    """Resolve `path` to an absolute filesystem path for cache-key comparisons."""

    if path is None:
        return None
    try:
        return str(Path(path).resolve())
    except (OSError, RuntimeError):
        return str(path)


def build_optimizer(params, optimizer_config, ctx, *, lr: float | None = None):
    """Construct the configured DP-sharded optimizer implementation."""

    if optimizer_config.galore_rank is not None:
        from areno.engine.optim.galore import GaLoreAdamW

        if ctx.world_size != 1 or ctx.dp_size != 1:
            raise ValueError("GaLore currently supports single-GPU training only")
        return GaLoreAdamW(
            params,
            lr=optimizer_config.lr if lr is None else float(lr),
            betas=optimizer_config.betas,
            weight_decay=optimizer_config.weight_decay,
            rank=optimizer_config.galore_rank,
            update_proj_gap=optimizer_config.galore_update_proj_gap,
            scale=optimizer_config.galore_scale,
            projector_backend=optimizer_config.galore_projector_backend,
            projector_oversampling=optimizer_config.galore_projector_oversampling,
            projector_iterations=optimizer_config.galore_projector_iterations,
            projector_seed=optimizer_config.galore_projector_seed,
            projector_final_qr=optimizer_config.galore_projector_final_qr,
            compact_master=optimizer_config.galore_compact_master,
            tile_rows=optimizer_config.galore_tile_rows,
            release_gradients=optimizer_config.galore_release_gradients,
            fused_writeback=optimizer_config.galore_fused_writeback,
            transport_moments=optimizer_config.galore_transport_moments,
            exclude_vocab=optimizer_config.galore_exclude_vocab,
        )
    if optimizer_config.adam_4bit:
        optimizer_cls = AdamW4bit
    elif optimizer_config.adam_8bit:
        optimizer_cls = AdamW8bit
    else:
        optimizer_cls = AdamWFP32Master
    if optimizer_config.paged:
        from areno.engine.optim.paged import PagedAdamW4bit, PagedAdamW8bit, PagedAdamWFP32Master

        optimizer_cls = {AdamW4bit: PagedAdamW4bit, AdamW8bit: PagedAdamW8bit, AdamWFP32Master: PagedAdamWFP32Master}[
            optimizer_cls
        ]
    return optimizer_cls(
        params,
        lr=optimizer_config.lr if lr is None else float(lr),
        betas=optimizer_config.betas,
        weight_decay=optimizer_config.weight_decay,
        bucket_numel=optimizer_config.fp32_master_bucket_numel,
        dp_rank=ctx.dp_rank,
        dp_size=ctx.dp_size,
        dp_group=ctx.dp_group,
    )


def mark_galore_vocabulary_parameters(model: torch.nn.Module) -> None:
    """Mark actual input/output vocabulary owners without names or shape guesses."""
    from areno.engine.layers.vocab import VocabParallelEmbedding, VocabParallelLMHead

    for module in model.modules():
        if isinstance(module, (VocabParallelEmbedding, VocabParallelLMHead)):
            module.weight._areno_galore_vocab = True


def configure_multimodal_training(model: torch.nn.Module, optimizer_config, *, trainable: bool) -> None:
    """Apply optional model-defined media trainability and relative learning rates."""

    unwrapped = unwrap_model(model)
    configure = getattr(unwrapped, "configure_multimodal_training", None)
    requested = optimizer_config.unfreeze_multimodal_tower or optimizer_config.unfreeze_multimodal_projector
    if configure is None:
        if requested:
            raise ValueError(f"{type(unwrapped).__name__} does not expose configurable multimodal modules")
        return
    configure(
        unfreeze_tower=optimizer_config.unfreeze_multimodal_tower,
        unfreeze_projector=optimizer_config.unfreeze_multimodal_projector,
        tower_lr=optimizer_config.multimodal_tower_lr,
        projector_lr=optimizer_config.multimodal_projector_lr,
        base_lr=optimizer_config.lr,
        trainable=trainable,
    )
