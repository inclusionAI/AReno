"""Experimental model-owned AdamW writeback: round once after each update."""

import triton
import triton.language as tl


@triton.jit
def _write(P, D, FLAG, N: tl.constexpr, OFFSET: tl.constexpr, DECAY, STEP, BLOCK: tl.constexpr):
    index = tl.program_id(0) * BLOCK + tl.arange(0, BLOCK)
    mask = index < N
    weight = tl.load(P + OFFSET + index, mask, other=0).to(tl.float32)
    delta = tl.load(D + index, mask, other=0).to(tl.float32)
    updated = tl.fma(delta, STEP, weight * DECAY)
    invalid = mask & ((tl.abs(updated) == float("inf")) | (updated != updated))
    if tl.sum(invalid.to(tl.int32), 0) > 0:
        tl.atomic_or(FLAG, 1)
    tl.store(P + OFFSET + index, updated, mask)


def model_writeback(parameter, delta, offset, decay, step, invalid_flag):
    """FP32 product then FMA, followed by the parameter's single dtype cast."""
    delta = delta.contiguous()
    _write[(triton.cdiv(delta.numel(), 1024),)](
        parameter,
        delta,
        invalid_flag,
        delta.numel(),
        offset,
        decay,
        step,
        BLOCK=1024,
        enable_fp_fusion=False,
    )
