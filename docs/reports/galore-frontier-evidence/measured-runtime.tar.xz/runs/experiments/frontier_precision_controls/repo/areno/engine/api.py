"""User-facing Python API for the areno engine.

This module exposes :class:`ArenoEngine`, the entry point that callers use to
drive a local training and inference engine. The engine itself owns no model
weights; instead it spawns a :class:`TPCluster` of worker processes (one per
TP/DP rank) and dispatches commands to them.

High-level responsibilities:

* Spawn and tear down the worker cluster.
* Translate user inputs (``SamplingParams``, ``TrainerConfig``, prompt lists,
  data packs) into the on-the-wire ``Command`` protocol consumed by
  :mod:`areno.engine.worker`.
* Split inputs across data-parallel ranks and merge rank-0 outputs back into
  the simple single-process result shape returned to the caller.
* Expose the rollout/train/score/checkpoint operations as plain Python methods
  while hiding the underlying RPC-style ``call`` / fire-and-forget
  request-demux semantics.
"""

from __future__ import annotations

from collections.abc import Callable
from itertools import count
from typing import Any

import torch

from areno.adapters.config import LoraConfig
from areno.engine.checkpoints.io import resolve_model_path
from areno.engine.config import EngineConfig, OptimizerConfig, RuntimeConfig
from areno.engine.data import RolloutOutput, SamplingParams, TrainStats, to_cpu
from areno.engine.modeling import canonical_model_path
from areno.engine.protocol import (
    EnsureRolesPayload,
    ExportAdapterPayload,
    Op,
    RoleSpecPayload,
    RolloutCacheProbePayload,
    RolloutPayload,
    SaveCheckpointPayload,
    ScorePayload,
    TPCluster,
    TrainPayload,
    TrainValuesPayload,
)
from areno.engine.runtime.common import (
    dp_rank0_results,
    merge_metric_dicts,
    merge_train_stats,
    split_data_pack_by_dp,
    split_list_by_dp,
)
from areno.engine.runtime.decode_graph import ceil_div
from areno.engine.runtime.rollout import _build_rollout_from_rows, _merge_dp_rollouts_in_input_order, _merge_rollouts
from areno.engine.worker import ArenoWorker
from areno.models.registry import config_from_hf


def _merge_async_dp_rollouts(outputs: list[RolloutOutput | None], *, total_count: int) -> RolloutOutput:
    """Merge async DP results, allowing single-row requests to land on any DP."""

    non_empty = [output for output in outputs if output is not None and len(output.prompt_ids) > 0]
    if total_count == 1 and len(non_empty) == 1:
        return non_empty[0]
    try:
        return _merge_dp_rollouts_in_input_order(outputs, total_count=total_count)
    except RuntimeError as exc:
        row_counts = [0 if output is None else len(output.prompt_ids) for output in outputs]
        if sum(row_counts) == total_count:
            return _merge_rollouts(non_empty)
        raise RuntimeError(f"{exc}; async DP row_counts={row_counts} total_count={total_count}") from exc


def _merge_dp_rollouts_by_prompt_indices(
    outputs: list[RolloutOutput | None],
    prompt_indices_by_dp: list[list[int]],
    *,
    chunk_start: int,
    total_count: int,
) -> RolloutOutput:
    """Merge DP outputs by explicit prompt indices, allowing offset DP assignment."""

    if total_count == 0:
        return _merge_rollouts([])
    routed_experts = [] if any(output is not None and output.routed_experts is not None for output in outputs) else None
    rows: list[tuple[list[int], list[int], str, torch.Tensor, torch.Tensor | None] | None] = [
        None for _ in range(total_count)
    ]
    for dp_rank, output in enumerate(outputs):
        if output is None:
            continue
        indices = prompt_indices_by_dp[dp_rank]
        if len(indices) != len(output.prompt_ids):
            raise RuntimeError(
                f"DP rollout row count mismatch: dp_rank={dp_rank} indices={len(indices)} rows={len(output.prompt_ids)}"
            )
        for local_idx, original_idx in enumerate(indices):
            row_idx = int(original_idx) - chunk_start
            if row_idx < 0 or row_idx >= total_count:
                raise RuntimeError(f"DP rollout prompt index out of chunk range: original_idx={original_idx}")
            response = output.response_ids[local_idx]
            routes = None
            if routed_experts is not None:
                if output.routed_experts is None:
                    raise RuntimeError("routing replay is missing from one DP rollout shard")
                routes = output.routed_experts[local_idx]
            rows[row_idx] = (
                output.prompt_ids[local_idx],
                response,
                output.finish_reason[local_idx],
                output.logprobs[local_idx, : len(response)].detach().cpu(),
                routes,
            )
    if any(row is None for row in rows):
        missing = [idx for idx, row in enumerate(rows) if row is None]
        raise RuntimeError(f"missing DP rollout rows for chunk offsets={missing}")
    materialized = [row for row in rows if row is not None]
    return _build_rollout_from_rows(
        [row[0] for row in materialized],
        [row[1] for row in materialized],
        [row[2] for row in materialized],
        [row[3] for row in materialized],
        metrics=None,
        adapter_version=_rollout_version(non_empty=[output for output in outputs if output is not None]),
        routed_experts=[row[4] for row in materialized if row[4] is not None] if routed_experts is not None else None,
    )


def _rollout_version(*, non_empty: list[RolloutOutput]) -> int | None:
    versions = {output.adapter_version for output in non_empty}
    if not versions:
        return None
    if len(versions) != 1:
        raise RuntimeError(f"rollout DP replicas reported different adapter versions: {versions}")
    return versions.pop()


class ArenoEngine:
    """User-facing coordinator for one local training/inference engine.

    The engine itself does not hold model weights. It splits user batches by DP,
    sends commands to rank workers via the :class:`TPCluster` protocol, and
    merges rank-0 DP results back into the simple API shape returned to the
    caller.

    Two request patterns are used against the cluster:

    * ``cluster.call(op, payload)`` -- blocking RPC-style; waits for every rank
      to return a result. Used for ops where the caller needs outputs
      (rollout, train step, scoring, checkpoint).
    * ``cluster.call_async(op, payload)`` -- async request-id demux over the
      same worker queues, used by request-concurrent serving and agentic
      rollout paths.
    """

    def __init__(
        self,
        config: EngineConfig,
        *,
        start: bool = True,
        cluster_kwargs: dict[str, Any] | None = None,
    ):
        """Start rank workers for a validated engine config.

        Constructs the :class:`TPCluster` and starts the underlying worker
        processes; blocks until the cluster is ready to accept commands.
        """

        # Rollout-only engines do not create a trainer or require a loss.
        if config.role == "train" and config.train_loss_fn is None:
            raise ValueError("ArenoEngine requires train_loss_fn")
        self.config = config
        # TPCluster owns the per-rank worker processes and the IPC channels;
        # ``ArenoWorker`` is the rank-side command loop.
        worker_cls = ArenoWorker
        if config.runtime.device_type != "cuda":
            from areno.api.backend.base import get_backend_cls
            from areno.api.models import BackendType

            worker_cls = get_backend_cls(BackendType(config.runtime.device_type.upper())).worker_cls
        self.cluster = TPCluster(config, worker_cls, **(cluster_kwargs or {}))
        if start:
            self.cluster.start()
        self._async_dp_cursor = count()

    def begin_rollout_session(self) -> None:
        """Prepare workers for one or more rollout calls."""

        self.cluster.call(Op.ROLLOUT_SESSION_BEGIN)

    async def begin_rollout_session_async(self) -> None:
        """Async variant of :meth:`begin_rollout_session`."""

        await self.cluster.call_async(Op.ROLLOUT_SESSION_BEGIN)

    async def sync_rollout_session_async(self) -> None:
        """Synchronize worker TP groups before request-driven rollout."""

        await self.cluster.call_async(Op.ROLLOUT_SESSION_SYNC)

    def end_rollout_session(self) -> None:
        """Finalize rollout state and prepare train weights."""

        self.cluster.call(Op.ROLLOUT_SESSION_END)

    async def end_rollout_session_async(self) -> None:
        """Async variant of :meth:`end_rollout_session`."""

        await self.cluster.call_async(Op.ROLLOUT_SESSION_END)

    @classmethod
    def from_pretrained(
        cls,
        model: str,
        *,
        tp_size: int = 1,
        sequence_parallel: bool | None = None,
        dp_size: int | None = None,
        devices: list[int] | None = None,
        dummy_load: bool = False,
        optimizer_config: OptimizerConfig | None = None,
        runtime_config: RuntimeConfig | None = None,
        loss_fn: Callable[[Any, torch.Tensor], torch.Tensor | tuple[torch.Tensor, dict[str, Any]]] | None = None,
        role: str = "train",
        start: bool = True,
        cluster_kwargs: dict[str, Any] | None = None,
        policy_sync_bucket_mb: int = 64,
        lora_config: LoraConfig | None = None,
        reference_mode: str = "independent",
        base_model_name_or_path: str | None = None,
    ) -> ArenoEngine:
        """Build an engine by reading model config from a checkpoint path.

        Resolves a local path or HuggingFace repo id to a concrete checkpoint
        directory, parses the HF config into the internal model config, and
        wraps the result in an :class:`EngineConfig` before delegating to
        ``__init__``. Blocking: workers are started before the call returns.
        """

        if model is None:
            raise ValueError("from_pretrained() requires a local model path or Hugging Face model id")
        # Resolve HF repo id or local dir to an on-disk checkpoint directory.
        model_path = resolve_model_path(model)
        if model_path is None:
            raise ValueError(f"could not resolve model path: {model!r}")
        # Translate the HF config.json into the engine's internal model schema.
        model_config = config_from_hf(model_path)
        cfg = EngineConfig(
            model=model_config,
            model_path=model_path,
            base_model_name_or_path=(model if base_model_name_or_path is None else base_model_name_or_path),
            train_loss_fn=loss_fn,
            tp_size=tp_size,
            sequence_parallel=sequence_parallel,
            dp_size=dp_size,
            devices=devices,
            dummy_load=dummy_load,
            optimizer=optimizer_config or OptimizerConfig(),
            runtime=runtime_config or RuntimeConfig(),
            role=role,
            policy_sync_bucket_mb=policy_sync_bucket_mb,
            lora=lora_config,
            lora_seed=torch.initial_seed(),
            reference_mode=reference_mode,
        )
        return cls(cfg, start=start, cluster_kwargs=cluster_kwargs)

    def generate_rollout(
        self,
        prompts: list[list[int]],
        *,
        max_new_tokens: int,
        max_running_prompts: int,
        max_prompt_len: int | None = None,
        eos_token_id: int | None = None,
        sampling_params: SamplingParams | None = None,
        prompt_features: list[dict[str, Any] | None] | None = None,
        decode_progress_interval_s: float = 0.0,
        cancel_flags: torch.Tensor | None = None,
    ) -> RolloutOutput:
        """Generate rollout tokens for pre-tokenized prompts.

        Dispatches ``Op.INFER_ROLLOUT`` via the blocking ``cluster.call``
        path. Inputs are token-id rows (one row per prompt); the returned
        :class:`RolloutOutput` carries response token ids and finish reasons
        merged across DP ranks in the original input order.

        All prompts are submitted to the worker scheduler in one payload. The
        worker keeps at most ``max_running_prompts`` rows active and admits
        pending rows under the prefill-token and paged-KV budgets as slots are
        released.
        """

        if not prompts:
            raise ValueError("prompts must be non-empty")
        if prompt_features is not None and len(prompt_features) != len(prompts):
            raise ValueError("prompt_features must have the same length as prompts")
        if max_running_prompts < 1:
            raise ValueError("max_running_prompts must be >= 1")
        sampling_params = sampling_params or SamplingParams()
        # Cap prompt length for KV sizing; either honour caller-provided bound
        # or fall back to the longest prompt actually seen.
        rollout_max_prompt_len = (
            int(max_prompt_len) if max_prompt_len is not None else max(len(prompt) for prompt in prompts)
        )
        rollout_max_cache_len = rollout_max_prompt_len + max_new_tokens
        dp_size = int(self.config.dp_size)
        local_max_running_prompts = max(ceil_div(int(max_running_prompts), dp_size), 1)
        # Worst-case per-rank prefill = every local running slot prefilling its
        # full prompt. The public max_running_prompts value is global.
        max_prefill_tokens = local_max_running_prompts * rollout_max_prompt_len
        # InferenceBatchState already owns bounded admission and continuous
        # refill. Keeping the whole request in one worker payload prevents the
        # coordinator from serialising independent max-running-sized chunks and
        # repeatedly paying their long decode tails.
        prompts_by_dp = split_list_by_dp(prompts, dp_size)
        prompt_features_by_dp = split_list_by_dp(prompt_features, dp_size) if prompt_features is not None else None
        # Parallel split of the global prompt indices for downstream mapping.
        prompt_indices_by_dp = split_list_by_dp(list(range(len(prompts))), dp_size)
        # The payload may contain more pending rows than the KV pool can run at
        # once. Keep allocation bounded by the configured capacity.
        max_cache_len = max(
            max(len(prompt) + max_new_tokens for prompt in prompts),
            rollout_max_cache_len,
        )
        max_blocks_per_seq = ceil_div(max_cache_len, self.config.runtime.kv_block_size)
        # Blocking RPC: returns one result per rank after every prompt finishes
        # (or the cancel flag fires).
        results = self.cluster.call(
            Op.INFER_ROLLOUT,
            RolloutPayload(
                prompts_by_dp=prompts_by_dp,
                prompt_indices_by_dp=prompt_indices_by_dp,
                prompt_features_by_dp=prompt_features_by_dp,
                max_new_tokens=max_new_tokens,
                eos_token_id=eos_token_id,
                sampling_params=sampling_params,
                max_running_seqs=local_max_running_prompts,
                max_cache_len=max_cache_len,
                max_blocks_per_seq=max_blocks_per_seq,
                max_prefill_tokens=max_prefill_tokens,
                num_blocks=local_max_running_prompts * max_blocks_per_seq,
                block_size=self.config.runtime.kv_block_size,
                decode_progress_interval_s=decode_progress_interval_s,
                cancel_flags=cancel_flags,
                cancel_indices_by_dp=split_list_by_dp(list(range(len(prompts))), dp_size)
                if cancel_flags is not None
                else None,
            ),
        )
        # Drop TP duplicates (only DP rank 0 carries real results) and re-order
        # DP-shuffled rows back into input order.
        return _merge_dp_rollouts_in_input_order(
            dp_rank0_results(results, self.config.tp_size, dp_size),
            total_count=len(prompts),
        )

    def probe_rollout_cache(
        self,
        *,
        max_new_tokens: int,
        max_running_prompts: int,
        max_prompt_len: int,
    ) -> float:
        """Allocate rollout KV cache and capture decode graphs without decoding."""

        if max_running_prompts < 1:
            raise ValueError("max_running_prompts must be >= 1")
        if max_prompt_len < 1:
            raise ValueError("max_prompt_len must be >= 1")
        if max_new_tokens < 1:
            raise ValueError("max_new_tokens must be >= 1")
        dp_size = int(self.config.dp_size)
        local_max_running = max(ceil_div(int(max_running_prompts), dp_size), 1)
        max_cache_len = int(max_prompt_len) + int(max_new_tokens)
        max_blocks_per_seq = ceil_div(max_cache_len, self.config.runtime.kv_block_size)
        results = self.cluster.call(
            Op.PROBE_ROLLOUT_CACHE,
            RolloutCacheProbePayload(
                max_running_seqs=local_max_running,
                max_cache_len=max_cache_len,
                max_blocks_per_seq=max_blocks_per_seq,
                num_blocks=local_max_running * max_blocks_per_seq,
                block_size=self.config.runtime.kv_block_size,
            ),
        )
        return max(float(result or 0.0) for result in results) if results else 0.0

    async def generate_rollout_async(
        self,
        prompts: list[list[int]],
        *,
        max_new_tokens: int,
        max_running_prompts: int,
        max_prompt_len: int | None = None,
        eos_token_id: int | None = None,
        sampling_params: SamplingParams | None = None,
        prompt_features: list[dict[str, Any] | None] | None = None,
        decode_progress_interval_s: float = 0.0,
        cancel_flags: torch.Tensor | None = None,
    ) -> RolloutOutput:
        """Async rollout path using TPCluster request-id demux."""

        return await self._generate_rollout_async_once(
            prompts,
            max_new_tokens=max_new_tokens,
            max_running_prompts=max_running_prompts,
            max_prompt_len=max_prompt_len,
            eos_token_id=eos_token_id,
            sampling_params=sampling_params,
            prompt_features=prompt_features,
            decode_progress_interval_s=decode_progress_interval_s,
            cancel_flags=cancel_flags,
        )

    async def _generate_rollout_async_once(
        self,
        prompts: list[list[int]],
        *,
        max_new_tokens: int,
        max_running_prompts: int,
        max_prompt_len: int | None = None,
        eos_token_id: int | None = None,
        sampling_params: SamplingParams | None = None,
        prompt_features: list[dict[str, Any] | None] | None = None,
        decode_progress_interval_s: float = 0.0,
        cancel_flags: torch.Tensor | None = None,
    ) -> RolloutOutput:
        """Run one async rollout pass."""

        if not prompts:
            raise ValueError("prompts must be non-empty")
        if prompt_features is not None and len(prompt_features) != len(prompts):
            raise ValueError("prompt_features must have the same length as prompts")
        if max_running_prompts < 1:
            raise ValueError("max_running_prompts must be >= 1")
        sampling_params = sampling_params or SamplingParams()
        rollout_max_prompt_len = (
            int(max_prompt_len) if max_prompt_len is not None else max(len(prompt) for prompt in prompts)
        )
        rollout_max_cache_len = rollout_max_prompt_len + max_new_tokens
        dp_size = int(self.config.dp_size)
        if not hasattr(self, "_async_dp_cursor"):
            self._async_dp_cursor = count()
        dp_start = next(self._async_dp_cursor) % dp_size
        local_max_running_prompts = max(ceil_div(int(max_running_prompts), dp_size), 1)
        max_prefill_tokens = local_max_running_prompts * rollout_max_prompt_len
        # InferenceBatchState already owns bounded admission and continuous
        # refill. Submit all rows together so pending prompts can enter a free
        # slot without waiting for an earlier coordinator chunk to finish.
        prompts_by_dp = _split_list_by_dp_with_offset(prompts, dp_size, dp_start)
        prompt_features_by_dp = (
            _split_list_by_dp_with_offset(prompt_features, dp_size, dp_start) if prompt_features is not None else None
        )
        prompt_indices_by_dp = _split_list_by_dp_with_offset(list(range(len(prompts))), dp_size, dp_start)
        max_cache_len = max(
            max(len(prompt) + max_new_tokens for prompt in prompts),
            rollout_max_cache_len,
        )
        max_blocks_per_seq = ceil_div(max_cache_len, self.config.runtime.kv_block_size)
        payload = RolloutPayload(
            prompts_by_dp=prompts_by_dp,
            prompt_indices_by_dp=prompt_indices_by_dp,
            prompt_features_by_dp=prompt_features_by_dp,
            max_new_tokens=max_new_tokens,
            eos_token_id=eos_token_id,
            sampling_params=sampling_params,
            max_running_seqs=local_max_running_prompts,
            max_cache_len=max_cache_len,
            max_blocks_per_seq=max_blocks_per_seq,
            max_prefill_tokens=max_prefill_tokens,
            num_blocks=local_max_running_prompts * max_blocks_per_seq,
            block_size=self.config.runtime.kv_block_size,
            decode_progress_interval_s=decode_progress_interval_s,
            cancel_flags=cancel_flags,
            cancel_indices_by_dp=_split_list_by_dp_with_offset(list(range(len(prompts))), dp_size, dp_start)
            if cancel_flags is not None
            else None,
        )
        results = await self.cluster.call_async(
            Op.INFER_ROLLOUT,
            payload,
            result_ranks={dp_rank * int(self.config.tp_size) for dp_rank in range(dp_size)},
        )
        return _merge_dp_rollouts_by_prompt_indices(
            dp_rank0_results(results, self.config.tp_size, dp_size),
            prompt_indices_by_dp,
            chunk_start=0,
            total_count=len(prompts),
        )

    def step(
        self, data_packs: list[dict[str, Any]], *, gradient_accumulation_steps: int | None = None
    ) -> list[TrainStats]:
        """Run one or more train data packs through the DP/TP worker cluster.

        Dispatches ``Op.TRAIN`` via the blocking ``cluster.call`` path. Each
        data pack is split across DP ranks; the workers run forward + backward
        + optimizer for every pack in order and return per-step
        :class:`TrainStats`. Blocking: returns after every rank finishes all
        steps.
        """

        if not data_packs:
            return []
        data_packs_by_dp = []
        for data_pack in data_packs:
            # Per-pack DP split so each rank receives a balanced micro-batch.
            data_packs_by_dp.append(split_data_pack_by_dp(data_pack, int(self.config.dp_size)))
        # to_cpu + shared-memory copy avoids pickling large tensors across IPC.
        results = self.cluster.call(
            Op.TRAIN,
            TrainPayload(
                data_packs_by_dp=self._transport_payload(to_cpu(data_packs_by_dp)),
                gradient_accumulation_steps=gradient_accumulation_steps,
            ),
        )
        stats: list[TrainStats] = []
        # results[rank] is a list aligned with data_packs; zip transposes to
        # iterate per-step across ranks.
        for step_results in zip(*results, strict=True):
            rank0_results = [
                result
                for result in dp_rank0_results(list(step_results), self.config.tp_size, int(self.config.dp_size))
                if result is not None
            ]
            # Sum/average loss + metric fields contributed by each DP rank.
            stats.append(merge_train_stats(rank0_results))
        return stats

    def ensure_roles(self, roles: dict[str, Any]) -> None:
        """Create backend-owned auxiliary roles inside worker processes.

        Dispatches ``Op.ENSURE_ROLES`` (blocking). A role is a named secondary
        model (critic, reward model, reference policy, ...) that workers load
        alongside the primary policy. Idempotent: existing roles are left as
        is, missing ones are constructed using the provided spec.
        """

        # Flatten role specs to a transport-friendly dict; path is stringified
        # because Path objects do not always pickle cleanly across processes.
        payload = EnsureRolesPayload(
            roles={
                name: RoleSpecPayload(
                    path=str(spec.path),
                    trainable=bool(spec.trainable),
                    optimizer_lr=getattr(spec, "optimizer_lr", None),
                    reference_mode=self._role_reference_mode(name, str(spec.path)),
                )
                for name, spec in roles.items()
            }
        )
        self.cluster.call(Op.ENSURE_ROLES, payload)

    def _role_reference_mode(self, name: str, path: str) -> str:
        mode = self.config.reference_mode if name == "ref" else "independent"
        if mode == "reuse_actor_base" and canonical_model_path(path) != canonical_model_path(self.config.model_path):
            raise ValueError("reuse_actor_base requires the reference checkpoint to match the actor base checkpoint")
        return mode

    def score_logprobs(
        self,
        role: str,
        token_rows: list[list[int]],
        *,
        pad_token_id: int,
        features: list[dict[str, Any] | None] | None = None,
        routed_experts: list[object] | None = None,
        microbatch_size: int = 8,
    ) -> list[list[float]]:
        """Score fixed token rows with a model role.

        Dispatches ``Op.SCORE_LOGPROBS`` (blocking). Returns per-token
        log-probabilities for each input row in input order. Token rows are
        split across DP ranks; only rank 0's merged result is returned.
        """

        if not token_rows:
            return []
        if features is not None and len(features) != len(token_rows):
            raise ValueError("features must have the same length as token_rows")
        if routed_experts is not None and len(routed_experts) != len(token_rows):
            raise ValueError("routed_experts must have the same length as token_rows")
        results = self.cluster.call(
            Op.SCORE_LOGPROBS,
            ScorePayload(
                role=role,
                token_rows_by_dp=split_list_by_dp(token_rows, int(self.config.dp_size)),
                features_by_dp=split_list_by_dp(features, int(self.config.dp_size)) if features is not None else None,
                pad_token_id=int(pad_token_id),
                routing_replay_by_dp=(
                    split_list_by_dp(routed_experts, int(self.config.dp_size)) if routed_experts is not None else None
                ),
                microbatch_size=int(microbatch_size),
            ),
        )
        return _merge_dp_rank0_strided_results(results, self.config.tp_size, int(self.config.dp_size))

    def score_values(
        self,
        role: str,
        token_rows: list[list[int]],
        *,
        pad_token_id: int,
        features: list[dict[str, Any] | None] | None = None,
    ) -> list[list[float]]:
        """Score per-token values with a critic role.

        Dispatches ``Op.SCORE_VALUES`` (blocking). Same shape contract as
        :meth:`score_logprobs` but returns per-token critic values.
        """

        if not token_rows:
            return []
        if features is not None and len(features) != len(token_rows):
            raise ValueError("features must have the same length as token_rows")
        results = self.cluster.call(
            Op.SCORE_VALUES,
            ScorePayload(
                role=role,
                token_rows_by_dp=split_list_by_dp(token_rows, int(self.config.dp_size)),
                features_by_dp=split_list_by_dp(features, int(self.config.dp_size)) if features is not None else None,
                pad_token_id=int(pad_token_id),
            ),
        )
        return _merge_dp_rank0_strided_results(results, self.config.tp_size, int(self.config.dp_size))

    def score_rewards(
        self,
        role: str,
        token_rows: list[list[int]],
        *,
        pad_token_id: int,
        features: list[dict[str, Any] | None] | None = None,
    ) -> list[float]:
        """Score sequence rewards with a reward model role.

        Dispatches ``Op.SCORE_REWARDS`` (blocking). Returns one scalar reward
        per input row (not per token).
        """

        if not token_rows:
            return []
        if features is not None and len(features) != len(token_rows):
            raise ValueError("features must have the same length as token_rows")
        results = self.cluster.call(
            Op.SCORE_REWARDS,
            ScorePayload(
                role=role,
                token_rows_by_dp=split_list_by_dp(token_rows, int(self.config.dp_size)),
                features_by_dp=split_list_by_dp(features, int(self.config.dp_size)) if features is not None else None,
                pad_token_id=int(pad_token_id),
            ),
        )
        return _merge_dp_rank0_strided_results(results, self.config.tp_size, int(self.config.dp_size))

    def train_values(
        self,
        role: str,
        data_packs: list[dict[str, Any]],
        *,
        gradient_accumulation_steps: int | None = None,
        cliprange_value: float = 0.5,
        value_loss_coef: float = 0.5,
    ) -> dict[str, float]:
        """Train a critic role on value returns.

        Dispatches ``Op.TRAIN_VALUES`` (blocking). Each data pack is split
        across DP ranks and grouped per-rank so the worker can iterate the
        packs in input order. Returns merged scalar metrics (loss components,
        clip fraction, ...).
        """

        if not data_packs:
            return {}
        data_packs_by_dp = []
        for data_pack in data_packs:
            data_packs_by_dp.append(split_data_pack_by_dp(data_pack, int(self.config.dp_size)))
        # Transpose [pack][dp_rank] -> [dp_rank][pack] so each rank gets its own
        # sequential pack list (matches Op.TRAIN_VALUES worker contract).
        per_dp_packs = [[] for _ in range(int(self.config.dp_size))]
        for split_pack in data_packs_by_dp:
            for dp_rank, pack in enumerate(split_pack):
                per_dp_packs[dp_rank].append(pack)
        results = self.cluster.call(
            Op.TRAIN_VALUES,
            TrainValuesPayload(
                role=role,
                data_packs_by_dp=self._transport_payload(to_cpu(per_dp_packs)),
                gradient_accumulation_steps=gradient_accumulation_steps,
                cliprange_value=float(cliprange_value),
                value_loss_coef=float(value_loss_coef),
            ),
        )
        rank0_results = [
            result for result in dp_rank0_results(results, self.config.tp_size, int(self.config.dp_size)) if result
        ]
        return merge_metric_dicts(rank0_results) or {}

    def save_checkpoint(self, path: str) -> str:
        """Save base weights, or the standard PEFT artifact in native LoRA mode.

        Fullweight workers cooperatively write HuggingFace shards to ``path``.
        Native LoRA keeps the base frozen, so its checkpoint is the adapter-only
        PEFT artifact consumed by training and serving.
        """

        if self.config.lora is not None:
            return self.export_adapter(path)
        results = self.cluster.call(Op.SAVE_CHECKPOINT, SaveCheckpointPayload(path=path))
        return results[0]["path"]

    def export_adapter(self, path: str) -> str:
        """Export the live native LoRA weights as a standard PEFT adapter."""

        results = self.cluster.call(Op.EXPORT_ADAPTER, ExportAdapterPayload(path=path))
        result = next((result for result in results if result is not None), None)
        if result is None:
            raise RuntimeError("native LoRA export did not produce an artifact")
        return result["path"]

    def _transport_payload(self, payload: Any) -> Any:
        """Move tensors to CPU shared memory for zero-copy IPC to workers."""

        # share_memory=True lets the worker side mmap the underlying buffer
        # instead of receiving a pickled copy over the IPC channel.
        return to_cpu(payload, share_memory=True)

    def close(self) -> None:
        """Stop worker processes and release cluster resources.

        Blocking: waits for each rank's worker process to exit before returning.
        """

        self.cluster.close()

    def __enter__(self) -> ArenoEngine:
        """Return self for `with ArenoEngine...` usage."""

        return self

    def __exit__(self, _exc_type, _exc, _tb) -> None:
        """Close workers when leaving a context manager."""

        self.close()


def _split_list_by_dp_with_offset(items: list[Any], dp_size: int, offset: int) -> list[list[Any]]:
    """Round-robin split with a starting DP offset for async request balancing."""

    parts = [[] for _ in range(dp_size)]
    for idx, item in enumerate(items):
        parts[(idx + offset) % dp_size].append(item)
    return parts


def _first_rank0_result(results: list[Any], tp_size: int, dp_size: int):
    """Return the first non-empty rank-0 DP result, or ``[]`` if none."""

    # Strip TP duplicates; only the DP rank-0 of each TP group carries the
    # actual scoring output, the rest return None.
    rank0_results = [result for result in dp_rank0_results(results, tp_size, dp_size) if result is not None]
    if not rank0_results:
        return []
    return rank0_results[0]


def _merge_dp_rank0_strided_results(results: list[Any], tp_size: int, dp_size: int) -> list[Any]:
    """Merge per-DP local score results returned by each TP rank-0 worker."""

    parts = [result if result is not None else [] for result in dp_rank0_results(results, tp_size, dp_size)]
    merged = []
    max_len = max((len(part) for part in parts), default=0)
    for item_idx in range(max_len):
        for part in parts:
            if item_idx < len(part):
                merged.append(part[item_idx])
    return merged
