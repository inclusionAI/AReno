"""Production-gap selected GaLore engineering save/restore, outside quality budget."""

from __future__ import annotations

import hashlib
import json
import os
import random
import sys
from datetime import UTC, datetime
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "repo/scripts/galore_sft"))
from common import batch_indices, encode, parser, trainer
from restore_observer import install_restore_audit, source_sha, write

from areno.api import sft_loss_fn

def main():
    args = parser(__doc__).parse_args()
    assert args.optimizer == "galore" and args.scale == 1 and args.gap == 200
    assert args.context == 512 and args.batch == 4 and args.micro_batch == 2
    assert not args.checkpoint_dir.exists()
    freeze = json.loads((ROOT / "RUNTIME_FREEZE.json").read_text())
    assert source_sha() == freeze["runtime_sha256"]
    args.output_dir.mkdir(parents=True, exist_ok=False)
    os.environ["ARENO_DELIVERY_ACCEPTANCE_DIR"] = str(args.output_dir)
    os.environ["ARENO_EXPERIMENT_MODEL_OWNED_MASTER"] = "0"
    random.seed(args.seed)
    torch.manual_seed(args.seed)
    install_restore_audit()
    write(args.output_dir / "launch.json", {
        "timestamp": datetime.now(UTC).isoformat(), "argv": sys.argv,
        "runtime_sha256": source_sha(), "native_sha256": freeze["native_sha256"],
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "cuda_visible_devices": os.environ["CUDA_VISIBLE_DEVICES"],
        "scope": "200 engineering prefix updates plus two resumed updates; no validation/test and no quality-budget extension",
    })
    orders, rows = {}, []

    def batch_for(encoded, step):
        indices = batch_indices(step, args.seed, len(encoded), args.batch, orders)
        batch = [encoded[index] for index in indices]
        signature = hashlib.sha256(json.dumps(
            [(sample.tokens, sample.prompt_len) for sample in batch], separators=(",", ":")
        ).encode()).hexdigest()
        return batch, {"step": step, "sample_indices": indices, "batch_sha256": signature}

    def step(engine, encoded, index):
        batch, row = batch_for(encoded, index)
        scores = engine.score_logprobs("actor", [sample.tokens for sample in batch], microbatch_size=2)
        for sample, score in zip(batch, scores, strict=True):
            sample.logprobs = list(score)
        metrics = engine.train(batch, sft_loss_fn, mini_bs=2)
        assert metrics["logp_abs_diff_mean"] == 0
        assert metrics["update_optimizer_steps"] == 1
        assert metrics["update_worker_step"] == index + 1
        assert engine._ctx.global_step == index
        refresh = bool(metrics["update_refresh_any"])
        assert refresh == (index % 200 == 0)
        row.update(timestamp=datetime.now(UTC).isoformat(), native_logp_abs_diff_mean=metrics["logp_abs_diff_mean"],
                   optimizer_updates=metrics["update_optimizer_steps"], refresh=refresh)
        rows.append(row)
        with (args.output_dir / "steps.jsonl").open("a") as stream:
            stream.write(json.dumps(row) + "\n")
        if index % 25 == 0 or index >= 199:
            print(json.dumps(row), flush=True)

    engine = trainer(args, output=args.output_dir / "prefix-events")
    try:
        engine.init()
        encoded, stats = encode(engine.get_tokenizer(), args, "train")
        for index in range(200):
            step(engine, encoded, index)
        engine.save_checkpoint(str(args.checkpoint_dir))
        probe_tokens = [encoded[0].tokens, encoded[1].tokens]
        probe = engine.score_logprobs("actor", probe_tokens, microbatch_size=2)
        _, next_batch = batch_for(encoded, 200)
        assert engine._ctx.global_step == 199
    finally:
        engine.close()

    engine = trainer(args, resume=True, output=args.output_dir / "resume-events")
    try:
        engine.init()
        audit = json.loads((args.output_dir / "immediate-state-restore.json").read_text())
        assert audit["exact_match"] and audit["worker_completed_updates"] == 200
        assert engine._ctx.global_step == 199
        assert probe == engine.score_logprobs("actor", probe_tokens, microbatch_size=2)
        encoded, _ = encode(engine.get_tokenizer(), args, "train")
        assert batch_for(encoded, 200)[1] == next_batch
        for index in (200, 201):
            step(engine, encoded, index)
        assert engine._ctx.global_step == 201
    finally:
        engine.close()
    assert source_sha() == freeze["runtime_sha256"]
    write(args.output_dir / "summary.json", {
        "status": "passed", "runtime_sha256": source_sha(),
        "prefix_updates": 200, "resume_updates": [200, 201], "refresh_indices": [row["step"] for row in rows if row["refresh"]],
        "canonical_state_bitexact": audit, "probe_exact": True, "next_batch_exact": True,
        "native_logp_abs_diff_max": max(row["native_logp_abs_diff_mean"] for row in rows),
        "data_encoding": stats, "quality_budget_unchanged": True,
        "checkpoint_bytes": sum(p.stat().st_size for p in args.checkpoint_dir.rglob("*") if p.is_file()),
        "limitation": "Immediate restore equality and two native updates; no bitwise native future-trajectory claim",
    })


if __name__ == "__main__":
    main()
