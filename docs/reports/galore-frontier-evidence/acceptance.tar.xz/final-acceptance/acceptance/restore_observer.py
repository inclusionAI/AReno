from pathlib import Path
from datetime import UTC, datetime
import os,json,hashlib,torch
REPO=Path(__file__).resolve().parents[1]/"repo"
def source_sha():
 h=hashlib.sha256()
 for p in sorted((REPO/"areno").rglob("*.py")):
  h.update(str(p.relative_to(REPO)).encode());h.update(p.read_bytes())
 return h.hexdigest()
def write(path,value):
 Path(path).write_text(json.dumps(value,indent=2)+"\n")

def install_restore_audit():
    from areno.engine import worker as worker_module
    from areno.engine.checkpoints import training_state as state_io

    original = state_io.load_training_state

    def checked_load(worker, path):
        original(worker, path)
        expected = torch.load(Path(path) / "training_state.pt", map_location="cpu", weights_only=True, mmap=True)
        actual = {
            "format": "areno-training-v1",
            "optimizer_class": type(worker.optimizer).__name__,
            "parameter_names": [name for name, param in worker.model.named_parameters() if param.requires_grad],
            "optimizer": worker.optimizer.state_dict(),
            "global_step": worker._global_step,
            "schedule": {name: getattr(worker, name) for name in state_io._SCHEDULE_FIELDS},
            "torch_rng": torch.get_rng_state(),
            "cuda_rng": torch.cuda.get_rng_state(worker.device),
        }
        mismatches, counts = [], {"tensors": 0, "tensor_bytes": 0}

        def compare(left, right, key="root"):
            if isinstance(left, torch.Tensor):
                counts["tensors"] += 1
                counts["tensor_bytes"] += left.numel() * left.element_size()
                if not isinstance(right, torch.Tensor) or left.shape != right.shape or left.dtype != right.dtype:
                    mismatches.append(key + ".shape/dtype")
                elif not torch.equal(
                    left.contiguous().reshape(-1).view(torch.uint8), right.contiguous().reshape(-1).view(torch.uint8)
                ):
                    mismatches.append(key + ".bits")
            elif isinstance(left, dict):
                if not isinstance(right, dict) or left.keys() != right.keys():
                    mismatches.append(key + ".keys")
                    return
                for name in left:
                    compare(left[name], right[name], f"{key}.{name}")
            elif isinstance(left, (tuple, list)):
                if type(left) is not type(right) or len(left) != len(right):
                    mismatches.append(key + ".type/length")
                    return
                for index, (a, b) in enumerate(zip(left, right, strict=True)):
                    compare(a, b, f"{key}[{index}]")
            elif left != right:
                mismatches.append(key)

        compare(expected, actual)
        result = dict(
            timestamp=datetime.now(UTC).isoformat(),
            exact_match=not mismatches,
            mismatches=mismatches,
            **counts,
            worker_completed_updates=worker._global_step,
            parameter_owners=len(actual["parameter_names"]),
            runtime_repo_sha256=source_sha(),
            scope="immediate live restored canonical masters/moments/bases/private RNG/global RNG/schedule/clock/names compared to saved sidecar before scoring/backward",
        )
        write(Path(os.environ["ARENO_DELIVERY_ACCEPTANCE_DIR"]) / "immediate-state-restore.json", result)
        assert not mismatches, "immediate live state restoration mismatch"

    state_io.load_training_state = checked_load
    worker_module.load_training_state = checked_load

