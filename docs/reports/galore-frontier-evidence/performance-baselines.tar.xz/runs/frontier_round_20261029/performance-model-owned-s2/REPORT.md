# Model-owned scale2/all-matrix same-GPU performance

GPU0 `GPU-550e9997-ba0a-b916-63f8-ea9284318c37`, source `7da069e9aba272313b2e7b3f5325923b4779adf5afb50f9b98098aae9127faf2`. Each method ran in a fresh process with 2 warmups + 400 measured updates. All 402 input batch hashes/target counts and the initial forward loss matched. Native SFT diagnostic was 0 throughout. No foreign PID was observed on this GPU. No validation/test or checkpoint I/O was performed.

| Method | Allocated GiB | Reserved GiB | Sync train profile ms/update | Actor-score+train ms/update | Targets/s (score+train) | Measured refreshes |
|---|---:|---:|---:|---:|---:|---:|
| adamw | 12.084 | 13.141 | 485.38 | 590.08 | 543.98 | 0 |
| adam8 | 8.453 | 9.668 | 452.69 | 554.50 | 578.88 | 0 |
| galore | 7.078 | 8.201 | 507.38 | 609.28 | 526.84 | 2 |

GaLore reduced peak allocated memory by 41.42% versus AdamW and 16.26% versus 8-bit Adam. Actor-score+train time increased by 3.25% and 9.88%, respectively. These ratios describe this scale2 run; no claim is made for a different later-selected scale.

The selected GaLore uses rank128/gap200/scale2/transport/vocabulary-included/recycled+QR+native-model-master+fused. Other model/runtime/lr/beta/clip/batch/context/seed settings are matched. Actual measured refresh steps are 200 and 400; the initial step 0 refresh is inside warmup and excluded from timing summaries.

| GaLore subset | Updates | Sync train profile ms/update | Score+train ms/update | Allocated GiB |
|---|---:|---:|---:|---:|
| normal | 398 | 495.69 | 597.59 | 7.078 |
| refresh | 2 | 2833.09 | 2934.26 | 6.952 |

The raw cuda_step_time_s field uses perf_counter bracketed by torch.cuda.synchronize, summed across microbatches; it is synchronized training-segment wall time, not kernel-only CUDA-event time. Framework memory peaks aggregate max over per-microbatch training profiles; sampled NVML memory is separately recorded as a lower bound. Other GPUs carried independent jobs, so this is card-exclusive rather than node-exclusive. There is one sequential timing trial per method and no quality comparison. Actor-score+train throughput excludes logging, batch preparation and model initialization. No timing claim is inferred from the mocked CPU smoke.

Raw outputs: [AdamW](outputs/adamw/steps.jsonl), [8-bit Adam](outputs/adam8/steps.jsonl), [GaLore](outputs/galore/steps.jsonl). Each output directory retains metadata, encoding, launcher, summary and one-second nvml-audit files. Exact commands/environment/model/source/wrapper/data identities are in [RUN_MANIFEST.json](RUN_MANIFEST.json). Complete machine-readable results and ratios are in [summary.json](summary.json).
