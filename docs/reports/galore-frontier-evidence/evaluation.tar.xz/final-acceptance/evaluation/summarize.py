"""Summarize the pre-registered endpoint scores without changing selection."""

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main():
    status = json.loads((HERE / "status.json").read_text())
    assert status["status"] == "complete"
    rows = {(j["condition"], j["seed"]): j["result"]["test"]["loss"] for j in status["jobs"]}
    assert len(rows) == 9
    lines = [
        "# Selected-candidate post-selection test evaluation",
        "",
        "All nine frozen 1024-update model exports were scored once through the final runtime. No endpoint was retrained or selected using these scores. This is the historical fixed test split used in earlier rounds; it is not an untouched benchmark.",
        "",
        "| Seed | AdamW loss | 8-bit loss | GaLore loss | GaLore−AdamW | Relative vs AdamW | GaLore−8-bit | Relative vs 8-bit |",
        "|---|---:|---:|---:|---:|---:|---:|---:|",
    ]
    deltas = []
    for seed in (0, 1, 2):
        a, b, g = (rows[(m, seed)] for m in ("adamw", "adam8", "galore"))
        delta = {"seed": seed, "adamw_loss": a, "adam8_loss": b, "galore_loss": g,
                 "galore_minus_adamw": g-a, "galore_relative_vs_adamw_percent": 100*(g/a-1),
                 "galore_minus_adam8": g-b, "galore_relative_vs_adam8_percent": 100*(g/b-1)}
        deltas.append(delta)
        lines.append(f"| {seed} | {a:.9f} | {b:.9f} | {g:.9f} | {g-a:+.9f} | {100*(g/a-1):+.4f}% | {g-b:+.9f} | {100*(g/b-1):+.4f}% |")
    lines += ["", "| Method | Mean test loss | Sample standard deviation |", "|---|---:|---:|"]
    for method in ("adamw", "adam8", "galore"):
        stats = status["aggregates"][method]
        lines.append(f"| {method} | {stats['mean']:.9f} | {stats['sample_std']:.9f} |")
    lines += ["", f"Mean GaLore relative change versus AdamW: {status['aggregates']['galore_relative_change_vs_adamw_percent']:+.6f}%; versus 8-bit: {status['aggregates']['galore_relative_change_vs_adam8_percent']:+.6f}%.",
              "", "Each endpoint scored 743 examples / 55,562 response targets. All nine encoded-example digests agree. GPU 1 was exclusively locked and sampled each second; contamination flags are preserved per endpoint. Runtime and native-library hashes match the approved freeze. There is one evaluation per endpoint, not timing replication or a claim about other datasets/models."]
    (HERE / "REPORT.md").write_text("\n".join(lines) + "\n")
    (HERE / "PER_SEED_DELTAS.json").write_text(json.dumps(deltas, indent=2) + "\n")
    print(json.dumps(status["aggregates"], indent=2))


if __name__ == "__main__":
    main()
