"""Register a fixed nine-endpoint test evaluation before viewing any test results."""

import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
CONFIRM = ROOT / "runs/frontier_confirm_20261029"
REPO = HERE.parent / "repo"


def digest(path):
    sha = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(8 << 20), b""):
            sha.update(block)
    return sha.hexdigest()


def main():
    target = HERE / "PREPARED.json"
    if target.exists():
        raise RuntimeError("registration already exists; preserve the original")
    jobs = json.loads((CONFIRM / "jobs.json").read_text())
    states = json.loads((CONFIRM / "status.json").read_text())["jobs"]
    inputs = {}
    endpoints = []
    data_dir = Path(jobs["jobs"][0]["data_dir"])
    expected_data = jobs["jobs"][0]["expected_input_sha256"]
    for path in (data_dir / f"{split}.jsonl" for split in ("train", "validation", "test")):
        got = digest(path)
        assert got == expected_data[str(path)], path
        inputs[str(path)] = got
    for job in jobs["jobs"]:
        state = states[job["id"]]
        assert state["status"] == "complete"
        assert state["resolved_source_sha256"] == job["expected_source_sha256"]
        checkpoint = Path(state["final_checkpoint"])
        weights = {}
        for relative, expected in state["checkpoint_model_sha256"].items():
            path = checkpoint / relative
            actual = digest(path)
            assert actual == expected, path
            weights[relative] = actual
        assert weights and any(name.endswith(".safetensors") for name in weights)
        metadata_file = next((Path(job["model_eval_output_dir"])).rglob("metadata.json"))
        prior_metadata = json.loads(metadata_file.read_text())
        assert prior_metadata["source_sha256"] == job["expected_source_sha256"]
        assert prior_metadata["data_sha256"]["test"] == inputs[str(data_dir / "test.jsonl")]
        command = [
            str(ROOT / ".venv/bin/python"), str(HERE / "harness/test_eval.py"),
            "--data-dir", str(data_dir), "--checkpoint-dir", str(checkpoint),
            "--output-dir", str(HERE / "outputs" / job["id"]),
            "--model", str(ROOT / "models/Qwen3-0.6B"), *job["options"],
        ]
        endpoints.append({
            "id": job["id"], "condition": job["condition"], "seed": job["seed"],
            "checkpoint": str(checkpoint), "model_files_sha256": weights,
            "training_source_sha256": job["expected_source_sha256"],
            "training_summary_sha256": digest(state["train_summary_file"]),
            "prior_model_eval_metadata_sha256": digest(metadata_file), "command": command,
        })
    assert len(endpoints) == 9
    for method in ("adamw", "adam8", "galore"):
        assert sorted(e["seed"] for e in endpoints if e["condition"] == method) == [0, 1, 2]
    for path in sorted((HERE / "harness").glob("*.py")):
        inputs[str(path)] = digest(path)
    original_common = CONFIRM / "harness/common.py"
    assert inputs[str(HERE / "harness/common.py")] == digest(original_common)
    manifest = {
        "status": "prepared_waiting_for_parent_freeze",
        "registered_at": datetime.now(UTC).isoformat(),
        "repo": str(REPO), "gpu": 1, "cpu_affinity": [40, 41, 42, 43],
        "split": "test", "selection_from_test_allowed": False,
        "historical_test_usage": "This fixed split was used in earlier rounds, not untouched.",
        "validation_selection": "Selected strict logicalFP32 rank128 gap200 scale1 before this registration.",
        "harness_relation": "common.py byte-identical; original scorer/encoding; model-only entry changes validation to test",
        "input_sha256": inputs, "jobs": endpoints,
        "training_jobs_sha256": digest(CONFIRM / "jobs.json"),
        "training_status_sha256": digest(CONFIRM / "status.json"),
        "training_selection_sha256": digest(CONFIRM / "SELECTION.json"),
    }
    target.write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps({"status": manifest["status"], "jobs": len(endpoints), "model_files": sum(len(e["model_files_sha256"]) for e in endpoints), "manifest_sha256": digest(target)}))


if __name__ == "__main__":
    main()
