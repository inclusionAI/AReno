"""Frozen post-selection test evaluation of already exported model weights."""

import hashlib
import json
from pathlib import Path

from common import encode, evaluate, metadata, parser, setup, trainer, write


def main():
    args = parser(__doc__).parse_args()
    log = setup(args, "test_eval")
    info = metadata(args)
    info["model_only"] = True
    info["evaluation_split"] = "test"
    info["selection_policy"] = "already selected; no retraining or selection from test results"
    info["test_usage_caveat"] = "fixed historical split used in earlier rounds; not untouched"
    info["test_entry_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    write(args.output_dir / "metadata.json", info)
    args.model = str(args.checkpoint_dir)
    engine = trainer(args, resume=False)
    try:
        engine.init()
        rows, stats = encode(engine.get_tokenizer(), args, "test")
        fingerprint = hashlib.sha256()
        for row in rows:
            fingerprint.update(json.dumps([row.tokens, row.prompt_len], separators=(",", ":")).encode())
            fingerprint.update(b"\n")
        result = {
            "status": "complete",
            "model_only": True,
            "test": evaluate(engine, rows, args.micro_batch),
            "encoded_examples_sha256": fingerprint.hexdigest(),
        }
        result["test"]["encoding"] = stats
        write(args.output_dir / "summary.json", result)
        log.info("%s", result)
    finally:
        engine.close()


if __name__ == "__main__":
    main()
