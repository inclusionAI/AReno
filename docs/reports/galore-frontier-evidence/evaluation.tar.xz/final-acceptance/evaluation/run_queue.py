"""Run the registered test-only endpoint queue after an explicit parent freeze."""

import fcntl
import hashlib
import json
import math
import os
import statistics
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

import psutil

from prepare import HERE, ROOT, digest


def now():
    return datetime.now(UTC).isoformat()


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def runtime_sha(repo):
    sha = hashlib.sha256()
    for path in sorted((repo / "areno").rglob("*.py")):
        sha.update(str(path.relative_to(repo)).encode())
        sha.update(path.read_bytes())
    return sha.hexdigest()


def gpu_processes():
    output = subprocess.check_output([
        "nvidia-smi", "--id=1", "--query-compute-apps=pid", "--format=csv,noheader,nounits"
    ], text=True)
    return sorted(int(line.strip()) for line in output.splitlines() if line.strip().isdigit())


def is_descendant(pid, ancestor):
    try:
        process = psutil.Process(pid)
        return pid == ancestor or any(p.pid == ancestor for p in process.parents())
    except psutil.NoSuchProcess:
        return False


def main():
    manifest = json.loads((HERE / "PREPARED.json").read_text())
    freeze = json.loads((HERE / "FREEZE.json").read_text())
    assert freeze["parent_approved"] is True
    assert freeze["manifest_sha256"] == digest(HERE / "PREPARED.json")
    assert freeze["queue_sha256"] == digest(Path(__file__))
    repo = Path(manifest["repo"])
    assert runtime_sha(repo) == freeze["runtime_source_sha256"]
    native = next((repo / "areno/accel").glob("_areno_accel*.so"))
    assert digest(native) == freeze["native_extension_sha256"]
    for path, sha in manifest["input_sha256"].items():
        assert digest(path) == sha, path
    for job in manifest["jobs"]:
        for relative, sha in job["model_files_sha256"].items():
            path = Path(job["checkpoint"]) / relative
            assert digest(path) == sha, path
    os.sched_setaffinity(0, manifest["cpu_affinity"])
    lock = (ROOT / "runs/gpu1.lock").open("a")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert not gpu_processes(), "GPU1 has foreign compute processes; do not launch"
    status = {"status": "running", "started_at": now(), "freeze": freeze, "jobs": []}
    write(HERE / "status.json", status)
    environment = os.environ.copy()
    environment.update(CUDA_VISIBLE_DEVICES="1", PYTHONPATH=str(repo), ARENO_EXPERIMENT_MODEL_OWNED_MASTER="0")
    for job in manifest["jobs"]:
        assert runtime_sha(repo) == freeze["runtime_source_sha256"], "runtime changed during frozen evaluation"
        assert not gpu_processes(), "GPU1 became occupied; do not launch"
        output = HERE / "outputs" / job["id"]
        if output.exists():
            raise RuntimeError(f"refusing to overwrite a prior endpoint: {output}")
        output.mkdir(parents=True)
        launch = {"id": job["id"], "started_at": now(), "command": job["command"], "environment": {key: environment[key] for key in ("CUDA_VISIBLE_DEVICES", "PYTHONPATH", "ARENO_EXPERIMENT_MODEL_OWNED_MASTER")}, "cpu_affinity": sorted(os.sched_getaffinity(0)), "foreign_pids": []}
        write(output / "launch.json", launch)
        with (output / "launcher.log").open("w") as log, (output / "gpu_samples.jsonl").open("w") as samples:
            process = subprocess.Popen(job["command"], env=environment, stdout=log, stderr=subprocess.STDOUT)
            while process.poll() is None:
                pids = gpu_processes()
                foreign = [pid for pid in pids if not is_descendant(pid, process.pid)]
                launch["foreign_pids"] = sorted(set(launch["foreign_pids"] + foreign))
                samples.write(json.dumps({"timestamp": now(), "compute_pids": pids, "foreign_pids": foreign}) + "\n")
                samples.flush()
                time.sleep(1)
            launch.update(returncode=process.returncode, ended_at=now(), contaminated=bool(launch["foreign_pids"]))
        write(output / "launch.json", launch)
        assert process.returncode == 0, f"failed evaluation: {job['id']}"
        result = json.loads((output / "summary.json").read_text())
        info = json.loads((output / "metadata.json").read_text())
        assert result["status"] == "complete"
        assert info["source_sha256"] == freeze["runtime_source_sha256"]
        assert info["native_extension_sha256"] == freeze["native_extension_sha256"]
        assert result["test"]["examples"] == 743
        assert result["test"]["target_tokens"] == 55562
        assert math.isfinite(result["test"]["loss"])
        status["jobs"].append({"id": job["id"], "condition": job["condition"], "seed": job["seed"], "launch": launch, "result": result})
        write(HERE / "status.json", status)
        print(json.dumps({"timestamp": now(), "completed": len(status["jobs"]), "id": job["id"], "test_loss": result["test"]["loss"]}), flush=True)
        assert not launch["contaminated"], "foreign GPU process appeared; preserve result and investigate"
    fingerprints = {job["result"]["encoded_examples_sha256"] for job in status["jobs"]}
    assert len(fingerprints) == 1
    aggregates = {}
    for method in ("adamw", "adam8", "galore"):
        losses = [job["result"]["test"]["loss"] for job in status["jobs"] if job["condition"] == method]
        aggregates[method] = {"mean": statistics.mean(losses), "sample_std": statistics.stdev(losses), "per_seed": losses}
    aggregates["galore_relative_change_vs_adamw_percent"] = 100 * (aggregates["galore"]["mean"] / aggregates["adamw"]["mean"] - 1)
    aggregates["galore_relative_change_vs_adam8_percent"] = 100 * (aggregates["galore"]["mean"] / aggregates["adam8"]["mean"] - 1)
    status.update(status="complete", completed_at=now(), aggregates=aggregates, encoded_examples_sha256=fingerprints.pop())
    write(HERE / "status.json", status)
    write(HERE / "RESULTS.json", {"status": "complete", "aggregates": aggregates, "notes": manifest["historical_test_usage"], "selection_from_test_allowed": False})


if __name__ == "__main__":
    main()
