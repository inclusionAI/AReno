# Frozen selected-candidate test evaluation

Prepared nine model-only endpoints: AdamW, 8-bit AdamW, selected strict logicalFP32 GaLore; seeds 0, 1, 2. All endpoints are existing 1024-update exports from the same-source formal confirmation. No training, optimizer restore, ensembling or selection from test scores is allowed.

`prepare.py` freshly checks all 324 exported model/config files against the training controller SHA inventory, checks the fixed train/validation/test data digests, and registers the commands before any test score is observed. `harness/common.py`, `train.py`, `eval.py` are byte-identical copies of the confirmation harness. `harness/test_eval.py` uses its unchanged encoder/scorer on `test` and records a common encoded-example digest. This historical fixed test split was used in earlier rounds and is not an untouched new benchmark.

`run_queue.py` requires parent-approved `FREEZE.json` containing the prepared-manifest digest, queue-script digest, runtime-source digest, and native-extension digest. It rechecks all registered input/model files before launch, uses GPU 1 and CPU cores 40–43 with the shared GPU lock, rejects occupied GPUs, samples compute PIDs each second, and flags foreign PIDs without terminating them. Outputs are preserved per endpoint; existing outputs cannot be overwritten. The queue requires 743 test examples and 55,562 response targets, equal encoded-example fingerprints, a fixed runtime and native library, and finite losses.

Preparation smoke completed: scripts compile, registration verifies nine endpoints / 324 model-config files. The first registration attempt saw auxiliary `test.manifest.jsonl` among the dataset directory and stopped before registration; prepare now checks only the actual train/validation/test inputs. The original scorer and data are unchanged.

Commands (source the workspace environment first):

```bash
python runs/final_delivery_20261029/evaluation/prepare.py
CUDA_VISIBLE_DEVICES=1 PYTHONPATH=runs/final_delivery_20261029/repo taskset -c 40-43 python runs/final_delivery_20261029/evaluation/harness/test_eval.py --help
python runs/final_delivery_20261029/evaluation/run_queue.py
```

Parent freeze was approved after semantic review. All nine formal GPU evaluations completed successfully, with one evaluation per endpoint and no retraining or post-test selection. Mean test losses: AdamW 2.209215081, 8-bit 2.160363904, GaLore 2.154818821. GaLore relative changes are −2.46224% versus AdamW and −0.25667% versus 8-bit. All three GaLore seeds have lower loss than both corresponding controls. The fixed split has historical usage, and these results are not a universal optimizer claim.

`summarize.py` generated `REPORT.md`, `PER_SEED_DELTAS.json`, and the queue generated `RESULTS.json`. `AUDIT.json` records 9 successful endpoints, 324 files verified before launch, identical encoded examples (743 / 55,562 targets), runtime/native hashes matching freeze, and 242 one-second GPU process samples with no foreign PID observed.
