# Selected-candidate post-selection test evaluation

All nine frozen 1024-update model exports were scored once through the final runtime. No endpoint was retrained or selected using these scores. This is the historical fixed test split used in earlier rounds; it is not an untouched benchmark.

| Seed | AdamW loss | 8-bit loss | GaLore loss | GaLore−AdamW | Relative vs AdamW | GaLore−8-bit | Relative vs 8-bit |
|---|---:|---:|---:|---:|---:|---:|---:|
| 0 | 2.210180925 | 2.160922750 | 2.156022797 | -0.054158129 | -2.4504% | -0.004899954 | -0.2268% |
| 1 | 2.209284991 | 2.159379015 | 2.152665351 | -0.056619641 | -2.5628% | -0.006713664 | -0.3109% |
| 2 | 2.208179327 | 2.160789947 | 2.155768317 | -0.052411010 | -2.3735% | -0.005021630 | -0.2324% |

| Method | Mean test loss | Sample standard deviation |
|---|---:|---:|
| adamw | 2.209215081 | 0.001002629 |
| adam8 | 2.160363904 | 0.000855520 |
| galore | 2.154818821 | 0.001869296 |

Mean GaLore relative change versus AdamW: -2.462244%; versus 8-bit: -0.256674%.

Each endpoint scored 743 examples / 55,562 response targets. All nine encoded-example digests agree. GPU 1 was exclusively locked and sampled each second; contamination flags are preserved per endpoint. Runtime and native-library hashes match the approved freeze. There is one evaluation per endpoint, not timing replication or a claim about other datasets/models.
