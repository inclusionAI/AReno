# Final strict-FP32 candidate: semantic and numerical acceptance

This audit covers final runtime SHA256 `65b3dd64133770266a5a3f1f05f5bef64db359ead45810f0ae4a557719e0710c`, compared with formal experiment runtime `7da069e9aba272313b2e7b3f5325923b4779adf5afb50f9b98098aae9127faf2`. The experimental model-owned mode is disabled. The final runtime does not include that experimental feature.

The only new runtime change from the previous e1e0cc4 deliverable is an early checkpoint-policy guard added by the parent agent. It rejects an explicit incompatible `backend_policy` even if the payload is relabeled as legacy v1/v2. Valid current checkpoints carry the exact `BACKEND_POLICY`, so this guard performs a comparison and has no state or numerical side effects. Genuine legacy v1 checkpoints without a policy remain supported. This matters because legacy format labels previously bypassed the current-format policy validation, potentially admitting checkpoints produced under a different precision policy.

## Changes and checks

- Added `tests/test_galore_checkpoint_policy_cpu.py` to the final repo: eight incompatible-policy/legacy-format combinations require rejection without modifying model, optimizer, or global RNG; two legitimate legacy-v1 variants restore and continue exactly.
- Preserved the pre-fix result: eight expected rejection tests failed and two compatibility tests passed. After the guard, all ten pass. Logs are `policy-before.log` and `policy-after.log`.
- Added local `compare_implementations.py`, loading the two optimizer classes under distinct module names. The classes use identical shared dependencies: every other runtime Python file matches byte-for-byte, except the experiment-only `model_writeback.py`, unused with its flag disabled. `galore-source.diff` preserves the complete optimizer source difference.
- Six dynamic cases cover CPU and CUDA, FP32 and BF16 matrices, FP32 normalization owners, tall/wide matrices, rank128, and a 32768-row matrix that actually crosses the registered 16384-row tiling boundary. Each runs eight updates including refreshes 0/3/6, bidirectional serialized checkpoint cross-loads after updates 2/3, and a malformed second-owner rejection. The 1152 counted tensor comparisons are exact; all checkpoint trees, parameters, private RNG and hyperparameters match. The later-owner rejection publishes no partial state.
- Copied the previous independent scale2 numerical harness to `numerics_scale1.py`; changed only its explicit reference multiplier and candidate/byte-proof scale from 2 to 1, its repo location/frozen source SHA, and added the total-byte assertion including masters. The independent QR/Ritz rule, dense full-covariance moment-transport reference, torch AdamW rule, and original `atol=1e-6, rtol=1e-4` are preserved.
- Six CPU and six CUDA numerical cases pass, covering square/tall/wide FP32 matrices, selected scalar settings and registered nonzero-decay/epsilon stress settings. Maximum weight absolute error is 2.9802322387695312e-8 on CPU and 5.960464477539063e-8 on CUDA. Maximum normalized error across weights, moments and bases is 0.02432094 CPU and 0.27444813 CUDA, below 1. Saving after three updates and resuming into refresh update3 agrees exactly through subsequent updates.
- Existing final-source GPU integration/reference smoke passes: 59 tests across `test_integrated_galore_cpu.py`, `test_galore_streamed_cuda.py`, and `test_galore_cuda.py`. This includes combined recycled projection/transport, compact FP32 masters, fused BF16 writes, tiled lifts, exact checkpoint restore and FP32 reference checks.

## Persistent bytes

For actual 1024x1024 FP32, rank128 state tensors, moments plus basis consume 1,572,864 bytes; including private CPU projector RNG, 1,577,920 bytes. Including the explicit FP32 master, all GaLore optimizer tensors consume 5,772,224 bytes. Measured torch FP32 AdamW optimizer tensors consume 8,388,612 bytes, including its step counter; torch uses the model itself as its FP32 master. Both the issue's state criterion and this stricter all-optimizer-tensors comparison pass. Model storage, gradients, workspace, activations and Python object metadata are excluded from these counts; real-model peak measurements remain separate.

## How to reproduce

Source the project `env.sh`, set `PYTHONPATH` to the final repo, and invoke the local audit scripts. `compare_implementations.py` accepts `--final-repo`, `--experiment-repo`, `--output`, and `--device`. `numerics_scale1.py` accepts `--device` and `--output` and asserts the frozen runtime SHA. Run the new policy tests with CUDA hidden for the CPU suite. CUDA commands used physical GPU2, `CUDA_VISIBLE_DEVICES=2`, `taskset -c 44-47`, and the shared `runs/gpu2.lock` via `flock`. The foreign-process precheck was empty. There was no continuous NVML monitor, so this evidence is not a performance or clean-timing claim.

`AUDIT.json` contains exact source identities, counts, byte results, limitations and per-file SHA256 values. `equivalence-{cpu,cuda}.json` retain per-case settings, source-file hashes, AST-identical method names, hardware/software identity and timestamps. `numerics-{cpu,cuda}.json` retain all per-update numerical readouts.

## Limits and retained harness correction

Dynamic equality covers enumerated cases and source review; it is not a universal formal proof. Selected production rank128/gap200 training quality comes from the existing paired three-seed formal experiment; the small acceptance harness uses gap3/rank2 to repeatedly exercise refreshes. FP32 reference matrices correctly use the FP32 master fallback; real mixed-BF16 compact/fused behavior is covered separately. The code audit does not claim future native full-model backward trajectories are bitwise deterministic.

The first CPU dynamic comparison aliased its two FP32 initial owners because `.to(cpu, float32)` reused storage. This was an audit-harness issue: cloning each initial owner fixed it. The initial traceback is retained as `equivalence-cpu-harness-alias-failure.log`; final CPU and CUDA comparisons were rerun with the corrected script. Runtime and reference tolerances were not changed.
