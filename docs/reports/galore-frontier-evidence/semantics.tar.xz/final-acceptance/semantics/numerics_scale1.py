"""Independent scale1 reference, strict refresh-boundary resume and byte proof."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path

import torch
from tests.test_galore_transport_cpu import dense_transport
from tests.test_recycled_galore_cpu import IndependentReference, reference_qr

from areno.engine.optim.galore import GaLoreAdamW

EXPECTED_SHA = "65b3dd64133770266a5a3f1f05f5bef64db359ead45810f0ae4a557719e0710c"
REPO = Path(__file__).resolve().parents[1] / "repo"


def source_sha():
    digest = hashlib.sha256()
    for path in sorted((REPO / "areno").rglob("*.py")):
        digest.update(str(path.relative_to(REPO)).encode())
        digest.update(path.read_bytes())
    value = digest.hexdigest()
    assert value == EXPECTED_SHA
    return value


class Scale1Reference(IndependentReference):
    """Reuse independent QR/Ritz + torch AdamW, plus dense covariance transport."""

    def __init__(self, initial, *, lr, betas, decay, eps):
        super().__init__(initial, oversampling=16)
        self.lr, self.betas, self.decay = lr, betas, decay
        self.optimizer.param_groups[0].update(lr=lr, betas=betas, eps=eps)

    def _update(self, gradient):
        old_weight = self.weight.clone()
        old_basis = self.basis.clone() if self.basis is not None else None
        completed = self.step
        a = gradient.T if self.right else gradient
        if completed % 3 == 0:
            width = min(2 + self.oversampling, a.shape[0])
            noise = torch.randn(a.shape[0], width if old_basis is None else width - 2, generator=self.generator).to(
                a.device
            )
            if old_basis is not None:
                for _ in range(2):
                    noise -= old_basis @ (old_basis.T @ noise)
                q = reference_qr(torch.cat([old_basis, noise], dim=1))
            else:
                q = reference_qr(noise)
            q = reference_qr(a @ reference_qr(a.T @ q))
            # Only the registered QR(A.T Q)->SVD(R.T) coordinate rule is
            # authoritative. Direct compressed-B SVD is a different FP32 rule.
            _, triangular = torch.linalg.qr(a.T @ q, mode="r")
            left, _, _ = torch.linalg.svd(triangular.T, full_matrices=False, driver="gesvd" if a.is_cuda else None)
            self.basis = reference_qr(q @ left[:, :2])
            for column in range(2):
                pivot = self.basis[:, column].abs().argmax()
                if self.basis[pivot, column] < 0:
                    self.basis[:, column].neg_()
            if old_basis is not None:
                state = self.optimizer.state[self.coordinates]
                mean, second = dense_transport(
                    dict(
                        step=completed,
                        basis=old_basis.T if self.right else old_basis,
                        exp_avg=state["exp_avg"],
                        exp_avg_sq=state["exp_avg_sq"],
                    ),
                    self.basis.T if self.right else self.basis,
                    self.right,
                    self.betas,
                )
                state["exp_avg"].copy_(mean)
                state["exp_avg_sq"].copy_(second)
        projected = (self.basis.T @ a).T if self.right else self.basis.T @ a
        with torch.no_grad():
            self.coordinates.zero_()
        self.coordinates.grad = projected
        self.optimizer.step()
        lifted = self.basis @ self.coordinates.detach().T if self.right else self.basis @ self.coordinates.detach()
        self.weight = old_weight * (1 - self.lr * self.decay) + 1.0 * (lifted.T if self.right else lifted)
        self.step += 1


def compare(left, right):
    torch.testing.assert_close(left, right, atol=1e-6, rtol=1e-4)
    error = (left - right).abs()
    return {
        "max_absolute_error": float(error.max()),
        "max_normalized_error": float((error / (1e-6 + 1e-4 * right.abs())).max()),
    }


def exact(left, right):
    if isinstance(left, torch.Tensor):
        assert left.shape == right.shape and left.dtype == right.dtype
        assert torch.equal(left.reshape(-1).view(torch.uint8), right.reshape(-1).view(torch.uint8))
    elif isinstance(left, dict):
        assert left.keys() == right.keys()
        for key in left:
            exact(left[key], right[key])
    elif isinstance(left, (list, tuple)):
        assert type(left) is type(right) and len(left) == len(right)
        for a, b in zip(left, right, strict=True):
            exact(a, b)
    else:
        assert left == right


def case(shape, device, stress):
    generator = torch.Generator().manual_seed(593)
    initial = torch.randn(shape, generator=generator).to(device)
    parameter = torch.nn.Parameter(initial.clone())
    options = dict(
        lr=0.003 if stress else 1e-5,
        betas=(0.9, 0.95),
        weight_decay=0.1 if stress else 0.01,
        eps=1e-4 if stress else 1e-8,
        rank=2,
        update_proj_gap=3,
        scale=1.0,
        projector_backend="recycled",
        projector_oversampling=16,
        projector_seed=17,
        compact_master=True,
        tile_rows=16384,
        release_gradients=True,
        fused_writeback=True,
        transport_moments=True,
        exclude_vocab=False,
    )
    actual = GaLoreAdamW([parameter], **options)
    reference = Scale1Reference(
        initial, lr=options["lr"], betas=options["betas"], decay=options["weight_decay"], eps=options["eps"]
    )
    resumed, replacement = None, None
    comparisons, refreshes = [], []
    previous = torch.get_float32_matmul_precision()
    torch.set_float32_matmul_precision("high")
    try:
        for step in range(10):
            gradient = torch.randn(shape, generator=generator).to(device)
            parameter.main_grad = gradient.clone()
            actual.step()
            reference.update(gradient)
            assert torch.get_float32_matmul_precision() == "high"
            row = dict(step=step, weight=compare(parameter, reference.weight))
            for name in ("exp_avg", "exp_avg_sq"):
                row[name] = compare(
                    actual.state[parameter][name], reference.optimizer.state[reference.coordinates][name]
                )
            row["basis"] = compare(
                actual.state[parameter]["basis"], reference.basis.T if reference.right else reference.basis
            )
            if actual.last_projection_refresh:
                refreshes.append(step)
            if resumed is not None:
                replacement.main_grad = gradient.clone()
                resumed.step()
                exact(actual.state_dict(), resumed.state_dict())
                exact(parameter, replacement)
                row["continuous_resumed_exact"] = True
            comparisons.append(row)
            if step == 2:
                replacement = torch.nn.Parameter(torch.zeros_like(parameter))
                resumed = GaLoreAdamW([replacement], lr=9, rank=1)
                resumed.load_state_dict(actual.state_dict())
                exact(actual.state_dict(), resumed.state_dict())
                exact(parameter, replacement)
        assert refreshes == [0, 3, 6, 9]
    finally:
        torch.set_float32_matmul_precision(previous)
    return dict(
        shape=list(shape),
        dtype="float32",
        device=device,
        options=options,
        refresh_updates=refreshes,
        save_after_completed_updates=3,
        next_update_is_refresh=True,
        comparisons=comparisons,
        max_weight_absolute_error=max(row["weight"]["max_absolute_error"] for row in comparisons),
        exact_optimizer_resume=True,
    )


def byte_proof():
    generator = torch.Generator().manual_seed(593)
    parameter = torch.nn.Parameter(torch.randn(1024, 1024, generator=generator))
    optimizer = GaLoreAdamW(
        [parameter],
        lr=1e-5,
        rank=128,
        scale=1,
        projector_backend="recycled",
        projector_oversampling=16,
        transport_moments=True,
        exclude_vocab=False,
    )
    parameter.main_grad = torch.randn(1024, 1024, generator=generator)
    optimizer.step()
    state = optimizer.state[parameter]
    sizes = {
        name: value.numel() * value.element_size() for name, value in state.items() if isinstance(value, torch.Tensor)
    }
    gpu_equivalent = sizes["exp_avg"] + sizes["exp_avg_sq"] + sizes["basis"]
    total = gpu_equivalent + sizes["projector_rng_state"]
    ordinary_moments = 2 * parameter.numel() * 4
    reference_parameter = torch.nn.Parameter(parameter.detach().clone())
    reference = torch.optim.AdamW([reference_parameter], lr=1e-5, betas=(0.9, 0.95), weight_decay=0.01)
    reference_parameter.grad = parameter.main_grad.clone()
    reference.step()
    reference_bytes = {
        name: value.numel() * value.element_size()
        for name, value in reference.state[reference_parameter].items()
        if isinstance(value, torch.Tensor)
    }
    assert reference_bytes["exp_avg"] + reference_bytes["exp_avg_sq"] == ordinary_moments
    assert gpu_equivalent == 1572864 and total < ordinary_moments
    assert total + sizes["master"] < sum(reference_bytes.values())
    return dict(
        shape=[1024, 1024],
        rank=128,
        precision="float32",
        actual_tensor_bytes=sizes,
        moments_plus_basis_bytes=gpu_equivalent,
        cpu_private_rng_bytes=sizes["projector_rng_state"],
        total_state_including_private_rng_bytes=total,
        adamw_same_precision_moments_bytes=ordinary_moments,
        galore_actual_master_bytes=sizes["master"],
        galore_all_optimizer_tensor_bytes=total + sizes["master"],
        pytorch_fp32_adamw_actual_state_tensor_bytes=reference_bytes,
        pytorch_fp32_adamw_all_state_tensor_bytes=sum(reference_bytes.values()),
        criterion_pass=True,
        all_optimizer_tensor_bytes_including_master_less_than_adamw=True,
        scope="measured persistent optimizer tensor bytes; PyTorch FP32 AdamW uses model weights as masters; model/gradients/activations/workspace/Python metadata excluded; native bucket optimizer storage is separately benchmarked",
    )


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    cases = [case(shape, args.device, stress) for shape in ((9, 9), (13, 9), (9, 13)) for stress in (False, True)]
    result = dict(
        timestamp=datetime.now(UTC).isoformat(),
        runtime_repo_sha256=source_sha(),
        sha_policy="sorted areno/*.py recursively; relative repo path including areno/ prefix plus file bytes",
        status="passed",
        criterion=dict(atol=1e-6, rtol=1e-4),
        cases=cases,
        byte_proof=byte_proof() if args.device == "cpu" else None,
        limits=[
            "Small matrices use rank2/gap3 to exercise repeated refresh and exact resume; final-scale1 scalar settings plus nonzero-epsilon/decay stress case",
            "Independent reference reuses separate QR/Ritz implementation, torch.optim.AdamW and explicit dense covariance transport, not production update/projector helpers",
            "FP32 compact/fused flags correctly retain ordinary FP32 master fallback; real BF16 compact/fused path is tested by public-Trainer smoke",
        ],
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            dict(
                status=result["status"],
                cases=len(cases),
                max_weight_absolute_error=max(r["max_weight_absolute_error"] for r in cases),
            )
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
