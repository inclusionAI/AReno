"""Audit strict-path interchangeability without modifying either implementation."""

from __future__ import annotations

import argparse
import ast
import copy
import hashlib
import importlib.util
import io
import json
import os
from datetime import UTC, datetime
from pathlib import Path

import torch


def same(a, b, path="root"):
    if isinstance(a, torch.Tensor):
        assert isinstance(b, torch.Tensor), path
        assert a.dtype == b.dtype and a.shape == b.shape, path
        assert torch.equal(a.cpu(), b.cpu()), path
        return 1
    if isinstance(a, dict):
        assert a.keys() == b.keys(), path
        return sum(same(a[k], b[k], f"{path}.{k}") for k in a)
    if isinstance(a, (list, tuple)):
        assert type(a) is type(b) and len(a) == len(b), path
        return sum(same(x, y, f"{path}[{i}]") for i, (x, y) in enumerate(zip(a, b, strict=True)))
    assert a == b, path
    return 0


def load_class(root, name):
    spec = importlib.util.spec_from_file_location(name, root / "areno/engine/optim/galore.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.GaLoreAdamW


def transport(payload):
    stream = io.BytesIO()
    torch.save(payload, stream)
    stream.seek(0)
    return torch.load(stream, map_location="cpu", weights_only=False)


def run_case(classes, device, dtype, rank, shape):
    generator = torch.Generator().manual_seed(593)
    shapes = [shape, shape[::-1], (13,)]
    initial = [torch.randn(s, generator=generator) for s in shapes]
    # The normalization owner stays FP32, matching the actual model contract.
    groups = [
        [torch.nn.Parameter(x.to(device=device, dtype=dtype if x.ndim == 2 else torch.float32).clone()) for x in initial]
        for _ in range(2)
    ]
    settings = dict(
        lr=1e-5, rank=rank, update_proj_gap=3, scale=1,
        betas=(0.9, 0.95), weight_decay=0.01,
        projector_backend="recycled", projector_oversampling=16,
        projector_iterations=1, projector_seed=0, projector_final_qr=True,
        compact_master=True, tile_rows=16384, release_gradients=True,
        fused_writeback=True, transport_moments=True,
    )
    optimizers = [cls(params, **settings) for cls, params in zip(classes, groups, strict=True)]
    compared_tensors = 0
    refreshes = []
    rng_before = torch.get_rng_state().clone()
    for step in range(8):
        gradients = [torch.randn(s, generator=generator).to(device) for s in shapes]
        for optimizer, params in zip(optimizers, groups, strict=True):
            for param, gradient in zip(params, gradients, strict=True):
                param.main_grad = gradient.clone()
            optimizer.step()
        if device == "cuda":
            torch.cuda.synchronize()
        for a, b in zip(groups[0], groups[1], strict=True):
            compared_tensors += same(a, b, f"step{step}.parameter")
            assert a.main_grad is None and b.main_grad is None
        compared_tensors += same(optimizers[0].state_dict(), optimizers[1].state_dict(), f"step{step}.checkpoint")
        assert optimizers[0].last_projection_refresh == optimizers[1].last_projection_refresh
        if optimizers[0].last_projection_refresh:
            refreshes.append(step)
        if step in (2, 3):
            # Bidirectional cross-loading before and after the refresh boundary.
            snapshots = [transport(optimizer.state_dict()) for optimizer in optimizers]
            replacements = [[torch.nn.Parameter(torch.zeros_like(p)) for p in params] for params in groups]
            restored = [cls(params, lr=0.5) for cls, params in zip(classes, replacements, strict=True)]
            restored[0].load_state_dict(snapshots[1])
            restored[1].load_state_dict(snapshots[0])
            compared_tensors += same(restored[0].state_dict(), snapshots[1])
            compared_tensors += same(restored[1].state_dict(), snapshots[0])
            for old_params, new_params in zip(groups, replacements, strict=True):
                for old, new in zip(old_params, new_params, strict=True):
                    compared_tensors += same(old, new)
            groups, optimizers = replacements, restored
    assert torch.equal(torch.get_rng_state(), rng_before)
    # A later owner fails after earlier owner validation, without publishing
    # partial state, hyperparameters, parameters or changing global RNG.
    for optimizer, params in zip(optimizers, groups, strict=True):
        before = optimizer.state_dict()
        bad = copy.deepcopy(before)
        bad["state"][1]["exp_avg"] = torch.zeros(1)
        weights = [p.detach().clone() for p in params]
        try:
            optimizer.load_state_dict(bad)
        except ValueError as error:
            assert "shape" in str(error)
        else:
            raise AssertionError("malformed later owner accepted")
        same(before, optimizer.state_dict())
        for old, param in zip(weights, params, strict=True):
            same(old, param)
    return dict(device=device, dtype=str(dtype), rank=rank, shape=shape, updates=8,
                refresh_steps=refreshes, bidirectional_cross_load_after_steps=[2,3],
                exact_tensor_comparisons=compared_tensors, late_owner_rejection_atomic=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--final-repo", type=Path, required=True)
    parser.add_argument("--experiment-repo", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--device", choices=["cpu", "cuda"], required=True)
    args = parser.parse_args()
    os.environ["ARENO_EXPERIMENT_MODEL_OWNED_MASTER"] = "0"
    started_at = datetime.now(UTC).isoformat()
    classes = [load_class(args.final_repo, "delivery_final"), load_class(args.experiment_repo, "delivery_experiment")]
    sources = {}
    for label, root in [("final",args.final_repo),("experiment",args.experiment_repo)]:
        sources[label] = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
                          for p in sorted((root / "areno").rglob("*.py"))}
    changed = [name for name in sorted(set(sources["final"]) | set(sources["experiment"]))
               if sources["final"].get(name) != sources["experiment"].get(name)]
    aggregate_sources = {}
    function_asts = {}
    for label,root in [("final",args.final_repo),("experiment",args.experiment_repo)]:
        aggregate = hashlib.sha256()
        for path in sorted((root / "areno").rglob("*.py")):
            aggregate.update(str(path.relative_to(root)).encode())
            aggregate.update(path.read_bytes())
        aggregate_sources[label] = aggregate.hexdigest()
        module = ast.parse((root / "areno/engine/optim/galore.py").read_text())
        cls = next(node for node in module.body if isinstance(node,ast.ClassDef) and node.name == "GaLoreAdamW")
        function_asts[label] = {node.name:ast.dump(node,include_attributes=False) for node in cls.body if isinstance(node,ast.FunctionDef)}
    cases = []
    shapes = [(32,16,2)] if args.device == "cpu" else [(512,256,128),(32768,128,16)]
    for rows, cols, rank in shapes:
        for dtype in (torch.float32, torch.bfloat16):
            cases.append(run_case(classes,args.device,dtype,rank,(rows,cols)))
    result = dict(status="passed", model_owned_env="0", changed_runtime_python_files=changed,
                  started_at_utc=started_at,completed_at_utc=datetime.now(UTC).isoformat(),
                  cuda_visible_devices=os.getenv("CUDA_VISIBLE_DEVICES"),cpu_affinity=sorted(os.sched_getaffinity(0)),
                  torch_version=torch.__version__,cuda_version=torch.version.cuda,
                  gpu_name=torch.cuda.get_device_name(0) if args.device == "cuda" else None,
                  runtime_sha256=aggregate_sources,
                  unchanged_function_asts=[name for name in function_asts["final"] if function_asts["final"][name] == function_asts["experiment"][name]],
                  changed_function_asts=[name for name in function_asts["final"] if function_asts["final"][name] != function_asts["experiment"][name]],
                  source_files=sources, cases=cases,
                  limits=["Dynamic equality is limited to the enumerated cases; it is not a formal universal proof.",
                          "Checkpoint rejection/acceptance intentionally differs for explicit incompatible legacy policies."])
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps({"status":result["status"],"cases":cases,"changed":changed}),flush=True)


if __name__ == "__main__":
    main()
