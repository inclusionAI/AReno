#!/usr/bin/env bash
set -euo pipefail
root_dir=/mnt2/ling/areno-galore
acceptance_dir="$root_dir/runs/pr_round_20261029/acceptance/scale2"
source "$root_dir/env.sh"
export CUDA_VISIBLE_DEVICES=0 OMP_NUM_THREADS=4
export PYTHONPATH="$root_dir/runs/pr_round_20261029/candidate-pr:$acceptance_dir"
if [[ ${SCALE2_ACCEPTANCE_GPU_LOCKED:-0} != 1 ]]; then
    export SCALE2_ACCEPTANCE_GPU_LOCKED=1
    exec flock "$root_dir/runs/gpu0.lock" "$0" "$@"
fi
occupied=$(nvidia-smi -i 0 --query-compute-apps=pid --format=csv,noheader)
if [[ -n $occupied ]]; then
    echo "GPU0 occupied after project lock; no acceptance GPU work launched: $occupied" >&2
    exit 2
fi
date -Is
nvidia-smi -i 0 --query-gpu=index,uuid,memory.used,utilization.gpu --format=csv
taskset -c 36-39 python "$acceptance_dir/numerics.py" --device cuda --output "$acceptance_dir/numerics-cuda.json"
exec taskset -c 36-39 python "$acceptance_dir/trainer_resume.py" \
    --data-dir "$root_dir/data-repo-text" \
    --checkpoint-dir "$acceptance_dir/prefix" --output-dir "$acceptance_dir"
