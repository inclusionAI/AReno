# Selected scale2 numerical and public-Trainer acceptance

This is verification of the frozen candidate, not a new optimizer experiment. Runtime files under `candidate-pr/areno` are unchanged. The expected runtime digest is `142c7be2c33f871badad4105bd682d4e34da3d3c32e17278dba67324e45c21e1`, computed from sorted Python files using paths relative to the repo, including the `areno/` prefix, followed by file bytes. This differs from the older benchmark's package-relative hash convention. The actual benchmark helper and acceptance scripts are fingerprinted separately.

## Independent numerical proof

`numerics.py` specializes the existing independent `IndependentReference`: its separate QR/Ritz sequence constructs bases, `torch.optim.AdamW` evolves projected coordinates, and an explicit dense covariance calculation transports moments. It does not call production projector/update/transport helpers. All cases use scale2, recycled final-QR projection and transport, with all-matrix targeting (`exclude_vocab=False`).

Square 9×9, tall 13×9 and wide 9×13 FP32 matrices each run ten updates with deterministic seeds. One setting uses the final scalar settings (lr1e-5,betas0.9/0.95,decay0.01,eps1e-8); another stresses nonzero decay/epsilon (lr0.003,decay0.1,eps1e-4). Rank2/gap3 deliberately exercises refreshes at 0/3/6/9. After three completed updates, restore occurs immediately before update 3's refresh. Both continuous and restored paths remain independently checked against the reference; their model and complete optimizer tensor/scalar payloads must also match exactly. The unchanged reference criterion is atol1e-6,rtol1e-4. Caller matmul precision is checked after every update.

`numerics-cpu.json` records six passing cases; maximum weight absolute error is2.384185791015625e-7. `numerics-cuda.json` records six passing cases with maximum weight error1.1920928955078125e-7. Exact errors for weights, bases and moments are retained for every update. All satisfy the combined unchanged atol/rtol criterion; the largest CUDA second-moment absolute difference is1.043081283569336e-6, which passes its relative allowance. `summary.json`/`done.json` now consolidate both devices and the successful real Trainer proof.

The first CUDA attempt stopped inside an auxiliary assertion of the older independent helper: direct compressed-B SVD and registered QR-Ritz basis coordinates differed by6.616115570068359e-6. That is a different FP32 factorization, not the requested same-rule oracle. `gpu0-reference-aux-failure.log` preserves this evidence. The acceptance specialization reuses the independent class initialization/precision wrapper, QR helper, torch AdamW and dense covariance transport, and implements only the registered QR(A.TQ)→SVD(R.T) coordinate rule. Seeds, gradients, shapes and acceptance thresholds were unchanged. No production-vs-reference check was removed.

`test-oracle.patch` gives the corresponding minimal test-only correction to `tests/test_recycled_galore_cpu.py`: remove six auxiliary direct-B lines while preserving the registered reference and every original production parameter/basis/moment comparison at1e-6/1e-4. This agent did not modify candidate-pr; the parent reviewed and committed it as8ccfc006092f75c4f7dca4f4750944412c860fff. An isolated patched-module CPU focused regression passes50 cases, with29 CUDA cases skipped in that CPU-only invocation. The final whole-repository test below subsequently covers the patched module with real CUDA visible.

## 1024×1024, rank128 byte proof

The CPU proof materializes actual production state on a1024² FP32 parameter. Two moments plus persistent basis use1,572,864bytes. Private CPU RNG adds5,056bytes, for1,577,920bytes versus8,388,608bytes of ordinary FP32 AdamW moments. The comparison counts the basis and RNG, not just compressed moments.

The actual GaLore FP32 master is separately counted (4,194,304bytes), giving5,772,224 total optimizer tensor bytes. A real `torch.optim.AdamW` state is also counted, including its step scalar; FP32 model weights act as that optimizer's masters. Native bucket-optimizer storage and actual-model total peaks remain separate benchmark results. An earlier CPU JSON preserved a normalized “common master” convention; `numerics-cpu.pre-baseline-accounting.json` is historical, and the current JSON uses actual measured reference state to avoid implying identical resident master representations.

## Actual public-Trainer save/load/update

`run_gpu0.sh` waits for `runs/gpu0.lock`, then refuses any remaining compute process before launching on physical GPU0 and CPU36–39. It first runs the small CUDA reference cases, then invokes `trainer_resume.py`. No other GPU is used.

The real model is pinned Qwen3-0.6B with BF16 compute/FP32 norms and optimizer, native attention, batch2/context64 on the old fixed tiny training fold. The selected scale2/recycled/compact/fused/transport/all-matrix configuration is used; gap4 is an explicit refresh-boundary engineering stress rather than the final quality run's gap200. No validation/test quality value is used.

Public Trainer performs four updates, saves one prefix checkpoint, records its live probe and exact next-batch cursor/hash, and closes. A fresh public Trainer restores that prefix. A process-local load observer immediately compares the live restored canonical masters, moments, bases, private/global RNG, schedule, parameter order and worker clock against the sidecar, before scoring or backward. Its read-only `state_dict` snapshot is held only in host memory and is not written as a second checkpoint.

The restored probe, SDK step3 and next batch match exactly; the next indices are[11,27] with the same recorded token hash. The immediate live restored state matches906 tensors/3,040,529,296bytes plus all scalar metadata. Two further public SFT updates at absolute indices4/5 complete, with actual refresh at4 and no refresh at5. All six updates emit native same-path `logp_abs_diff_mean=0`. No continuation checkpoint is saved. The one prefix occupies4,249,022,232bytes (<5GiB). Complete counts and outcomes appear in `immediate-state-restore.json`, `trainer-resume-proof.json` and consolidated `summary.json`. GPU0 has been released.

This proves immediate complete-state/probe/cursor restoration and successful real resumed updates. It does not claim bitwise equality of entire uninterrupted and restored native BF16 trajectories: the previously diagnosed custom backward nondeterminism is unchanged and is not re-investigated here. Final three-seed learning quality, whole-model memory/workspace and throughput are separate parent acceptance evidence.

`verify_events.py` independently reads the actual TensorBoard scalar files. The native `train/logp_abs_diff_mean` tag is present at prefix steps0–3 and resumed steps4–5, and all six recorded values are exactly zero. `native-sft-events.json` contains those events; this is not a substitute metric recomputation.

## Final post-oracle repository check

After the test-only correction, the actual clean8ccfc00 tree was tested on physical GPU2, CPU52–55, with real CUDA availability and normal plugin loading. The unmodified command was `python -m pytest tests/ -k cpu -q` plus an explicit project-local cache directory. No fake availability or stub was injected. It completed with exit0:1805 passed,28 skipped,2222 deselected,12 subtests passed,91 warnings in138.63s. The CPU-keyword selection includes CUDA parameterizations in `test_recycled_galore_cpu.py`, so the corrected oracle was exercised on CUDA as well. Runtime remained142c7 throughout. See `../post-oracle-full-suite.json` and its raw log; GPU2 was released immediately afterwards. No further full-suite repetition is required by this acceptance task.

## Reproduction

Source `/mnt2/ling/areno-galore/env.sh`, set `PYTHONPATH` to `candidate-pr` and this directory, and use CPU36–39. Run `numerics.py --device cpu --output numerics-cpu.json` for CPU proof. The guarded `run_gpu0.sh` performs the GPU proof and one-prefix integration test; it refuses an existing prefix rather than overwriting evidence. After successful completion, run `verify_events.py` and `summarize.py` to create the native-event check, consolidated JSON and done sentinel. Raw outputs and source fingerprints remain in this directory.
