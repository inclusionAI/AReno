"""Verify actual native Trainer TensorBoard events without recomputing a metric."""

from __future__ import annotations

import json
from pathlib import Path

from tensorboard.backend.event_processing.event_accumulator import EventAccumulator


def main():
    root = Path(__file__).resolve().parent
    result = {}
    for name, expected_steps in (("events-prefix", [0, 1, 2, 3]), ("events-resume", [4, 5])):
        accumulator = EventAccumulator(str(root / name))
        accumulator.Reload()
        tag = "train/logp_abs_diff_mean"
        assert tag in accumulator.Tags()["scalars"]
        events = [dict(step=row.step, value=row.value, wall_time=row.wall_time) for row in accumulator.Scalars(tag)]
        assert [row["step"] for row in events] == expected_steps
        assert all(row["value"] == 0 for row in events)
        result[name] = dict(tag=tag, events=events)
    (root / "native-sft-events.json").write_text(
        json.dumps(
            dict(
                status="passed",
                source="actual Trainer TensorBoard scalar events, no substitute calculation",
                runs=result,
            ),
            indent=2,
        )
        + "\n"
    )
    print("native train/logp_abs_diff_mean: six actual events are exactly zero", flush=True)


if __name__ == "__main__":
    main()
