"""Consolidate executed acceptance evidence; fails until every gate completes."""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, datetime
from pathlib import Path


def main():
    root = Path(__file__).resolve().parent
    cpu = json.loads((root / "numerics-cpu.json").read_text())
    gpu = json.loads((root / "numerics-cuda.json").read_text())
    trainer = json.loads((root / "trainer-resume-proof.json").read_text())
    metadata = json.loads((root / "metadata.json").read_text())
    expected = "142c7be2c33f871badad4105bd682d4e34da3d3c32e17278dba67324e45c21e1"
    assert {r["runtime_repo_sha256"] for r in (cpu, gpu, trainer, metadata)} == {expected}
    for report in (cpu, gpu):
        assert report["status"] == "passed" and len(report["cases"]) == 6
        for case in report["cases"]:
            assert case["exact_optimizer_resume"] and case["options"]["scale"] == 2
            assert case["refresh_updates"] == [0, 3, 6, 9]
            for row in case["comparisons"]:
                for name in ("weight", "basis", "exp_avg", "exp_avg_sq"):
                    assert row[name]["max_normalized_error"] <= 1
    assert cpu["byte_proof"]["criterion_pass"]
    assert trainer["status"] == "passed" and trainer["complete_immediate_state"]["exact_match"]
    assert trainer["probe_exact"] and trainer["next_batch_exact"] and trainer["actual_refreshed_update4"]
    assert trainer["native_logp_abs_diff_max"] == 0 and trainer["continuation_updates"] == [4, 5]
    assert not trainer["continuation_checkpoint_saved"] and trainer["checkpoint_bytes"] < 5 * 2**30
    assert len(list(root.rglob("training_state.pt"))) == 1
    errors = {}
    for device, report in [("cpu", cpu), ("cuda", gpu)]:
        errors[device] = {}
        for name in ("weight", "basis", "exp_avg", "exp_avg_sq"):
            values = [row[name] for case in report["cases"] for row in case["comparisons"]]
            errors[device][name] = {
                key: max(item[key] for item in values) for key in ("max_absolute_error", "max_normalized_error")
            }
    result = dict(
        timestamp=datetime.now(UTC).isoformat(),
        status="numerical_and_public_trainer_acceptance_passed_quality_separate",
        runtime_repo_sha256=expected,
        sha_policy=cpu["sha_policy"],
        criterion=cpu["criterion"],
        independent_cases_cpu=6,
        independent_cases_cuda=6,
        max_errors=errors,
        byte_proof=cpu["byte_proof"],
        public_trainer=trainer,
        files={
            name: hashlib.sha256((root / name).read_bytes()).hexdigest()
            for name in [
                "numerics.py",
                "trainer_resume.py",
                "run_gpu0.sh",
                "numerics-cpu.json",
                "numerics-cuda.json",
                "trainer-resume-proof.json",
                "metadata.json",
            ]
        },
        limits=[
            "Small-matrix stress usesrank2/gap3; actual1024²byteproof usesrank128; realBF16smoke usesrank128/gap4 stress, not finalgap200",
            "Final scale2/all-matrix learning quality and whole-run memory/throughput are established separately by parent three-seed runs",
            "No exact uninterrupted-versus-restored nativeBF16 trajectory claim; immediate state/probe/cursor equality and successful resumed updates are distinct evidence",
        ],
        earlier_attempts=[
            dict(
                status="failed_auxiliary_different_factorization_coordinate_assumption",
                log="gpu0-reference-aux-failure.log",
                assertion="old independent helper additionally compared direct compressed-B SVD coordinates against the registered QR-Ritz coordinates",
                maximum_absolute_basis_difference=6.616115570068359e-6,
                resolution="same independent QR/torchAdamW reference specialized to the registered QR(A.T Q)->SVD(R.T) rule only",
                acceptance_tolerances_changed=False,
                numerical_test_inputs_changed=False,
            )
        ],
    )
    if (root / "native-sft-events.json").exists():
        events = json.loads((root / "native-sft-events.json").read_text())
        assert events["status"] == "passed"
        result["native_sft_tensorboard_events"] = events
        result["files"]["native-sft-events.json"] = hashlib.sha256(
            (root / "native-sft-events.json").read_bytes()
        ).hexdigest()
    if (root / "test-oracle.patch").exists():
        result["test_oracle_correction"] = dict(
            patch="test-oracle.patch",
            patch_sha256=hashlib.sha256((root / "test-oracle.patch").read_bytes()).hexdigest(),
            applied_by_this_agent=False,
            parent_applied_commit="8ccfc006092f75c4f7dca4f4750944412c860fff",
            isolated_patched_module_cpu_passed=50,
            cuda_skipped_in_cpu_only_run=29,
            cpu_log="oracle-check/cpu-regression-clean.log",
            production_comparisons_and_tolerances_unchanged=True,
        )
    repository_record = root.parent / "post-oracle-full-suite.json"
    if repository_record.exists():
        repository = json.loads(repository_record.read_text())
        assert repository["status"] == "passed" and repository["exit_code"] == 0
        assert repository["runtime_source_sha256"] == expected
        result["post_oracle_final_repository_check"] = dict(
            record="../post-oracle-full-suite.json",
            status=repository["status"],
            git_commit=repository["git_commit"],
            passed=repository["passed"],
            skipped=repository["skipped"],
            subtests_passed=repository["subtests_passed"],
            seconds=repository["seconds"],
            real_cuda_visible=True,
        )
    (root / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    (root / "done.json").write_text(
        json.dumps(
            dict(
                timestamp=result["timestamp"],
                status=result["status"],
                runtime_repo_sha256=expected,
                numerical_cases_passed=12,
                persistent_bytes_pass=True,
                immediate_complete_state_exact=True,
                public_prefix_resume_pass=True,
                gpu0_released=True,
                one_prefix_checkpoint_only=True,
                quality_separate=True,
            ),
            indent=2,
        )
        + "\n"
    )
    print(
        json.dumps(
            dict(
                status=result["status"],
                max_weight_error={key: value["weight"]["max_absolute_error"] for key, value in errors.items()},
            )
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
