"""Actual scale2 public-Trainer prefix save/load/continuation, one checkpoint."""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import random
from datetime import UTC, datetime
from pathlib import Path

import torch
from numerics import EXPECTED_SHA, REPO, source_sha
from scripts.bench_galore import encode

import areno
from areno import Trainer
from areno.api import CudaConfig, sft_loss_fn


def write(path, payload):
    Path(path).write_text(json.dumps(payload, indent=2) + "\n")


def install_restore_audit():
    from areno.engine import worker as worker_module
    from areno.engine.checkpoints import training_state as state_io

    original = state_io.load_training_state

    def checked_load(worker, path):
        original(worker, path)
        expected = torch.load(Path(path) / "training_state.pt", map_location="cpu", weights_only=True, mmap=True)
        actual = {
            "format": "areno-training-v1",
            "optimizer_class": type(worker.optimizer).__name__,
            "parameter_names": [name for name, param in worker.model.named_parameters() if param.requires_grad],
            "optimizer": worker.optimizer.state_dict(),
            "global_step": worker._global_step,
            "schedule": {name: getattr(worker, name) for name in state_io._SCHEDULE_FIELDS},
            "torch_rng": torch.get_rng_state(),
            "cuda_rng": torch.cuda.get_rng_state(worker.device),
        }
        mismatches, counts = [], {"tensors": 0, "tensor_bytes": 0}

        def compare(left, right, key="root"):
            if isinstance(left, torch.Tensor):
                counts["tensors"] += 1
                counts["tensor_bytes"] += left.numel() * left.element_size()
                if not isinstance(right, torch.Tensor) or left.shape != right.shape or left.dtype != right.dtype:
                    mismatches.append(key + ".shape/dtype")
                elif not torch.equal(
                    left.contiguous().reshape(-1).view(torch.uint8), right.contiguous().reshape(-1).view(torch.uint8)
                ):
                    mismatches.append(key + ".bits")
            elif isinstance(left, dict):
                if not isinstance(right, dict) or left.keys() != right.keys():
                    mismatches.append(key + ".keys")
                    return
                for name in left:
                    compare(left[name], right[name], f"{key}.{name}")
            elif isinstance(left, (tuple, list)):
                if type(left) is not type(right) or len(left) != len(right):
                    mismatches.append(key + ".type/length")
                    return
                for index, (a, b) in enumerate(zip(left, right, strict=True)):
                    compare(a, b, f"{key}[{index}]")
            elif left != right:
                mismatches.append(key)

        compare(expected, actual)
        result = dict(
            timestamp=datetime.now(UTC).isoformat(),
            exact_match=not mismatches,
            mismatches=mismatches,
            **counts,
            worker_completed_updates=worker._global_step,
            parameter_owners=len(actual["parameter_names"]),
            runtime_repo_sha256=source_sha(),
            scope="immediate live restored canonical masters/moments/bases/private RNG/global RNG/schedule/clock/names compared to saved sidecar before scoring/backward",
        )
        write(Path(os.environ["ARENO_SCALE2_ACCEPTANCE_DIR"]) / "immediate-state-restore.json", result)
        assert not mismatches, "immediate live state restoration mismatch"

    state_io.load_training_state = checked_load
    worker_module.load_training_state = checked_load


if os.environ.get("ARENO_SCALE2_ACCEPTANCE_DIR"):
    install_restore_audit()


def digest(tokens):
    return hashlib.sha256(json.dumps(tokens, separators=(",", ":")).encode()).hexdigest()


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--checkpoint-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--model", default="/mnt2/ling/areno-galore/models/Qwen3-0.6B")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    assert Path(areno.__file__).resolve().parent.parent == REPO
    assert source_sha() == EXPECTED_SHA
    if args.checkpoint_dir.exists():
        raise RuntimeError("refuse to overwrite acceptance prefix checkpoint")
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[logging.FileHandler(args.output_dir / "trainer.log"), logging.StreamHandler()],
    )
    os.environ["ARENO_SCALE2_ACCEPTANCE_DIR"] = str(args.output_dir)
    os.environ["ARENO_BENCH_SEED"] = "0"
    random.seed(0)
    torch.manual_seed(0)
    optimizer = dict(
        lr=1e-5,
        min_lr=1e-5,
        betas=(0.9, 0.95),
        weight_decay=0.01,
        grad_clip_norm=1,
        galore_rank=128,
        galore_update_proj_gap=4,
        galore_scale=2,
        galore_projector_backend="recycled",
        galore_projector_oversampling=16,
        galore_projector_iterations=1,
        galore_projector_seed=0,
        galore_projector_final_qr=True,
        galore_compact_master=True,
        galore_tile_rows=16384,
        galore_release_gradients=True,
        galore_fused_writeback=True,
        galore_transport_moments=True,
        galore_exclude_vocab=False,
        save_training_state=True,
    )
    runtime = dict(
        attn_backend="native",
        compile_model=False,
        activation_checkpointing=True,
        keep_rollout_state=True,
        profile_training=True,
    )
    metadata = dict(
        timestamp=datetime.now(UTC).isoformat(),
        runtime_repo_sha256=source_sha(),
        source_root=str(REPO),
        sha_policy="relative repo path including areno/ prefix plus bytes",
        script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        benchmark_helper_sha256=hashlib.sha256((REPO / "scripts/bench_galore.py").read_bytes()).hexdigest(),
        native_extension_sha256=hashlib.sha256(
            next((REPO / "areno/accel").glob("_areno_accel*.so")).read_bytes()
        ).hexdigest(),
        optimizer=optimizer,
        runtime=runtime,
        data_sha256=hashlib.sha256((args.data_dir / "train.jsonl").read_bytes()).hexdigest(),
        dtype="BF16 model with FP32 norms/optimizer",
        batch=2,
        context=64,
        seed=0,
        cuda_visible_devices=os.getenv("CUDA_VISIBLE_DEVICES"),
        cpu_affinity=sorted(os.sched_getaffinity(0)),
        limits="engineering smoke on old tiny fixed training fold; gap4 stress differs finalgap200; not convergence or strict native trajectory evidence",
    )
    write(args.output_dir / "metadata.json", metadata)

    def make(resume):
        opt = dict(optimizer, resume_training_state=resume)
        return Trainer(
            world_size=1,
            model_path=str(args.checkpoint_dir if resume else args.model),
            custom_config=CudaConfig(devices=[0], tp_size=1, optimizer=opt, runtime=runtime),
            metrics_log_dir=str(args.output_dir / ("events-resume" if resume else "events-prefix")),
        )

    rows = [json.loads(line) for line in (args.data_dir / "train.jsonl").read_text().splitlines()]
    results = []
    prefix_probe = None
    next_batch = None
    order = []

    def batch_for(training, step):
        indices = [order[(2 * step + i) % len(order)] for i in range(2)]
        return indices, [training[index] for index in indices]

    def train_step(engine, training, step, phase):
        indices, batch = batch_for(training, step)
        scores = engine.score_logprobs("actor", [sample.tokens for sample in batch], microbatch_size=2)
        for sample, values in zip(batch, scores, strict=True):
            sample.logprobs = list(values)
        metrics = engine.train(batch, sft_loss_fn, mini_bs=2)
        assert metrics["logp_abs_diff_mean"] == 0.0
        assert bool(metrics["galore_projection_refresh"]) == (step % 4 == 0)
        assert engine._ctx.global_step == step
        row = dict(
            timestamp=datetime.now(UTC).isoformat(),
            phase=phase,
            step=step,
            sample_indices=indices,
            batch_sha256=digest([sample.tokens for sample in batch]),
            **metrics,
        )
        results.append(row)
        logging.info("step %s", json.dumps(row))

    engine = make(False)
    try:
        engine.init()
        training = encode(engine.get_tokenizer(), rows)
        order = list(range(len(training)))
        random.Random(0).shuffle(order)
        for step in range(4):
            train_step(engine, training, step, "prefix")
        engine.save_checkpoint(str(args.checkpoint_dir))
        assert engine._ctx.global_step == 3
        prefix_probe = engine.score_logprobs("actor", [training[0].tokens], microbatch_size=1)
        indices, batch = batch_for(training, 4)
        next_batch = dict(step=4, sample_indices=indices, batch_sha256=digest([sample.tokens for sample in batch]))
    finally:
        engine.close()

    engine = make(True)
    try:
        engine.init()
        training = encode(engine.get_tokenizer(), rows)
        assert engine._ctx.global_step == 3
        audit = json.loads((args.output_dir / "immediate-state-restore.json").read_text())
        assert audit["exact_match"] and audit["worker_completed_updates"] == 4
        restored_probe = engine.score_logprobs("actor", [training[0].tokens], microbatch_size=1)
        assert prefix_probe == restored_probe
        indices, batch = batch_for(training, engine._ctx.global_step + 1)
        restored_next = dict(step=4, sample_indices=indices, batch_sha256=digest([sample.tokens for sample in batch]))
        assert restored_next == next_batch
        for step in (4, 5):
            train_step(engine, training, step, "restored-continuation")
        summary = dict(
            timestamp=datetime.now(UTC).isoformat(),
            status="passed",
            runtime_repo_sha256=source_sha(),
            complete_immediate_state=audit,
            prefix_completed_updates=4,
            restored_sdk_step=3,
            next_batch_exact=True,
            next_batch=next_batch,
            probe_exact=True,
            probe_logprobs=prefix_probe,
            continuation_updates=[4, 5],
            actual_refreshed_update4=bool(results[4]["galore_projection_refresh"]),
            native_logp_abs_diff_max=max(row["logp_abs_diff_mean"] for row in results),
            final_sdk_step=engine._ctx.global_step,
            prefix_checkpoint=str(args.checkpoint_dir),
            checkpoint_bytes=sum(path.stat().st_size for path in args.checkpoint_dir.rglob("*") if path.is_file()),
            continuation_checkpoint_saved=False,
            limits="No uninterrupted-vs-resumed native BF16 trajectory equality claim; known bespoke backward nondeterminism unchanged",
        )
        assert summary["checkpoint_bytes"] < 5 * 2**30
        write(args.output_dir / "trainer-resume-proof.json", summary)
        write(args.output_dir / "steps.json", results)
    finally:
        engine.close()


if __name__ == "__main__":
    main()
