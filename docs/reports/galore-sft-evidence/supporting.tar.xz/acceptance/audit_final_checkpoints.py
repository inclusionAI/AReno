"""Read-only mmap audit of three selected final optimizer endpoints, CPU only."""
from __future__ import annotations
import hashlib
import ast
import importlib.util
import json
import os
from pathlib import Path
import struct
import time
from collections import Counter
import torch

HERE=Path(__file__).resolve().parent
CENTRAL=HERE.parent
EXPECTED_SOURCE='142c7be2c33f871badad4105bd682d4e34da3d3c32e17278dba67324e45c21e1'

def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda:f.read(16*1024**2),b''):h.update(b)
    return h.hexdigest()
def sig(path):
    s=path.stat();return {'size':s.st_size,'mtime_ns':s.st_mtime_ns,'inode':s.st_ino}
def nbytes(t):return t.numel()*t.element_size()
def tensor_meta(t):return {'dtype':str(t.dtype),'shape':list(t.shape),'bytes':nbytes(t),'device':str(t.device)}
def header(path):
    with path.open('rb') as f:
        length=struct.unpack('<Q',f.read(8))[0];raw=f.read(length)
    return json.loads(raw),hashlib.sha256(raw).hexdigest()
def source_hash():
    repo=CENTRAL/'candidate-pr';h=hashlib.sha256()
    for p in sorted((repo/'areno').rglob('*.py')):h.update(str(p.relative_to(repo)).encode());h.update(p.read_bytes())
    return h.hexdigest()

def main():
    os.sched_setaffinity(0,{56,57,58,59});os.nice(10)
    torch.set_num_threads(4);torch.set_float32_matmul_precision('highest')
    assert source_hash()==EXPECTED_SOURCE
    src=CENTRAL/'candidate-pr/areno/engine/optim'
    tree=ast.parse((src/'galore.py').read_text())
    expected_backend=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='BACKEND_POLICY' for x in n.targets))
    spec=importlib.util.spec_from_file_location('audited_projector_policy',src/'recycled_subspace.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    expected_projector=module.projector_policy(True)
    sha_cache=json.loads((HERE/'completed-state-sha-cache.json').read_text())
    status_path=CENTRAL/'status.json';status_sha=sha(status_path);status=json.loads(status_path.read_text())['jobs']
    started=time.time();results=[];reference_names=None;reference_shapes=None
    for seed in range(3):
        jid=f'final-sft512-1024__galore__s{seed}';state=status[jid];assert state['status']=='complete'
        checkpoint=Path(state['final_checkpoint']);file=checkpoint/'training_state.pt';before=sig(file)
        payload=torch.load(file,mmap=True,map_location='cpu',weights_only=True)
        metadata=json.loads((checkpoint/'training_state.json').read_text());opt=payload['optimizer'];hp=opt['hyperparameters'];names=payload['parameter_names'];shapes=opt['shapes'];rows=opt['state']
        assert payload['format']==metadata['format']=='areno-training-v1'
        assert payload['optimizer_class']==metadata['optimizer_class']=='GaLoreAdamW'
        assert payload['global_step']==metadata['global_step']==1024
        assert opt['backend_policy']==expected_backend and opt['projector_policy']==expected_projector
        assert opt['format']=='areno-galore-v3' and not hp.get('exclude_vocab',False) and 'projection_exclusions' not in opt
        expected=dict(lr=1e-5,betas=(.9,.95),weight_decay=.01,eps=1e-8,rank=128,update_proj_gap=200,scale=2.0,projector_backend='recycled',projector_oversampling=16,projector_iterations=1,projector_seed=seed,projector_final_qr=True,compact_master=True,tile_rows=16384,release_gradients=True,fused_writeback=True,transport_moments=True)
        assert hp==expected,(seed,hp)
        assert len(names)==len(set(names))==len(shapes)==len(rows)==226
        if reference_names is None:reference_names=names;reference_shapes=shapes
        else:assert names==reference_names and shapes==reference_shapes
        totals=Counter();per_owner=[];basis_checks=[];step_counts=Counter();model_dtype_owners=Counter();model_dtype_numel=Counter()
        for index,(name,shape,saved) in enumerate(zip(names,shapes,rows,strict=True)):
            shape=tuple(shape);assert saved['step']==1024
            step_counts[saved['step']]+=1
            master=saved['master'];assert tuple(master.shape)==shape and master.dtype==torch.float32
            projected=len(shape)==2 and 128<min(shape) and 128*(2*max(shape)+min(shape))<2*master.numel()
            expect_moment=((shape[0],128) if shape[0]>=shape[1] else (128,shape[1])) if projected else shape
            if not projected:expect_moment=shape
            for key in ['exp_avg','exp_avg_sq']:
                assert saved[key].dtype==torch.float32 and tuple(saved[key].shape)==expect_moment
            tensor_fields={k:tensor_meta(v) for k,v in saved.items() if isinstance(v,torch.Tensor)}
            for key,value in saved.items():
                if not isinstance(value,torch.Tensor):continue
                totals['canonical_optimizer_tensor_bytes']+=nbytes(value)
                category='full_fp32_master_bytes' if key=='master' else 'projected_moment_bytes' if key in ['exp_avg','exp_avg_sq'] and projected else 'fallback_moment_bytes' if key in ['exp_avg','exp_avg_sq'] else 'basis_bytes' if key=='basis' else 'private_projector_rng_bytes' if key=='projector_rng_state' else 'other_tensor_bytes'
                totals[category]+=nbytes(value)
            if projected:
                b=saved['basis'];assert b.dtype==torch.float32 and b.ndim==2
                expected_basis=(128,shape[1]) if shape[0]>=shape[1] else (shape[0],128)
                assert tuple(b.shape)==expected_basis
                assert saved['projector_parameter_index']==index and saved['projector_refreshes']==6 and saved['transport_count']==5
                rng=saved['projector_rng_state'];assert rng.dtype==torch.uint8 and rng.device.type=='cpu'
                torch.Generator(device='cpu').set_state(rng)
                gram=b@b.T if shape[0]>=shape[1] else b.T@b
                eye=torch.eye(128,dtype=torch.float32);err=(gram-eye).abs()
                close=torch.isclose(gram,eye,atol=1e-6,rtol=1e-4)
                result={'owner_index':index,'name':name,'basis_shape':list(b.shape),'gram_max_abs_error':err.max().item(),'gram_frobenius_error':torch.linalg.vector_norm(gram-eye).item(),'failed_elements':int((~close).sum().item()),'atol':1e-6,'rtol':1e-4,'passed':bool(close.all()),'refreshes':saved['projector_refreshes'],'transports':saved['transport_count'],'projector_rng':tensor_meta(rng),'projector_rng_sha256':hashlib.sha256(rng.numpy().tobytes()).hexdigest(),'cpu_generator_set_state_passed':True}
                basis_checks.append(result)
                assert result['passed'],(jid,name,result)
            else:
                assert saved['basis'] is None and 'projector_rng_state' not in saved
            dtype='BF16' if len(shape)==2 else 'F32';model_dtype_owners[dtype]+=1;model_dtype_numel[dtype]+=master.numel()
            per_owner.append({'index':index,'name':name,'shape':list(shape),'step':saved['step'],'projected':projected,'model_dtype_expected':dtype,'tensor_fields':tensor_fields})
        assert len(basis_checks)==113 and model_dtype_owners=={'BF16':113,'F32':113}
        assert sum(model_dtype_numel.values())==596049920
        index_path=checkpoint/'model.safetensors.index.json';weight_index=json.loads(index_path.read_text());header_tensors={};header_sha={}
        for shard in sorted(set(weight_index['weight_map'].values())):
            h,hs=header(checkpoint/shard);header_sha[shard]=hs
            for name,info in h.items():
                if name=='__metadata__':continue
                assert name not in header_tensors
                header_tensors[name]={'file':shard,**info}
        assert set(header_tensors)==set(weight_index['weight_map'])
        assert all(header_tensors[k]['file']==v for k,v in weight_index['weight_map'].items())
        config=json.loads((checkpoint/'config.json').read_text());assert config['tie_word_embeddings'] is True
        head_keys=[n for n in header_tensors if 'lm_head' in n];assert not head_keys
        assert header_tensors['model.embed_tokens.weight']['dtype']=='BF16' and header_tensors['model.embed_tokens.weight']['shape']==[151936,1024]
        export_dtypes=Counter();export_dtype_bytes=Counter()
        for n,info in header_tensors.items():
            dtype=info['dtype'];export_dtypes[dtype]+=1;export_dtype_bytes[dtype]+=info['data_offsets'][1]-info['data_offsets'][0]
            assert dtype==('F32' if 'norm' in n else 'BF16'),(n,dtype)
        assert sum(export_dtype_bytes.values())==weight_index['metadata']['total_size']
        assert export_dtype_bytes['BF16']==model_dtype_numel['BF16']*2 and export_dtype_bytes['F32']==model_dtype_numel['F32']*4
        for k in ['torch_rng','cuda_rng']:assert payload[k].dtype==torch.uint8 and payload[k].device.type=='cpu'
        torch.Generator(device='cpu').set_state(payload['torch_rng'])
        cached=sha_cache[str(file)];assert {k:cached[k] for k in before}==before
        file_sha=cached['sha256'];assert sig(file)==before
        result={'job':jid,'seed':seed,'checkpoint':str(checkpoint),'state_file':str(file),'state_file_sha256':file_sha,'state_sha256_provenance':'reused from immediately preceding completed full-SHA pass; cache stat matches, raw log retained','state_file_stat':before,'state_file_unmodified':True,'training_state_json_sha256':sha(checkpoint/'training_state.json'),'schema':payload['format'],'optimizer_schema':opt['format'],'optimizer_class':payload['optimizer_class'],'global_step':payload['global_step'],'sdk_zero_based_last_update':payload['global_step']-1,'sdk_cursor_explanation':'sidecar worker global_step=1024 counts completed updates; SDK context restores its last-update cursor as1023','owners':len(rows),'parameter_names_equal_across_seeds':True,'hyperparameters':hp,'backend_policy':opt['backend_policy'],'projector_policy':opt['projector_policy'],'schedule':payload['schedule'],'per_parameter_step_counts':dict(step_counts),'projected_matrices':len(basis_checks),'refreshes_per_projected_parameter':6,'transports_per_projected_parameter':5,'model_dtype_owner_counts':dict(model_dtype_owners),'model_dtype_numel':dict(model_dtype_numel),'logical_tensor_inventory_bytes':dict(totals),'worker_rng':{k:tensor_meta(payload[k]) for k in ['torch_rng','cuda_rng']},'basis_gram_checks':basis_checks,'basis_gram_max_abs_error':max(x['gram_max_abs_error'] for x in basis_checks),'per_owner':per_owner,'export_header_audit':{'index_sha256':sha(index_path),'header_sha256':header_sha,'index_metadata':weight_index['metadata'],'tensor_count':len(header_tensors),'dtype_counts':dict(export_dtypes),'dtype_bytes':dict(export_dtype_bytes),'tie_word_embeddings':True,'lm_head_tensor_keys':head_keys,'stale_independent_head_not_exported':True,'scope':'header/index/config metadata only; no full model load or new content/quality evaluation'},'passed':True}
        results.append(result);print(json.dumps({'seed':seed,'passed':True,'basis':len(basis_checks),'max_gram_error':result['basis_gram_max_abs_error'],'state_sha256':file_sha,'logical_state_bytes':dict(totals)}),flush=True)
        del payload,opt,rows
    current_status=json.loads(status_path.read_text())['jobs']
    assert all(current_status[r['job']]['status']=='complete' and current_status[r['job']]['final_checkpoint']==r['checkpoint'] for r in results)
    assert source_hash()==EXPECTED_SOURCE
    report={'status':'passed','source_sha256':EXPECTED_SOURCE,'status_file_sha256':status_sha,'status_file_post_sha256':sha(status_path),'status_file_note':'Live guardian may update global heartbeat; auditor only reads status. Selected complete statuses and final paths remain unchanged.','selected_endpoints_status_and_paths_unchanged':True,'audit_script_sha256':sha(Path(__file__)),'cpu_affinity':sorted(os.sched_getaffinity(0)),'torch_version':torch.__version__,'precision':'highest FP32 CPU; no CUDA operations','atol':1e-6,'rtol':1e-4,'basis_gram_checks':339,'all_339_basis_gram_checks_passed':True,'full_model_loaded':False,'checkpoint_written':False,'gpu_used':False,'elapsed_seconds':time.time()-started,'inventory_note':'Actual canonical on-disk optimizer tensor inventory, including full FP32 masters. It is not live compact-resident allocation or peak GPU memory; use the separate performance measurement for allocated/reserved peaks.','endpoints':results}
    (HERE/'final-checkpoint-audit.json').write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':main()
