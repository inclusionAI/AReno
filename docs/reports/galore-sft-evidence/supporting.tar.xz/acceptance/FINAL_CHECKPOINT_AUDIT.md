# Selected final checkpoint audit

Read-only CPU mmap audit of the three completed scale2/all-matrix 1024-update endpoints on source142c7be2c33f871badad4105bd682d4e34da3d3c32e17278dba67324e45c21e1. All339basis Gram tests passed with original atol1e-6/rtol1e-4 and highest FP32 CPU math. Maximum absolute Gram errors: seed0/1 9.5367431640625e-7, seed2 8.940696716308594e-7.

Each sidecar is3,040,818,666bytes, schema areno-training-v1/GaLore-v3, worker completed-step1024 (SDK zero-based last-update cursor1023). Every one of226unique parameter owners has step1024. Each of113projected matrices has6refreshes/5transports and uint8[5056] private RNG state accepted by a CPU generator. Shapes, moment/basis/master dtypes, hyperparameters and versioned backend/projector policies match the selected source. The full parameter inventory and per-basis results are in final-checkpoint-audit.json.

Per-seed canonical optimizer tensor inventory:3,040,524,224bytes =2,384,199,680full FP32 master +595,984,384projected moment +59,244,544basis +571,328private RNG +524,288fallback moment bytes. These are logical canonical serialized tensors, not live compact-resident memory or a GPU peak measurement. The independent same-GPU performance report measures actual allocated/reserved peaks.

Safetensors were inspected by headers only: tied-word-embedding config is true; no independent lm_head tensor is exported, norms are F32 and matrices BF16; index/header tensor byte totals match the expected owner inventory. This establishes metadata/schema consistency, not a new full model reload or model-content/quality test. Existing formal independent eval remains the reload evidence.

All three state files received a genuine full SHA256 in the first completed numerical pass, verified unchanged by file stat; those hashes were reused while fixing a final global-heartbeat guard. Original complete-hash log and stat-keyed cache are retained. The live guardian may update the global status file; all three selected complete statuses and endpoint paths remained unchanged. Audit code only reads original checkpoints/status/source, never writes them. CPU56–59/OMP4/nice10/idle I/O, no CUDA and no entire model load.

The initial one-dimensional shape-guard error and later overly broad status-file-heartbeat assertion are retained in their raw logs. Both were audit-helper issues and did not change checkpoints or source. Final audit passed. See final-checkpoint-audit.json and final-checkpoint-audit.log.
