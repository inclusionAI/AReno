#!/usr/bin/env bash
set -euo pipefail
root=/mnt2/ling/areno-galore
out="$root/runs/pr_round_20261029/acceptance/production-gap-resume"
source "$root/env.sh"
export CUDA_VISIBLE_DEVICES=2 OMP_NUM_THREADS=4
export PYTHONPATH="$root/runs/pr_round_20261029/candidate-pr:$root/runs/pr_round_20261029/acceptance/scale2:$root/runs/overnight_20261029/harness_v2"
if [[ ${PRODUCTION_GAP_RESUME_LOCKED:-0} != 1 ]]; then
 export PRODUCTION_GAP_RESUME_LOCKED=1
 exec flock "$root/runs/gpu2.lock" "$0"
fi
occupied=$(nvidia-smi -i 2 --query-compute-apps=pid --format=csv,noheader)
if [[ -n $occupied ]]; then echo "GPU2 occupied: $occupied" >&2; exit 2; fi
echo "$$" > "$out/runner.pid"
date -Is
exec taskset -c 44-47 python "$out/run.py"
