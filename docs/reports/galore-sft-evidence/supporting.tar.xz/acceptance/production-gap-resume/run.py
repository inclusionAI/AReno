"""Read-only formal endpoint restore; engineering continuation only, no save/eval."""

from __future__ import annotations

import hashlib
import json
import os
from datetime import UTC, datetime
from pathlib import Path

import torch
from common import batch_indices, encode, parser, trainer
from numerics import source_sha

from areno.api import sft_loss_fn

ROOT = Path("/mnt2/ling/areno-galore/runs/pr_round_20261029")
OUT = ROOT / "acceptance/production-gap-resume"
JOB = "final-sft512-1024__galore__s0"


def dump(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")


def sha(value):
    return hashlib.sha256(json.dumps(value, separators=(",", ":")).encode()).hexdigest()


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    status = json.loads((ROOT / "status.json").read_text())["jobs"][JOB]
    checkpoint = Path(status["final_checkpoint"])
    train_summary = Path(status["train_summary_file"])
    endpoint = json.loads(train_summary.read_text())
    assert endpoint["next_step"] == 1024
    last = json.loads((train_summary.parent / "steps.jsonl").read_text().splitlines()[-1])
    assert last["step"] == 1023
    original = {
        str(p.relative_to(checkpoint)): (p.stat().st_size, p.stat().st_mtime_ns)
        for p in checkpoint.rglob("*")
        if p.is_file()
    }
    args = parser(__doc__).parse_args(
        [
            "--data-dir",
            str(ROOT.parent / "experiments/overnight_20261029_data/data"),
            "--checkpoint-dir",
            str(checkpoint),
            "--output-dir",
            str(OUT),
            "--model",
            str(checkpoint),
            "--optimizer",
            "galore",
            "--seed",
            "0",
            "--context",
            "512",
            "--batch",
            "4",
            "--micro-batch",
            "2",
            "--rank",
            "128",
            "--gap",
            "200",
            "--scale",
            "2",
            "--extra-config-json",
            '{"optimizer":{"galore_exclude_vocab":false}}',
        ]
    )
    os.environ["ARENO_SCALE2_ACCEPTANCE_DIR"] = str(OUT)
    os.environ["ARENO_BENCH_SEED"] = "0"
    torch.manual_seed(0)
    dump(
        "metadata.json",
        dict(
            timestamp=datetime.now(UTC).isoformat(),
            runtime_source_sha256=source_sha(),
            checkpoint=str(checkpoint),
            formal_job=JOB,
            formal_budget_completed=1024,
            engineering_steps=178,
            engineering_indices=[1024, 1201],
            context=512,
            batch=4,
            micro_batch=2,
            seed=0,
            rank=128,
            gap=200,
            scale=2,
            transport=True,
            exclude_vocab=False,
            training_sha256=hashlib.sha256((args.data_dir / "train.jsonl").read_bytes()).hexdigest(),
            common_sha256=hashlib.sha256(Path(__import__("common").__file__).read_bytes()).hexdigest(),
            cuda_visible_devices=os.environ["CUDA_VISIBLE_DEVICES"],
            cpu_affinity=sorted(os.sched_getaffinity(0)),
            no_validation_or_test_read=True,
            no_checkpoint_save=True,
            scope="independent engineering continuation; excluded from formal1024 quality budget",
        ),
    )
    engine = trainer(args, resume=False, output=OUT / "model-only")
    try:
        engine.init()
        training, encoding = encode(engine.get_tokenizer(), args, "train")
        orders = {}

        def get_batch(step):
            indices = batch_indices(step, 0, len(training), 4, orders)
            return indices, [training[i] for i in indices]

        indices, batch = get_batch(1023)
        assert indices == last["sample_indices"]
        assert sha([(s.tokens, s.prompt_len) for s in batch]) == last["batch_sha256"]
        probe_tokens = [training[0].tokens, training[1].tokens]
        model_probe = engine.score_logprobs("actor", probe_tokens, microbatch_size=2)
        indices, batch = get_batch(1024)
        expected_next = dict(
            step=1024, sample_indices=indices, batch_sha256=sha([(s.tokens, s.prompt_len) for s in batch])
        )
        dump(
            "saved-endpoint-reference.json",
            dict(
                model_only_probe=model_probe,
                probe_source="independent model-only read of saved endpoint; original formal harness recorded no live endpoint probe",
                last_saved_batch1023_exact=True,
                next_batch=expected_next,
                cursor_source="frozen absolute-cursor contract validated against saved step1023, not a checkpointed application cursor",
            ),
        )
    finally:
        engine.close()
    engine = trainer(args, resume=True, output=OUT / "restored")
    try:
        engine.init()
        audit = json.loads((OUT / "immediate-state-restore.json").read_text())
        assert audit["exact_match"] and audit["worker_completed_updates"] == 1024
        assert engine._ctx.global_step == 1023
        assert engine.score_logprobs("actor", probe_tokens, microbatch_size=2) == model_probe
        indices, batch = get_batch(engine._ctx.global_step + 1)
        assert (
            dict(step=1024, sample_indices=indices, batch_sha256=sha([(s.tokens, s.prompt_len) for s in batch]))
            == expected_next
        )
        dump(
            "restore-proof.json",
            dict(
                status="passed",
                state=audit,
                probe_exact=True,
                next_batch_exact=True,
                sdk_step=1023,
                completed_updates=1024,
                next_batch=expected_next,
            ),
        )
        refreshed = []
        with (OUT / "steps.jsonl").open("w") as raw:
            for step in range(1024, 1202):
                indices, batch = get_batch(step)
                values = engine.score_logprobs("actor", [s.tokens for s in batch], microbatch_size=2)
                for sample, scores in zip(batch, values, strict=True):
                    sample.logprobs = list(scores)
                result = engine.train(batch, sft_loss_fn, mini_bs=2)
                assert result["update_optimizer_steps"] == 1 and result["update_worker_step"] == step + 1
                assert engine._ctx.global_step == step and result["logp_abs_diff_mean"] == 0
                refresh = bool(result["update_refresh_any"])
                assert refresh == (step % 200 == 0)
                if refresh:
                    refreshed.append(step)
                row = dict(
                    timestamp=datetime.now(UTC).isoformat(),
                    step=step,
                    worker_completed_updates=step + 1,
                    sample_indices=indices,
                    batch_sha256=sha([(s.tokens, s.prompt_len) for s in batch]),
                    target_tokens=sum(len(s.tokens) - s.prompt_len for s in batch),
                    optimizer_steps=1,
                    refresh=refresh,
                    native_logp_abs_diff_mean=result["logp_abs_diff_mean"],
                )
                raw.write(json.dumps(row) + "\n")
                raw.flush()
                if step % 20 == 0 or refresh or step == 1201:
                    print(json.dumps(row), flush=True)
        assert refreshed == [1200]
    finally:
        engine.close()
    after = {
        str(p.relative_to(checkpoint)): (p.stat().st_size, p.stat().st_mtime_ns)
        for p in checkpoint.rglob("*")
        if p.is_file()
    }
    assert after == original
    assert not list(OUT.rglob("training_state.pt"))
    dump(
        "summary.json",
        dict(
            status="passed",
            timestamp=datetime.now(UTC).isoformat(),
            runtime_source_sha256=source_sha(),
            formal_checkpoint=str(checkpoint),
            formal_budget_unchanged=1024,
            independent_engineering_updates=178,
            absolute_update_indices=[1024, 1201],
            completed_updates_after_continuation=1202,
            actual_refresh_indices=refreshed,
            step1201_refresh=False,
            native_sft_error_max=0,
            immediate_state_exact=True,
            model_only_endpoint_probe_exact=True,
            next_batch_exact=True,
            original_checkpoint_stat_manifest_unchanged=True,
            new_checkpoint_saved=False,
            no_validation_test_read=True,
            no_native_trajectory_equality_claim=True,
        ),
    )


if __name__ == "__main__":
    main()
