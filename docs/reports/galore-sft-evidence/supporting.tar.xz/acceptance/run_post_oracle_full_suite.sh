#!/usr/bin/env bash
set -euo pipefail
root_dir=/mnt2/ling/areno-galore
candidate_dir="$root_dir/runs/pr_round_20261029/candidate-pr"
acceptance_dir="$root_dir/runs/pr_round_20261029/acceptance"
source "$root_dir/env.sh"
export CUDA_VISIBLE_DEVICES=2 OMP_NUM_THREADS=4
export PYTHONPATH="$candidate_dir"
unset PYTEST_DISABLE_PLUGIN_AUTOLOAD
if [[ ${POST_ORACLE_FULL_SUITE_LOCKED:-0} != 1 ]]; then
    export POST_ORACLE_FULL_SUITE_LOCKED=1
    exec flock "$root_dir/runs/gpu2.lock" "$0"
fi
occupied=$(nvidia-smi -i 2 --query-compute-apps=pid --format=csv,noheader)
if [[ -n $occupied ]]; then
    echo "GPU2 occupied after lock; refusing full-suite CUDA visibility: $occupied" >&2
    exit 2
fi
cd "$candidate_dir"
date -Is
git rev-parse HEAD
git diff --quiet
git diff --cached --quiet
nvidia-smi -i 2 --query-gpu=index,uuid,memory.used,utilization.gpu --format=csv
taskset -c 52-55 python - <<'PY'
import hashlib,json,os,subprocess
from pathlib import Path
import torch
repo=Path.cwd()
digest=hashlib.sha256()
for path in sorted((repo/'areno').rglob('*.py')):
    digest.update(str(path.relative_to(repo)).encode());digest.update(path.read_bytes())
sha=digest.hexdigest()
commit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert commit.startswith('8ccfc00'),commit
assert sha=='142c7be2c33f871badad4105bd682d4e34da3d3c32e17278dba67324e45c21e1',sha
assert torch.cuda.is_available() and torch.cuda.device_count()==1
result=dict(git_commit=commit,runtime_repo_sha256=sha,cuda_visible_devices=os.environ['CUDA_VISIBLE_DEVICES'],
            real_cuda_available=torch.cuda.is_available(),gpu=torch.cuda.get_device_name(0),
            cpu_affinity=sorted(os.sched_getaffinity(0)),command='pytest tests/ -k cpu -q',
            cache_dir=str(repo.parent/'acceptance/pytest-cache-post-oracle'),no_harness_fake_availability=True)
(repo.parent/'acceptance/post-oracle-full-suite-inputs.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result),flush=True)
PY
exec taskset -c 52-55 python -m pytest tests/ -k cpu -q \
    -o "cache_dir=$acceptance_dir/pytest-cache-post-oracle"
