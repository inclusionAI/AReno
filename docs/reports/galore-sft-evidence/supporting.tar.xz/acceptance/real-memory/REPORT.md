# Actual selected-endpoint gradient and decomposition memory

Restored the real primary seed0 1024-update checkpoint (scale2/rank128/gap200/transport/all matrices), actual candidate source `142c7be2c33f871badad4105bd682d4e34da3d3c32e17278dba67324e45c21e1`. Ran the original capture_stages.py unchanged on exclusive GPU0 under gpu0.lock; return code0, completed.json confirms success. Staged recycled output matched unmodified recycled bit-for-bit. The original checkpoint file stat is unchanged.

| Actual resident category at postclip optimizer entry | Bytes | GiB |
|---|---:|---:|
| Unique model parameters | 1,192,230,912 | 1.110352 |
| Full FP32 main gradients | 2,384,199,680 | 2.220459 |
| Optimizer GPU buffers (unique storages) | 1,922,482,176 | 1.790451 |
| Optimizer private CPU RNG/state | 571,328 | 0.000532 |

The chosen real clipped vocabulary gradient is FP32 `[151936,1024]`, **622,329,856 bytes** (593.500 MiB). All full FP32 main gradients occupy **2,384,199,680 bytes**. After the real optimizer consumed them, both grad and main_grad storage totals are zero. GPU optimizer buffers increase by4bytes for the live writeback-invalid flag. These observed storage totals differ from the canonical full-FP32-master serialization inventory in the CPU checkpoint audit.

| Decomposition stage | Entry allocated GiB | Peak GiB | Exit GiB | Peak increase MiB | Transient above entry/exit MiB |
|---|---:|---:|---:|---:|---:|
| recycled.unmodified_end_to_end | 6.294501 | 6.531839 | 6.294989 | 243.035 | 242.535 |
| recycled.power0.QR_large | 6.377081 | 6.531839 | 6.459113 | 158.472 | 74.472 |
| recycled.final_QR_r_only | 6.377081 | 6.459955 | 6.377159 | 84.862 | 84.783 |
| recycled.small_Ritz_SVD | 6.295127 | 6.295804 | 6.295283 | 0.692 | 0.533 |
| exact_SVD.decompose_same_real_gradient | 6.294501 | 8.043187 | 6.878489 | 1790.655 | 1192.651 |

These are allocator-visible tensor/stage footprints; transient-above-endpoints is a lower bound, not exclusive cuSolver workspace. NVML endpoints provide additional lower bounds on process/device usage and external allocator residuals; they do not isolate solver workspace or guarantee the transient device peak.

This tiny probe uses data-repo-text train with ctx64/batch2, so it is separate from the main Dolly quality and 400-update performance controls. Intentional synchronizations/peak resets invalidate ordinary training timing. There was no validation/test encoding or evaluation and no checkpoint save; the unmodified legacy metadata helper does read the validation file only to hash it. Its source digest references integrated/repo, while the independent launch manifest proves the actual imported runtime is candidate142c. No code or source digest is silently rewritten.

Evidence: [worker-stages.jsonl](output/worker-stages.jsonl), [metadata](output/metadata.json), [completed](output/completed.json), [actual source/command manifest](launch-manifest.json), [complete stage summary](summary.json). GPU0 had no compute processes before lock-held launch or after completion; no external high-frequency sampler was run. The same real clipped gradient was used for recycled and full SVD.
