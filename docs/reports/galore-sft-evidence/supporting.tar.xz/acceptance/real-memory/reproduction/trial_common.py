"""Experiment-only public-Trainer utilities; canonical folds are read verbatim."""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import os
import random
import subprocess
from datetime import UTC, datetime
from pathlib import Path

import torch
from scripts.bench_galore import encode, evaluate

from areno import Trainer
from areno.api import CudaConfig

__all__ = ["encode", "evaluate"]

ALIAS = Path(__file__).resolve().parent
ROOT = ALIAS.parents[2]
if "ARENO_BENCH_SEED" in os.environ:
    torch.manual_seed(int(os.environ["ARENO_BENCH_SEED"]))
    random.seed(int(os.environ["ARENO_BENCH_SEED"]))


def arguments(description):
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--checkpoint-dir", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--seed", type=int, default=0, choices=[0, 1, 2])
    parser.add_argument("--optimizer", choices=["adamw", "adam8", "galore"], default="galore")
    parser.add_argument("--scale", type=float, default=1.0)
    parser.add_argument("--rank", type=int, default=128)
    parser.add_argument("--gap", type=int, default=4)
    parser.add_argument("--projector", choices=["svd", "recycled"], default="recycled")
    parser.add_argument("--compact", action="store_true")
    parser.add_argument("--tile-rows", type=int, default=16384)
    parser.add_argument("--fused", action="store_true")
    parser.add_argument("--transport", action="store_true")
    return parser


def setup(args, phase):
    args.output_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[
            logging.FileHandler(args.output_dir / f"{phase}-{stamp}.log"),
            logging.StreamHandler(),
        ],
    )
    random.seed(args.seed)
    torch.manual_seed(args.seed)
    os.environ["ARENO_BENCH_SEED"] = str(args.seed)
    return logging.getLogger(phase)


def rows(args, split):
    return [json.loads(line) for line in (args.data_dir / f"{split}.jsonl").read_text().splitlines()]


def token_hash(tokens):
    return hashlib.sha256(json.dumps(tokens, separators=(",", ":")).encode()).hexdigest()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def metadata(args):
    sources = hashlib.sha256()
    for path in sorted((ALIAS / "repo" / "areno").rglob("*.py")):
        sources.update(str(path.relative_to(ALIAS / "repo")).encode())
        sources.update(path.read_bytes())
    return {
        "timestamp": datetime.now(UTC).isoformat(),
        "arguments": {k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()},
        "torch_version": torch.__version__,
        "cuda_version": torch.version.cuda,
        "gpu": torch.cuda.get_device_name(0),
        "cuda_visible_devices": os.environ.get("CUDA_VISIBLE_DEVICES"),
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "source_sha256": sources.hexdigest(),
        "wrapper_sha256": {name: digest(ALIAS / name) for name in ("train.py", "eval.py", "trial_common.py")},
        "data_cursor": "zero-based-sdk-step-order-2step-and-2stepplus1-v1",
        "model_identity": "native-tied-input-output-weight; expected-unique-numel-596049920",
        "commit": subprocess.check_output(["git", "-C", str(ALIAS / "repo"), "rev-parse", "HEAD"], text=True).strip(),
        "train_sha256": digest(args.data_dir / "train.jsonl"),
        "validation_sha256": digest(args.data_dir / "validation.jsonl"),
        "native_extension_sha256": digest(next((ALIAS / "repo" / "areno" / "accel").glob("_areno_accel*.so"))),
        "benchmark_helpers_sha256": digest(ALIAS / "repo" / "scripts" / "bench_galore.py"),
        "batch_size": 2,
        "context_cap": 64,
        "warmup_steps": 2,
        "dtype": "bfloat16",
        "projector": {
            "backend": args.projector,
            "rank": args.rank,
            "scale": args.scale,
            "gap": args.gap,
            "oversampling": 16,
            "iterations": 1,
            "seed": args.seed,
            "moments": "transported" if args.transport else "retained-coordinate-arrays",
            "final_canonical_qr": True,
            "compact_master": args.compact,
            "fused_writeback": args.fused,
            "tile_rows": args.tile_rows,
        },
    }


def trainer(model, output, seed, *, options, resume=False):
    optimizer = {
        "lr": 1e-5,
        "min_lr": 1e-5,
        "betas": (0.9, 0.95),
        "weight_decay": 0.01,
        "grad_clip_norm": 1.0,
        "resume_training_state": resume,
        "save_training_state": True,
    }
    if options.optimizer == "adam8":
        optimizer["adam_8bit"] = True
    elif options.optimizer == "galore":
        optimizer.update(
            galore_rank=options.rank,
            galore_update_proj_gap=options.gap,
            galore_scale=options.scale,
            galore_projector_backend=options.projector,
            galore_projector_oversampling=16,
            galore_projector_iterations=1,
            galore_projector_seed=seed,
            galore_projector_final_qr=True,
            galore_compact_master=options.compact,
            galore_tile_rows=options.tile_rows if options.compact else 0,
            galore_release_gradients=options.compact,
            galore_fused_writeback=options.fused,
            galore_transport_moments=options.transport,
        )
    return Trainer(
        world_size=1,
        model_path=str(model),
        custom_config=CudaConfig(
            devices=[0],
            tp_size=1,
            optimizer=optimizer,
            runtime={
                "attn_backend": "native",
                "compile_model": False,
                "activation_checkpointing": True,
                "keep_rollout_state": True,
                "profile_training": True,
            },
        ),
        metrics_log_dir=str(output / "events"),
    )


def write_json(path, payload):
    Path(path).write_text(json.dumps(payload, indent=2) + "\n")


def gpu_snapshot():
    # Physical GPU index is fixed by the experiment resource registration.
    command = [
        "nvidia-smi",
        "-i",
        os.environ.get("CUDA_VISIBLE_DEVICES", "3").split(",")[0],
        "--query-gpu=timestamp,uuid,memory.used,memory.total,utilization.gpu",
        "--format=csv,noheader,nounits",
    ]
    return subprocess.check_output(command, text=True).strip()
