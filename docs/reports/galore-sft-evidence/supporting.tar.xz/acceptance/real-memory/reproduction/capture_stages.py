"""Separate diagnostic: real clipped gradients, stage peaks, matched SVD.

Monkeypatches only this process/its spawned worker. Frozen source is untouched.
Intentional peak resets/synchronization invalidate this job's ordinary timing
metrics; authoritative records are worker-stages.jsonl and external NVML.
"""

from __future__ import annotations

import ctypes
import json
import os
import random
import time
from pathlib import Path

import torch

from areno.api import sft_loss_fn
from areno.engine import training
from areno.engine.optim import recycled_subspace as recycled
from areno.engine.optim.galore import GaLoreAdamW
from areno.engine.optim.master_storage import BF16MasterStorage
from trial_common import arguments, encode, metadata, rows, setup, trainer, write_json


class Memory(ctypes.Structure):
    _fields_ = [("total", ctypes.c_ulonglong), ("free", ctypes.c_ulonglong), ("used", ctypes.c_ulonglong)]


_WORKER = None
_NVML = None
_HANDLE = None
_TARGET = None
_CAPTURED = False
_BACKWARD_DEPTH = 0


def storage_bytes(tensors):
    seen = {}
    for tensor in tensors:
        if isinstance(tensor, torch.Tensor):
            storage = tensor.untyped_storage()
            seen[(str(tensor.device), storage._cdata)] = storage.nbytes()
    return sum(seen.values())


def snapshot():
    global _NVML, _HANDLE
    device = torch.cuda.current_device()
    if _NVML is None:
        _NVML = ctypes.CDLL("libnvidia-ml.so.1")
        assert _NVML.nvmlInit_v2() == 0
        _HANDLE = ctypes.c_void_p()
        assert _NVML.nvmlDeviceGetHandleByIndex_v2(int(os.environ["CUDA_VISIBLE_DEVICES"]), ctypes.byref(_HANDLE)) == 0
    memory = Memory()
    assert _NVML.nvmlDeviceGetMemoryInfo(_HANDLE, ctypes.byref(memory)) == 0
    parameters = list(_WORKER.model.parameters())
    buffers = []
    host = []
    for state in _WORKER.optimizer.state.values():
        for value in state.values():
            tensors = (value.low_bits, value.round_up_bits) if isinstance(value, BF16MasterStorage) else (value,)
            for tensor in tensors:
                if isinstance(tensor, torch.Tensor):
                    (host if tensor.device.type == "cpu" else buffers).append(tensor)
    validation = getattr(_WORKER.optimizer, "_writeback_invalid", None)
    if validation is not None:
        buffers.append(validation)
    return {
        "allocated_bytes": torch.cuda.memory_allocated(device),
        "reserved_bytes": torch.cuda.memory_reserved(device),
        "nvml_used_bytes": memory.used,
        "model_unique_bytes": storage_bytes(parameters),
        "grad_unique_bytes": storage_bytes(getattr(p, "grad", None) for p in parameters),
        "main_grad_unique_bytes": storage_bytes(getattr(p, "main_grad", None) for p in parameters),
        "optimizer_gpu_unique_bytes": storage_bytes(buffers),
        "optimizer_cpu_unique_bytes": storage_bytes(host),
    }


def emit(row):
    path = Path(os.environ["ARENO_MEMORY_DIAG_DIR"]) / "worker-stages.jsonl"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a") as output:
        output.write(json.dumps(row) + "\n")
        output.flush()


def point(label):
    torch.cuda.synchronize()
    emit(dict(kind="lifecycle", label=label, monotonic_ns=time.monotonic_ns(), **snapshot()))


def stage(label, operation):
    torch.cuda.synchronize()
    before = snapshot()
    torch.cuda.reset_peak_memory_stats()
    start = time.monotonic_ns()
    result = operation()
    torch.cuda.synchronize()
    end = time.monotonic_ns()
    after = snapshot()
    peak = torch.cuda.max_memory_allocated()
    reserved_peak = torch.cuda.max_memory_reserved()
    emit(
        dict(
            kind="stage",
            label=label,
            start_monotonic_ns=start,
            end_monotonic_ns=end,
            seconds=(end - start) / 1e9,
            before=before,
            after=after,
            peak_allocated_bytes=peak,
            peak_reserved_bytes=reserved_peak,
            peak_increase_over_entry_bytes=max(0, peak - before["allocated_bytes"]),
            transient_above_entry_exit_lower_bound_bytes=max(
                0, peak - max(before["allocated_bytes"], after["allocated_bytes"])
            ),
            external_residual_endpoint_lower_bound_bytes=max(
                0, max(before["nvml_used_bytes"], after["nvml_used_bytes"]) - reserved_peak
            ),
        )
    )
    return result


def copied_projector_state(state):
    return {
        key: (value.clone() if key == "projector_rng_state" else value)
        for key, value in state.items()
        if key in ("basis", "projector_rng_state", "projector_parameter_index", "projector_refreshes")
    }


def staged_recycled(gradient, opt, state, parameter_index):
    right = gradient.shape[0] >= gradient.shape[1]
    a = gradient.T if right else gradient
    width = min(opt.rank + opt.projector_oversampling, a.shape[0])
    previous = state.get("basis")
    generator = torch.Generator(device="cpu")
    if "projector_rng_state" in state:
        generator.set_state(state["projector_rng_state"].cpu())
    else:
        generator.manual_seed((opt.projector_seed + 1000003 * parameter_index) % (2**63 - 1))
    noise = torch.randn(
        a.shape[0], width if previous is None else width - opt.rank, generator=generator, dtype=torch.float32
    )
    innovation = stage("recycled.innovation_to_gpu", lambda: noise.to(a.device))
    if previous is None:
        q = stage("recycled.initial_QR", lambda: recycled.canonical_qr(innovation))
    else:
        p = previous.T if right else previous
        for index in range(2):
            projected = stage(f"recycled.innovation_projection{index}", lambda: p @ (p.T @ innovation))
            innovation = stage(f"recycled.innovation_subtract{index}", lambda: innovation - projected)
            projected = None
        joined = stage("recycled.concat_old_and_innovation", lambda: torch.cat((p, innovation), dim=1))
        q = stage("recycled.initial_QR", lambda: recycled.canonical_qr(joined))
        joined = None
    innovation = None
    point("recycled.after_innovation_release")
    for index in range(opt.projector_iterations):
        product = stage(f"recycled.power{index}.A_T_Q", lambda: a.T @ q)
        z = stage(f"recycled.power{index}.QR_large", lambda: recycled.canonical_qr(product))
        product = None
        point(f"recycled.power{index}.after_large_input_release")
        product = stage(f"recycled.power{index}.A_Z", lambda: a @ z)
        new_q = stage(f"recycled.power{index}.QR_small", lambda: recycled.canonical_qr(product))
        product = z = None
        q = new_q
        new_q = None
    compressed = stage("recycled.final_A_T_Q", lambda: a.T @ q)
    _, triangular = stage("recycled.final_QR_r_only", lambda: torch.linalg.qr(compressed, mode="r"))
    compressed = None
    point("recycled.after_compressed_release")
    left, _, _ = stage(
        "recycled.small_Ritz_SVD", lambda: torch.linalg.svd(triangular.T, full_matrices=False, driver="gesvd")
    )
    triangular = None
    p = stage("recycled.Ritz_lift", lambda: q @ left[:, : opt.rank])
    left = q = None
    if opt.projector_final_qr:
        p = stage("recycled.final_canonical_QR", lambda: recycled.canonical_qr(p))
    p = stage("recycled.final_sign_gauge", lambda: recycled.canonical_columns(p))
    return stage("recycled.basis_contiguous", lambda: p.T.contiguous() if right else p.contiguous())


def install():
    original_train = training.TrainingManager._train_step

    def train_step(self, *args, **kwargs):
        global _WORKER
        _WORKER = self.worker
        point("train_step.entry")
        result = original_train(self, *args, **kwargs)
        point("train_step.exit")
        return result

    training.TrainingManager._train_step = train_step
    original_backward = torch.autograd.backward

    def backward(*args, **kwargs):
        global _BACKWARD_DEPTH
        outer = _BACKWARD_DEPTH == 0
        _BACKWARD_DEPTH += 1
        try:
            return (
                stage("lifecycle.backward", lambda: original_backward(*args, **kwargs))
                if outer and _WORKER is not None
                else original_backward(*args, **kwargs)
            )
        finally:
            _BACKWARD_DEPTH -= 1

    torch.autograd.backward = backward
    original_accumulate = training.TrainingManager._accumulate_main_gradients

    def accumulate(self):
        return stage("lifecycle.accumulate_FP32_main_grad", lambda: original_accumulate(self))

    training.TrainingManager._accumulate_main_gradients = accumulate
    original_norm = training._grad_norms
    training._grad_norms = lambda *args, **kwargs: stage(
        "lifecycle.global_gradient_norm", lambda: original_norm(*args, **kwargs)
    )
    original_clip = training._clip_grad_norm
    training._clip_grad_norm = lambda *args, **kwargs: stage(
        "lifecycle.global_gradient_clip", lambda: original_clip(*args, **kwargs)
    )
    original_write = GaLoreAdamW._write_update

    def write(self, param, state, update, offset, lr):
        if id(param) == _TARGET and (offset == 0 or offset + update.numel() == param.numel()):
            return stage(
                f"lifecycle.vocab_writeback_offset{offset}",
                lambda: original_write(self, param, state, update, offset, lr),
            )
        return original_write(self, param, state, update, offset, lr)

    GaLoreAdamW._write_update = write
    original_step = GaLoreAdamW.step

    def step(self, closure=None):
        global _CAPTURED, _TARGET
        if not _CAPTURED:
            _CAPTURED = True
            index, param = max(
                (
                    (i, p)
                    for i, p in enumerate(self.model_params)
                    if p.ndim == 2 and getattr(p, "main_grad", None) is not None
                ),
                key=lambda row: row[1].numel(),
            )
            gradient = param.main_grad
            _TARGET = id(param)
            names = {id(p): name for name, p in _WORKER.model.named_parameters()}
            emit(
                dict(
                    kind="gradient_identity",
                    parameter=names[id(param)],
                    shape=list(gradient.shape),
                    dtype=str(gradient.dtype),
                    bytes=gradient.numel() * gradient.element_size(),
                    parameter_index=index,
                    rank=self.rank,
                    scale=self.scale,
                    step_before=self.state[param]["step"],
                    projector_policy=recycled.projector_policy(self.projector_final_qr),
                )
            )
            point("optimizer.entry_all_clipped_gradients")
            precision = torch.get_float32_matmul_precision()
            torch.set_float32_matmul_precision("highest")
            try:
                # First measure unmodified recycled function end to end on real gradient.
                local = copied_projector_state(self.state[param])
                basis = stage(
                    "recycled.unmodified_end_to_end",
                    lambda: recycled.recycled_basis(
                        gradient,
                        local,
                        rank=self.rank,
                        oversampling=self.projector_oversampling,
                        iterations=self.projector_iterations,
                        seed=self.projector_seed,
                        parameter_index=index,
                        final_qr=self.projector_final_qr,
                    ),
                )
                expected = basis.cpu()
                basis = local = None
                torch.cuda.empty_cache()
                point("recycled.unmodified_outputs_released")
                staged = staged_recycled(gradient, self, copied_projector_state(self.state[param]), index)
                assert torch.equal(staged.cpu(), expected), "stage sequence changed numerical basis"
                staged = expected = None
                torch.cuda.empty_cache()
                point("recycled.staged_outputs_released")
                left, singular, right = stage(
                    "exact_SVD.decompose_same_real_gradient", lambda: torch.linalg.svd(gradient, full_matrices=False)
                )
                basis = stage(
                    "exact_SVD.basis_clone",
                    lambda: (
                        right[: self.rank].contiguous().clone()
                        if gradient.shape[0] >= gradient.shape[1]
                        else left[:, : self.rank].contiguous().clone()
                    ),
                )
                left = singular = right = basis = None
                torch.cuda.empty_cache()
                point("exact_SVD.outputs_released")
            finally:
                torch.set_float32_matmul_precision(precision)
        # Do not retain a diagnostic alias to the gradient during real release.
        gradient = None
        result = original_step(self, closure)
        point("optimizer.exit_gradients_consumed")
        return result

    GaLoreAdamW.step = step


if os.environ.get("ARENO_MEMORY_DIAG_DIR"):
    install()


def main():
    parser = arguments(__doc__)
    args = parser.parse_args()
    logger = setup(args, "diagnostic")
    os.environ["ARENO_MEMORY_DIAG_DIR"] = str(args.output_dir.resolve())
    write_json(
        args.output_dir / "metadata.json",
        dict(metadata(args), diagnostic_only=True, primary_metrics_invalidated_by_intentional_peak_resets=True),
    )
    engine = trainer(args.checkpoint_dir, args.output_dir, args.seed, options=args, resume=True)
    try:
        engine.init()
        train = encode(engine.get_tokenizer(), rows(args, "train"))
        order = list(range(len(train)))
        random.Random(args.seed).shuffle(order)
        step = engine._ctx.global_step + 1
        batch = [train[order[(2 * step + i) % len(order)]] for i in range(2)]
        scores = engine.score_logprobs("actor", [row.tokens for row in batch], microbatch_size=2)
        for row, values in zip(batch, scores, strict=True):
            row.logprobs = list(values)
        engine.train(batch, sft_loss_fn, mini_bs=2)
        write_json(
            args.output_dir / "completed.json",
            dict(
                status="complete",
                diagnostic_only=True,
                resumed_from=str(args.checkpoint_dir),
                step=step,
                result_metrics_invalidated_by_diagnostic_resets=True,
            ),
        )
        logger.info("real-gradient diagnostic completed; use stage/NVML artifacts, not ordinary step metrics")
    finally:
        engine.close()


if __name__ == "__main__":
    main()
