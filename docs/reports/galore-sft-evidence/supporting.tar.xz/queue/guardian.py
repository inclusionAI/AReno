"""Detached finite GPU queue with occupancy guards, recovery and morning reports."""

from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
import shutil
import signal
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
CPUS = {0: "36-39", 1: "40-43", 2: "44-47", 3: "48-51"}


def now():
    return datetime.now(UTC).isoformat()


def write(path, payload):
    tmp = Path(str(path) + ".tmp")
    tmp.write_text(json.dumps(payload, indent=2, allow_nan=False) + "\n")
    tmp.replace(path)


def read(path, default=None):
    try:
        return json.loads(Path(path).read_text())
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def log(event, **fields):
    line = dict(timestamp=now(), event=event, **fields)
    print(json.dumps(line), flush=True)
    with (HERE / "events.jsonl").open("a") as out:
        out.write(json.dumps(line) + "\n")


def source_hash(repo):
    sha = hashlib.sha256()
    for path in sorted((Path(repo) / "areno").rglob("*.py")):
        sha.update(str(path.relative_to(repo)).encode())
        sha.update(path.read_bytes())
    return sha.hexdigest()


def inventory():
    result = subprocess.run(
        ["nvidia-smi", "--query-gpu=index,uuid,memory.used", "--format=csv,noheader,nounits"],
        capture_output=True,
        text=True,
        check=True,
        timeout=15,
    )
    cards = {}
    for line in result.stdout.splitlines():
        index, uuid, memory = [field.strip() for field in line.split(",")]
        cards[int(index)] = dict(uuid=uuid, memory_mib=int(memory), pids=[])
    processes = subprocess.run(
        ["nvidia-smi", "--query-compute-apps=pid,gpu_uuid", "--format=csv,noheader"],
        capture_output=True,
        text=True,
        check=True,
        timeout=15,
    )
    by_uuid = {value["uuid"]: value for value in cards.values()}
    for line in processes.stdout.splitlines():
        fields = [field.strip() for field in line.split(",")]
        if len(fields) == 2 and fields[0].isdigit() and fields[1] in by_uuid:
            by_uuid[fields[1]]["pids"].append(int(fields[0]))
    return cards


def descendants(pid):
    parents = {}
    for directory in Path("/proc").iterdir():
        if not directory.name.isdigit():
            continue
        try:
            data = (directory / "stat").read_text().split(") ", 1)[1].split()
            parents[int(directory.name)] = int(data[1])
        except (OSError, ValueError, IndexError):
            continue
    found = {pid}
    while True:
        expanded = found | {child for child, parent in parents.items() if parent in found}
        if expanded == found:
            return found
        found = expanded


def eligible(job, statuses):
    if any(statuses.get(parent, {}).get("status") != "complete" for parent in job.get("depends_on", [])):
        return False
    if job.get("ready_file"):
        ready = read(job["ready_file"], {})
        if not ready.get("ready"):
            return False
    return True


def resolved_source(job):
    expected = job.get("expected_source_sha256")
    if job.get("ready_file"):
        ready = read(job["ready_file"], {})
        expected = ready.get("source_sha256", expected)
    actual = source_hash(job["source_repo"])
    if expected and actual != expected:
        raise RuntimeError(f"Source changed after freeze: {job['id']}")
    for path, expected_hash in job.get("expected_input_sha256", {}).items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest() != expected_hash:
            raise RuntimeError(f"Frozen input changed: {path}")
    if job.get("model_weight_stat"):
        pin = job["model_weight_stat"]
        stat = Path(pin["path"]).stat()
        if stat.st_size != pin["size"] or stat.st_mtime_ns != pin["mtime_ns"]:
            raise RuntimeError("Pinned model weights changed after startup verification")
    return actual


def checkpoint_step(checkpoint):
    """Read actual sidecar scalar without paging full optimizer tensors into RAM."""
    import torch

    checkpoint = Path(checkpoint)
    metadata = read(checkpoint / "training_state.json", {})
    payload = torch.load(checkpoint / "training_state.pt", mmap=True, map_location="cpu", weights_only=True)
    actual = int(payload["global_step"])
    if metadata.get("global_step") != actual:
        raise RuntimeError(f"Incomplete checkpoint metadata at {checkpoint}")
    return actual


def accepted_summary(job, status, summary_path, attempt):
    summary = read(summary_path, {})
    if summary.get("next_step") != job["target_steps"]:
        return False
    if checkpoint_step(summary["checkpoint"]) != summary["next_step"]:
        raise RuntimeError("final checkpoint cursor differs from completed budget")
    status["train_summary_file"] = str(summary_path)
    status["final_checkpoint"] = summary["checkpoint"]
    status["phase"] = "eval"
    attempt["accepted_start_step"] = summary.get("start_step", 0)
    attempt["accepted_end_step"] = summary["next_step"]
    return True


def launch(job, status, gpu, lock_fd, statuses):
    actual_source = resolved_source(job)
    if status.get("resolved_source_sha256", actual_source) != actual_source:
        raise RuntimeError("Source changed between job phases")
    phase = status.get("phase", "train")
    number = len(status["attempts"]) + 1
    if phase == "train":
        output = Path(job["base_output_dir"]) / f"attempt-{number}"
        checkpoint = Path(job["checkpoint_dir"]) / f"attempt-{number}"
    else:
        output = Path(job["eval_output_dir"]) / f"attempt-{number}"
        checkpoint = Path(status["final_checkpoint"])
    output.mkdir(parents=True, exist_ok=False)
    options = list(job["options"])
    options += ["--data-dir", job["data_dir"], "--output-dir", str(output), "--checkpoint-dir", str(checkpoint)]
    resume_from = status.get("recovery_checkpoint")
    start = status.get("recovery_next_step", 0)
    if phase == "train":
        if not resume_from and job.get("resume_dependency"):
            parent = statuses[job["resume_dependency"]]
            resume_from = parent["final_checkpoint"]
            start = read(parent["train_summary_file"])["next_step"]
        if resume_from:
            start = checkpoint_step(resume_from)
        remaining = job["target_steps"] - start
        if remaining < 1:
            raise RuntimeError("unexpected completed budget without final summary")
        options += ["--steps", str(remaining)]
        if job["track"] == "sft":
            options += [
                "--stop-file",
                str(output / "STOP_REQUESTED"),
                "--eval-every",
                "256",
                "--checkpoint-every",
                str(job.get("checkpoint_every", 0)),
            ]
            if resume_from:
                options += ["--resume-from", resume_from]
        elif resume_from:
            raise RuntimeError("canonical partial attempts restart fresh rather than change its cursor policy")
    elif job.get("test"):
        options += ["--test"]
    env = dict(
        os.environ,
        CUDA_VISIBLE_DEVICES=str(gpu),
        OMP_NUM_THREADS="4",
        PYTHONPATH=f"{job['source_repo']}:{job['harness_dir']}",
        ARENO_BENCH_SEED=str(job["seed"]),
        PYTHONDONTWRITEBYTECODE="1",
    )
    env.pop("INTEGRATED_GPU_LOCKED", None)
    env.pop("CUBLAS_WORKSPACE_CONFIG", None)
    env.update(job.get("environment", {}))
    command = ["taskset", "-c", CPUS[gpu], sys.executable, str(Path(job["harness_dir"]) / f"{phase}.py"), *options]
    logfile = (output / "launcher.log").open("w")
    process = subprocess.Popen(
        command,
        cwd=job["source_repo"],
        env=env,
        stdout=logfile,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
        pass_fds=(lock_fd.fileno(),),
    )
    attempt = dict(
        index=number,
        phase=phase,
        gpu=gpu,
        output_dir=str(output),
        stdout=str(output / "launcher.log"),
        start_time=now(),
        end_time=None,
        returncode=None,
        contaminated=False,
        resume_from=resume_from,
        accepted_start_step=start,
        accepted_end_step=start,
    )
    status["attempts"].append(attempt)
    status.update(status="running", phase=phase, gpu=gpu, pid=process.pid, resolved_source_sha256=actual_source)
    log(
        "launch",
        job=job["id"],
        phase=phase,
        gpu=gpu,
        pid=process.pid,
        target_steps=job["target_steps"],
        start_step=start,
    )
    return dict(
        process=process,
        lock=lock_fd,
        logfile=logfile,
        job=job,
        status=status,
        attempt=attempt,
        output=output,
        known_pids={process.pid},
        stop_at=None,
    )


def complete(active):
    job, status, attempt = active["job"], active["status"], active["attempt"]
    rc = active["process"].returncode
    if rc:
        try:
            os.killpg(active["process"].pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    observed = not getattr(active["process"], "adopted", False)
    attempt.update(returncode=rc if observed else None, exit_code_observed=observed, end_time=now())
    summary = active["output"] / "summary.json"
    phase = attempt["phase"]
    if rc == 0 and phase == "train" and accepted_summary(job, status, summary, attempt):
        status.update(status="pending", error=None)
    elif rc == 0 and phase == "eval" and read(summary, {}).get("status") == "complete":
        status.update(status="complete", eval_summary_file=str(summary), error=None)
    else:
        recovery = read(active["output"] / "recovery.json", {})
        if job["track"] == "sft" and recovery.get("checkpoint"):
            recovery["next_step"] = checkpoint_step(recovery["checkpoint"])
            status["recovery_checkpoint"] = recovery["checkpoint"]
            status["recovery_next_step"] = recovery["next_step"]
            attempt["accepted_end_step"] = recovery["next_step"]
            if recovery["next_step"] == job["target_steps"]:
                recovered_summary = active["output"] / "recovered-summary.json"
                write(
                    recovered_summary,
                    dict(
                        status="complete",
                        checkpoint=recovery["checkpoint"],
                        next_step=recovery["next_step"],
                        start_step=attempt["accepted_start_step"],
                        completion_evidence="validated endpoint recovery plus preserved per-step records; process exit was interrupted",
                    ),
                )
                accepted_summary(job, status, recovered_summary, attempt)
                status["status"] = "pending"
                for handle in (active["logfile"], active["lock"]):
                    if handle is not None:
                        handle.close()
                status.pop("pid", None)
                return
        transient = rc == 75 or attempt["contaminated"]
        if transient and len(status["attempts"]) < 8:
            status["status"] = "pending"
        else:
            status["status"] = "failed"
        status["error"] = f"{phase} exited{rc}; see {attempt['stdout']}"
    log(
        "finish",
        job=job["id"],
        phase=phase,
        returncode=rc if observed else None,
        exit_code_observed=observed,
        status=status["status"],
        contaminated=attempt["contaminated"],
    )
    status.pop("pid", None)
    for handle in (active["logfile"], active["lock"]):
        if handle is not None:
            handle.close()


class AdoptedProcess:
    """Monitor an already-running isolated session after a controller-only handoff."""

    adopted = True

    def __init__(self, pid, output, phase):
        self.pid, self.output, self.returncode = pid, Path(output), None
        command = Path(f"/proc/{pid}/cmdline")
        if command.exists():
            try:
                args = command.read_bytes().replace(b"\0", b" ").decode()
                if args and (str(self.output) not in args or f"{phase}.py" not in args or os.getsid(pid) != pid):
                    raise RuntimeError("refusing to adopt a PID without exact job/session identity")
            except ProcessLookupError:
                pass

    def poll(self):
        try:
            state = Path(f"/proc/{self.pid}/stat").read_text().split(") ", 1)[1].split()[0]
            if state != "Z":
                return None
        except FileNotFoundError:
            pass
        # The former parent's wait status is unavailable. Completion is accepted
        # only from independently validated artifacts, never an invented exitcode.
        self.returncode = (
            0
            if read(self.output / "summary.json", {}).get("status") == "complete"
            else 75
            if (self.output / "recovery.json").exists()
            else 1
        )
        return self.returncode


def request_stop(active, reason):
    if active["stop_at"] is not None:
        return
    active["stop_at"] = time.monotonic()
    active["status"]["stop_reason"] = reason
    if reason.startswith("foreign"):
        active["attempt"]["contaminated"] = True
    if active["job"]["track"] == "sft" and active["attempt"]["phase"] == "train":
        write(active["output"] / "STOP_REQUESTED", dict(reason=reason, timestamp=now()))
    else:
        # Only the process group created by this guardian is signalled.
        try:
            os.killpg(active["process"].pid, signal.SIGTERM)
        except ProcessLookupError:
            pass
    log("stop_requested", job=active["job"]["id"], reason=reason)



def required_disk_gib(job, phase):
    return float(job.get("checkpoint_reserve_gib", 9)) if phase == "train" else 0.25


def disk_admission(job, phase, active, registry, free_gib=None):
    if free_gib is None:
        free_gib = shutil.disk_usage(ROOT).free / 2**30
    # Evaluation writes only logs; it must not inherit the checkpoint threshold.
    if phase == "eval":
        return free_gib >= float(registry.get("eval_disk_floor_gib", 1))
    pending_writes = sum(required_disk_gib(r["job"], r["attempt"]["phase"]) for r in active.values())
    return free_gib - pending_writes - required_disk_gib(job, phase) >= float(registry.get("train_disk_floor_gib", 12))


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--adopt-running", action="store_true")
    args = parser.parse_args()
    singleton = (HERE / "guardian.lock").open("a+")
    fcntl.flock(singleton, fcntl.LOCK_EX | fcntl.LOCK_NB)
    registry = read(HERE / "jobs.json")
    if not registry:
        raise RuntimeError("jobs.json missing")
    if registry.get("model_pin"):
        pin = registry["model_pin"]
        if hashlib.sha256(Path(pin["path"]).read_bytes()).hexdigest() != pin["sha256"]:
            raise RuntimeError("Pinned model weight SHA mismatch")
    state = read(HERE / "status.json", {"jobs": {}})
    statuses = state["jobs"]
    active = {}
    by_id = {job["id"]: job for job in registry["jobs"]}
    for job_id, status in statuses.items():
        if status.get("status") == "running":
            if not args.adopt_running:
                raise RuntimeError("Use explicit --adopt-running only for a verified controller handoff")
            attempt = status["attempts"][-1]
            process = AdoptedProcess(status["pid"], attempt["output_dir"], status["phase"])
            active[status["gpu"]] = dict(
                process=process,
                lock=None,
                logfile=None,
                job=by_id[job_id],
                status=status,
                attempt=attempt,
                output=Path(attempt["output_dir"]),
                known_pids=descendants(process.pid),
                stop_at=None,
            )
            status["controller_handoff"] = dict(
                timestamp=now(), controller_pid=os.getpid(), exit_code_will_be_unavailable=True
            )
            log("adopt_running", job=job_id, pid=process.pid, gpu=status["gpu"])
    write(HERE / "guardian.pid.json", dict(pid=os.getpid(), started_at=now(), session=os.getsid(0)))
    last_analysis, last_heartbeat, analysis_process = 0.0, 0.0, None
    last_disk_notice = {}
    try:
        while True:
            try:
                registry = read(HERE / "jobs.json", registry)
                jobs = registry["jobs"]
                for job in jobs:
                    statuses.setdefault(job["id"], dict(status="pending", phase="train", attempts=[]))
                    status = statuses[job["id"]]
                    # Adopt already-finished preregistered seed0 bootstrap runs.
                    bootstrap = Path(job["base_output_dir"]) / "summary.json"
                    if not status["attempts"] and bootstrap.exists() and status["phase"] == "train":
                        attempt = dict(
                            index=0,
                            phase="train",
                            output_dir=str(bootstrap.parent),
                            stdout=str(bootstrap.parent / "train.log"),
                            gpu=None,
                            start_time=None,
                            end_time=now(),
                            returncode=0,
                            contaminated=False,
                            resume_from=None,
                            accepted_start_step=0,
                            accepted_end_step=0,
                        )
                        if accepted_summary(job, status, bootstrap, attempt):
                            status["attempts"].append(attempt)
                            status["resolved_source_sha256"] = resolved_source(job)
                cards = inventory()
                for gpu, running in list(active.items()):
                    if running["process"].poll() is not None:
                        foreign_at_exit = set(cards.get(gpu, {}).get("pids", [])) - running["known_pids"]
                        if foreign_at_exit:
                            running["attempt"]["contaminated"] = True
                            running["status"]["foreign_at_exit"] = sorted(foreign_at_exit)
                        try:
                            complete(running)
                        except Exception as exc:
                            running["status"].update(
                                status="failed", error=f"checkpoint/completion verification failed: {exc}"
                            )
                            running["status"].pop("pid", None)
                            running["attempt"].update(end_time=now(), verification_error=str(exc))
                            for handle in (running["logfile"], running["lock"]):
                                if handle is not None:
                                    handle.close()
                            log("completion_verification_error", job=running["job"]["id"], error=str(exc))
                        del active[gpu]
                        continue
                    running["known_pids"].update(descendants(running["process"].pid))
                    foreign = set(cards.get(gpu, {}).get("pids", [])) - running["known_pids"]
                    if foreign:
                        request_stop(running, f"foreign GPU process appeared: {sorted(foreign)}")
                    if running["job"]["track"] == "sft" and running["attempt"]["phase"] == "train":
                        heartbeat_path = running["output"] / "heartbeat.json"
                        heartbeat = read(heartbeat_path, {})
                        stamp = heartbeat.get("timestamp", running["attempt"]["start_time"])
                        if stamp and (datetime.now(UTC) - datetime.fromisoformat(stamp)).total_seconds() > 900:
                            request_stop(running, "stalled training heartbeat; request recovery")
                    if running["stop_at"]:
                        io_bytes = 0
                        for pid in running["known_pids"]:
                            try:
                                counters = dict(
                                    line.split(": ") for line in Path(f"/proc/{pid}/io").read_text().splitlines()
                                )
                                io_bytes += int(counters.get("rchar", 0)) + int(counters.get("wchar", 0))
                            except (OSError, ValueError):
                                continue
                        if io_bytes != running.get("save_io_marker"):
                            running.update(save_io_marker=io_bytes, save_last_progress=time.monotonic())
                        elapsed = time.monotonic() - running["stop_at"]
                        stalled = time.monotonic() - running.get("save_last_progress", running["stop_at"])
                        if elapsed > 900 or stalled > 300:
                            log("force_stop_own_session", job=running["job"]["id"], elapsed=elapsed, stalled=stalled)
                            try:
                                os.killpg(running["process"].pid, signal.SIGKILL)
                            except ProcessLookupError:
                                pass
                    if datetime.now(UTC) >= datetime.fromisoformat(registry["report_at"]):
                        request_stop(running, "morning report cutoff; checkpoint unfinished fixed-budget job")
                current = datetime.now(UTC)
                cutoff = datetime.fromisoformat(registry["report_at"])
                deadline = datetime.fromisoformat(registry["launch_deadline"])
                available = [gpu for gpu, card in cards.items() if gpu in registry.get("allowed_gpus", [0, 1, 2, 3]) and gpu not in active and not card["pids"]]
                candidates = sorted(
                    (job for job in jobs if statuses[job["id"]]["status"] == "pending" and eligible(job, statuses)),
                    key=lambda job: (0 if statuses[job["id"]]["phase"] == "eval" else 1, job["priority"]),
                )
                for gpu in available:
                    if not candidates:
                        continue
                    chosen = None
                    for job in candidates:
                        if not disk_admission(job, statuses[job["id"]]["phase"], active, registry):
                            if time.monotonic() - last_disk_notice.get(job["id"], 0) > 60:
                                log("disk_blocked", job=job["id"], phase=statuses[job["id"]]["phase"], free_gib=shutil.disk_usage(ROOT).free / 2**30)
                                last_disk_notice[job["id"]] = time.monotonic()
                            continue
                        if current >= (cutoff if statuses[job["id"]]["phase"] == "eval" else deadline):
                            continue
                        estimate = (
                            job.get("estimated_seconds", 1200) if statuses[job["id"]]["phase"] == "train" else 180
                        )
                        if (cutoff - current).total_seconds() > estimate * 1.15:
                            chosen = job
                            break
                    if chosen is None:
                        continue
                    lock_fd = (ROOT / f"runs/gpu{gpu}.lock").open("a+")
                    try:
                        fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    except BlockingIOError:
                        lock_fd.close()
                        continue
                    if inventory()[gpu]["pids"]:
                        lock_fd.close()
                        continue
                    try:
                        resolved_source(chosen)
                        active[gpu] = launch(chosen, statuses[chosen["id"]], gpu, lock_fd, statuses)
                    except Exception as exc:
                        lock_fd.close()
                        statuses[chosen["id"]].update(status="failed", error=str(exc))
                        log("launch_error", job=chosen["id"], error=str(exc))
                    candidates.remove(chosen)
                state.update(
                    updated_at=now(),
                    guardian_pid=os.getpid(),
                    gpu_inventory=cards,
                    free_disk_gib=shutil.disk_usage(ROOT).free / 2**30,
                )
                write(HERE / "status.json", state)
                if analysis_process is not None and analysis_process.poll() is not None:
                    if analysis_process.returncode:
                        log("analysis_error", returncode=analysis_process.returncode, log=str(HERE / "analysis.log"))
                    analysis_process = None
                if (
                    analysis_process is None
                    and time.monotonic() - last_analysis > 60
                    and (HERE / "analyze.py").exists()
                ):
                    with (HERE / "analysis.log").open("a") as report_log:
                        analysis_process = subprocess.Popen(
                            [sys.executable, str(HERE / "analyze.py")],
                            cwd=HERE,
                            stdout=report_log,
                            stderr=subprocess.STDOUT,
                        )
                    last_analysis = time.monotonic()
                if time.monotonic() - last_heartbeat > 60:
                    log(
                        "heartbeat",
                        active={gpu: item["job"]["id"] for gpu, item in active.items()},
                        counts={
                            label: sum(s["status"] == label for s in statuses.values())
                            for label in ["complete", "running", "pending", "failed"]
                        },
                        free_disk_gib=state["free_disk_gib"],
                    )
                    last_heartbeat = time.monotonic()
                terminal = all(s["status"] in {"complete", "failed", "deferred"} for s in statuses.values())
                pending_evaluation = any(
                    s["status"] == "pending" and s.get("phase") == "eval" for s in statuses.values()
                )
                if not active and (terminal or current >= cutoff or (current >= deadline and not pending_evaluation)):
                    for status in statuses.values():
                        if status["status"] == "pending":
                            status.update(status="deferred", error="not launched within morning resource/time window")
                    state.update(updated_at=now(), finished_at=now())
                    write(HERE / "status.json", state)
                    if (HERE / "analyze.py").exists():
                        if analysis_process is not None:
                            try:
                                analysis_process.wait(timeout=120)
                            except subprocess.TimeoutExpired:
                                analysis_process.terminate()
                                analysis_process.wait(timeout=10)
                        subprocess.run([sys.executable, str(HERE / "analyze.py")], cwd=HERE, timeout=120, check=False)
                    log("guardian_finished")
                    return
                time.sleep(15)
            except Exception as exc:
                log("iteration_error", error=repr(exc))
                state.update(updated_at=now(), guardian_pid=os.getpid(), last_error=repr(exc))
                write(HERE / "status.json", state)
                time.sleep(20)
    finally:
        for running in active.values():
            request_stop(running, "guardian shutdown; cooperative recovery requested")


if __name__ == "__main__":
    main()
