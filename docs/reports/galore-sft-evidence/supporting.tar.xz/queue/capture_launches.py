"""Capture real commands and whitelisted settings of this queue's live jobs."""

import fcntl
import hashlib
import json
import os
import time
from datetime import UTC, datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent
ENV_KEYS = {
    "CUDA_VISIBLE_DEVICES",
    "OMP_NUM_THREADS",
    "PYTHONPATH",
    "ARENO_BENCH_SEED",
    "CUBLAS_WORKSPACE_CONFIG",
    "PYTHONDONTWRITEBYTECODE",
}


def main():
    lock = (HERE / "capture-launches.lock").open("a+")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    target = HERE / "launch-commands.json"
    output = json.loads(target.read_text()) if target.exists() else {"entries": []}
    seen = {(r["job_id"], r["attempt_index"]) for r in output["entries"]}
    output["capture_source_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    while True:
        state = json.loads((HERE / "status.json").read_text())
        for job_id, row in state["jobs"].items():
            if row["status"] != "running":
                continue
            attempt = row["attempts"][-1]
            key = job_id, attempt["index"]
            if key in seen:
                continue
            proc = Path("/proc") / str(row["pid"])
            try:
                command = [s.decode() for s in (proc / "cmdline").read_bytes().split(b"\0") if s]
                if attempt["output_dir"] not in command:
                    continue
                if not any(s.endswith(f"/{row['phase']}.py") for s in command):
                    continue
                variables = {}
                for item in (proc / "environ").read_bytes().split(b"\0"):
                    name, sep, value = item.partition(b"=")
                    if sep and name.decode() in ENV_KEYS:
                        variables[name.decode()] = value.decode()
                record = {
                    "job_id": job_id,
                    "attempt_index": attempt["index"],
                    "phase": row["phase"],
                    "pid": row["pid"],
                    "gpu": row["gpu"],
                    "command": command,
                    "cwd": os.readlink(proc / "cwd"),
                    "cpu_affinity": sorted(os.sched_getaffinity(row["pid"])),
                    "environment": variables,
                    "captured_at": datetime.now(UTC).isoformat(),
                    "registry_sha256": hashlib.sha256((HERE / "jobs.json").read_bytes()).hexdigest(),
                }
            except (OSError, ProcessLookupError):
                continue
            output["entries"].append(record)
            seen.add(key)
            print(json.dumps({"captured": job_id, "phase": row["phase"]}), flush=True)
        output["updated_at"] = datetime.now(UTC).isoformat()
        temporary = target.with_suffix(".next.json")
        temporary.write_text(json.dumps(output, indent=2) + "\n")
        temporary.replace(target)
        if all(r["status"] in {"complete", "failed", "deferred"} for r in state["jobs"].values()):
            break
        guardian = Path("/proc") / str(state.get("guardian_pid", -1)) / "cmdline"
        try:
            if str(HERE / "guardian.py").encode() not in guardian.read_bytes():
                break
        except OSError:
            break
        time.sleep(5)


if __name__ == "__main__":
    main()
