# Preregistered secondary data track — Dolly instruction corpus

Registered before downloading or processing dataset contents. This track is exploratory and separate from the canonical64/16 repository-text acceptance fold; it must never replace or overwrite that evidence. Existing four literature reviews and four structural optimizer screens are already complete. This is a Tier2 external-validity/data-scale follow-up, not a novelty claim or a new first-round structural experiment.

## Tasks and rationale

1. Inspect caches and primary dataset documentation, then resolve a ModelScope dataset mirror/revision. Cache inspection found no existing dataset payload under the project ModelScope/HF caches; shared runtime packages will remain frozen.
2. Acquire the human-authored Databricks Dolly15k corpus if accessible. First try ModelScope metadata/download APIs. If the expected mirrors are unavailable, explicitly record the failure and use the dataset owner's official `databrickslabs/dolly` GitHub data at one immutable commit. No silent HuggingFace fallback.
3. Preserve immutable raw files, revision, SHA256, license/attribution and download URLs. Produce untruncated JSONL examples and a per-row manifest.
4. Normalize only keys used for grouping/deduplication; preserve source instruction/context/response content in the actual examples. Remove invalid empty instruction/response rows and exact normalized full-example duplicates. Group by normalized nonempty reference context (document proxy), or by normalized instruction for context-free examples. This prevents identical reference passages/prompts from crossing folds. Dolly does not expose Wikipedia article IDs, so exact article-level disjointness cannot be claimed.
5. Split entire groups using SHA256 of a fixed split salt plus group key:90%train/5%validation/5%test. Splits are fixed independently of training seed and model results. Retain all valid rows, expected≈13k training examples and a few million Qwen tokens. Seeds0/1/2 alter training order only.
6. Validate fold/group/prompt/full-example disjointness, calculate tokenizer length/target statistics at context512/1024 without changing the stored examples, run CPU integrity smoke and lint, and write `CHANGES.md`, provenance and a summary.

## Hypothesis and readouts

The initial24-example/12-update trial may reward a scale/history policy that does not remain stable under varied tasks or longer contexts. A human-written instruction corpus with diverse categories, multi-million-token budgets and document-proxy grouping tests that external validity. Reviews1A/1B motivate broader data and matched evaluation; reviews2A/2B motivate assessing refresh cost and coordinate-history behavior over many boundaries. This preparation does not select an optimizer configuration or consume validation/test loss.

The owner's primary documentation describes instruction/response records across brainstorming, classification, closed/open QA, generation, extraction and summarization, with reference passages sometimes from Wikipedia. Dataset license is CC-BY-SA3.0; exact owner documentation and license will be captured with the raw corpus. Source: https://github.com/databrickslabs/dolly and its `data` directory.

Preparation readouts: source row count, dropped duplicate/invalid counts, category counts, train/validation/test group counts and SHA256, whole/prompt/response token quantiles and totals, response-loss viability at512/1024, and every integrity assertion. No GPU work or model-quality metric is performed here. CPU28–31, one local tokenizer, all artifacts/caches under `/mnt2/ling`.

Expected runtime: raw download<2min for≈13MB, processing/tokenization<5min on four CPU cores; replace estimates with actual timings. Parent registers training budget/packing/caps independently before seeing new validation losses. Stored data are never truncated; the harness must explicitly document how it preserves response targets when prompts exceed its context cap.

## Resolved source and frozen preprocessing contract

ModelScope metadata resolved `AI-ModelScope/databricks-dolly-15k` at immutable revision `40789acc12fc986e9145f87d159f19e2f1d75c6a`; raw JSONL expected13,085,339bytes and SHA256 `2df9083338b4abd6bceb5635764dab5d833b393b55759dffb0959b6fcbf794ec`. The alternate short mirror name does not exist and is recorded in `modelscope-probe.json`. No fallback is needed.

Output prompt format is `### Instruction:\n{instruction}\n\n`, optional `### Context:\n{context}\n\n`, then `### Response:\n`; output `response` preserves the original response with only outer whitespace removed. No chat-template expansion, EOS insertion or token truncation occurs in stored JSONL. Dedup/group keys use Unicode NFKC, whitespace collapse and casefold; exact normalized full-example duplicates retain the first source row. Context-free groups use normalized instruction; otherwise use normalized entire reference context. Group-to-fold assignment is `int(SHA256("areno-dolly-group-split-v1:" + group_id)[:16],16) % 10000`, bins `[0,9000)` train, `[9000,9500)` validation, else test. Source order is preserved within each fold. No target-length or category filtering is applied, except invalid/empty required strings. Training permutations use `random.Random(seed).shuffle` for seeds0/1/2 and never alter folds.
