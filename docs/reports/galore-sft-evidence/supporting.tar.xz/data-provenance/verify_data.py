"""Independently audit serialized examples against raw source and fixed contracts."""

from __future__ import annotations

import hashlib
import json
import random
import unicodedata
from pathlib import Path


def normalize(value):
    return " ".join(unicodedata.normalize("NFKC", value).split()).casefold()


def main():
    root = Path(__file__).resolve().parent
    data = root / "data"
    summary = json.loads((data / "summary.json").read_text())
    raw = [json.loads(line) for line in (root / "raw/databricks-dolly-15k.jsonl").read_text().splitlines()]
    groups, prompts, records, all_source_ids, split_sizes = {}, {}, {}, set(), {}
    for split in ("train", "validation", "test"):
        rows = [json.loads(line) for line in (data / f"{split}.jsonl").read_text().splitlines()]
        manifest = [json.loads(line) for line in (data / f"{split}.manifest.jsonl").read_text().splitlines()]
        assert len(rows) == len(manifest) == summary["splits"][split]["rows"]
        groups[split], prompts[split], records[split] = set(), set(), set()
        split_sizes[split] = len(rows)
        for index, (row, record) in enumerate(zip(rows, manifest, strict=True)):
            assert set(row) == {"prompt", "response"}
            assert record["index"] == index
            source_id = record["source_index"]
            assert source_id not in all_source_ids
            all_source_ids.add(source_id)
            original = raw[source_id]
            instruction, context, response = (original[key].strip() for key in ("instruction", "context", "response"))
            pieces = ["### Instruction:", instruction, ""]
            if context:
                pieces += ["### Context:", context, ""]
            expected_prompt = "\n".join(pieces + ["### Response:", ""])
            assert row["prompt"] == expected_prompt and row["response"] == response
            assert response and record["response_tokens"] > 0
            assert record["total_tokens"] == record["prompt_tokens"] + record["response_tokens"]
            group = ("context", normalize(context)) if context else ("instruction", normalize(instruction))
            group_hash = hashlib.sha256((group[0] + ":" + group[1]).encode()).hexdigest()
            assert group_hash == record["group_id"]
            bucket = (
                int(hashlib.sha256(("areno-dolly-group-split-v1:" + group_hash).encode()).hexdigest()[:16], 16) % 10000
            )
            assert split == ("train" if bucket < 9000 else "validation" if bucket < 9500 else "test")
            groups[split].add(group)
            prompts[split].add(normalize(row["prompt"]))
            records[split].add((normalize(instruction), normalize(context), normalize(response)))
        assert (
            sum(record["response_tokens"] for record in manifest)
            == summary["splits"][split]["response_tokens"]["total"]
        )
        assert sum(record["total_tokens"] for record in manifest) == summary["splits"][split]["total_tokens"]["total"]
    for family in (groups, prompts, records):
        assert not family["train"] & family["validation"]
        assert not family["train"] & family["test"]
        assert not family["validation"] & family["test"]
    dropped_ids = {record["source_index"] for record in summary["dropped_rows"]}
    assert not dropped_ids & all_source_ids
    assert all_source_ids | dropped_ids == set(range(len(raw)))
    assert split_sizes["train"] > 10000 and split_sizes["validation"] > 500 and split_sizes["test"] > 500
    for seed in (0, 1, 2):
        actual = json.loads((data / "orders" / f"seed{seed}.json").read_text())
        expected = list(range(split_sizes["train"]))
        random.Random(seed).shuffle(expected)
        assert actual == expected
    for name, record in summary["files"].items():
        path = data / name
        assert path.stat().st_size == record["bytes"]
        assert hashlib.sha256(path.read_bytes()).hexdigest() == record["sha256"]
    result = {
        "status": "passed",
        "split_rows": split_sizes,
        "raw_rows": len(raw),
        "retained_source_rows": len(all_source_ids),
        "dropped_rows": len(dropped_ids),
        "assertions": [
            "raw-to-serialized exact content, no truncation",
            "registered hash-group assignment",
            "group/prompt/full-example disjointness",
            "raw source accounting",
            "positive targets and token totals",
            "fixed seed0/1/2 train permutations",
            "all serialized file hashes",
        ],
    }
    (root / "integrity.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
