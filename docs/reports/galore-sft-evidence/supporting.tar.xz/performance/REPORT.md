# Selected scale2/all-matrix same-GPU performance

GPU1 `GPU-d78c0eae-9ae7-3849-fa3d-f092f7502900`, source `142c7be2c33f871badad4105bd682d4e34da3d3c32e17278dba67324e45c21e1`. Each method ran in a fresh process with 2 warmups + 400 measured updates. All 402 input batch hashes/target counts and the initial forward loss matched. Native SFT diagnostic was 0 throughout. No foreign PID was observed on this GPU. No validation/test or checkpoint I/O was performed.

| Method | Allocated GiB | Reserved GiB | Sync train profile ms/update | Actor-score+train ms/update | Targets/s (score+train) | Measured refreshes |
|---|---:|---:|---:|---:|---:|---:|
| adamw | 12.084 | 13.141 | 494.14 | 603.59 | 531.80 | 0 |
| adam8 | 8.453 | 9.668 | 466.54 | 575.67 | 557.59 | 0 |
| galore | 8.272 | 9.367 | 520.29 | 623.70 | 514.66 | 2 |

GaLore reduced peak allocated memory by 31.54% versus AdamW and 2.14% versus 8-bit Adam. Actor-score+train time increased by 3.33% and 8.34%, respectively. It exchanges lower allocated memory for slower updates in this workload.

The selected GaLore uses rank128/gap200/scale2/transport/vocabulary-included/recycled+QR+compact+fused. Other model/runtime/lr/beta/clip/batch/context/seed settings are matched. Actual measured refresh steps are 200 and 400; the initial step 0 refresh is inside warmup and excluded from timing summaries.

| GaLore subset | Updates | Sync train profile ms/update | Score+train ms/update | Allocated GiB |
|---|---:|---:|---:|---:|
| normal | 398 | 508.79 | 612.19 | 8.272 |
| refresh | 2 | 2807.76 | 2912.92 | 8.143 |

The raw cuda_step_time_s field uses perf_counter bracketed by torch.cuda.synchronize, summed across microbatches; it is synchronized training-segment wall time, not kernel-only CUDA-event time. Framework memory peaks aggregate max over per-microbatch training profiles; sampled NVML memory is separately recorded as a lower bound. Other GPUs carried independent jobs, so this is card-exclusive rather than node-exclusive. There is one sequential timing trial per method and no quality comparison. Actor-score+train throughput excludes logging, batch preparation and model initialization. No timing claim is inferred from the mocked CPU smoke.

Raw outputs: [AdamW](outputs/adamw/steps.jsonl), [8-bit Adam](outputs/adam8/steps.jsonl), [GaLore](outputs/galore/steps.jsonl). Each output directory retains metadata, encoding, launcher, summary and one-second nvml-audit files. Exact commands/environment/model/source/wrapper/data identities are in [RUN_MANIFEST.json](RUN_MANIFEST.json). Complete machine-readable results and ratios are in [summary.json](summary.json).
