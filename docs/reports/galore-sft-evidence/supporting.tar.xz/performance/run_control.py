"""Exclusive physical-GPU1 sequential fresh-process performance measurement."""
from __future__ import annotations
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
REPO=HERE.parent/'candidate-pr'
DATA=ROOT/'runs/experiments/overnight_20261029_data/data'
MODEL=ROOT/'models/Qwen3-0.6B'
EXPECTED='142c7be2c33f871badad4105bd682d4e34da3d3c32e17278dba67324e45c21e1'

def now():return datetime.now(timezone.utc).isoformat()
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(16*1024*1024),b''):h.update(b)
    return h.hexdigest()
def source_hash():
    h=hashlib.sha256()
    for p in sorted((REPO/'areno').rglob('*.py')):h.update(str(p.relative_to(REPO)).encode());h.update(p.read_bytes())
    return h.hexdigest()
def write(p,data):
    temp=p.with_suffix(p.suffix+'.tmp');temp.write_text(json.dumps(data,indent=2)+'\n');temp.replace(p)
def inventory():
    card=subprocess.check_output(['nvidia-smi','--id=1','--query-gpu=index,uuid,memory.used,utilization.gpu,temperature.gpu,clocks.current.sm,power.draw','--format=csv,noheader,nounits'],text=True).strip().split(',')
    card=[x.strip() for x in card]
    processes=subprocess.check_output(['nvidia-smi','--query-compute-apps=pid,gpu_uuid,used_memory','--format=csv,noheader,nounits'],text=True)
    pids=[]
    for line in processes.splitlines():
        fields=[v.strip() for v in line.split(',')]
        if len(fields)==3 and fields[1]==card[1]:pids.append({'pid':int(fields[0]),'memory_mib':fields[2]})
    return {'timestamp':now(),'index':int(card[0]),'uuid':card[1],'memory_mib':int(card[2]),'utilization_gpu':card[3],'temperature_c':card[4],'sm_clock_mhz':card[5],'power_w':card[6],'processes':pids}
def descendants(pid):
    parents={}
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:parents[int(p.name)]=int((p/'stat').read_text().split(') ',1)[1].split()[1])
        except (OSError,ValueError,IndexError):pass
    found={pid}
    while True:
        expanded=found|{k for k,v in parents.items() if v in found}
        if expanded==found:return found
        found=expanded

def stop_owned(proc,owned):
    try:os.killpg(proc.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    for pid in owned:
        try:os.kill(pid,signal.SIGTERM)
        except ProcessLookupError:pass
    try:proc.wait(timeout=15)
    except subprocess.TimeoutExpired:
        try:os.killpg(proc.pid,signal.SIGKILL)
        except ProcessLookupError:pass
        for pid in owned:
            try:os.kill(pid,signal.SIGKILL)
            except ProcessLookupError:pass
        proc.wait()

def main():
    os.sched_setaffinity(0,{40,41,42,43})
    lock=(ROOT/'runs/gpu1.lock').open('a+')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    initial=inventory();assert not initial['processes'] and initial['memory_mib']<100,initial
    assert source_hash()==EXPECTED
    manifest={'started_at':now(),'gpu':1,'gpu_uuid':initial['uuid'],'lock':str(ROOT/'runs/gpu1.lock'),'controller_pid':os.getpid(),'source_sha256':EXPECTED,'wrapper_sha256':{n:sha(HERE/n) for n in ['common.py','train_perf.py','run_control.py']},'training_data_sha256':sha(DATA/'train.jsonl'),'base_model_sha256':sha(MODEL/'model.safetensors'),'initial_inventory':initial,'methods':{},'status':'running'}
    assert manifest['base_model_sha256']=='f47f71177f32bcd101b7573ec9171e6a57f4f4d31148d38e382306f42996874b'
    write(HERE/'RUN_MANIFEST.json',manifest);write(HERE/'LOCKED.json',{'locked':True,'timestamp':now(),'gpu':1,'gpu_uuid':initial['uuid'],'pid':os.getpid()})
    print('GPU1 LOCKED '+initial['uuid'],flush=True)
    for method in ['adamw','adam8','galore']:
        assert source_hash()==EXPECTED
        card=inventory();assert not card['processes'] and card['memory_mib']<100,card
        output=HERE/'outputs'/method;output.mkdir(parents=True,exist_ok=False)
        cmd=['taskset','-c','40-43',sys.executable,str(HERE/'train_perf.py'),'--model',str(MODEL),'--data-dir',str(DATA),'--checkpoint-dir',str(HERE/'NO_CHECKPOINTS'/method),'--output-dir',str(output),'--optimizer',method,'--seed','0','--context','512','--batch','4','--micro-batch','2','--rank','128','--gap','200','--scale','2','--extra-config-json','{"optimizer":{"galore_exclude_vocab":false}}','--warmup-updates','2','--measured-updates','400']
        env=dict(os.environ,CUDA_VISIBLE_DEVICES='1',OMP_NUM_THREADS='4',PYTHONPATH=f'{REPO}:{HERE}',ARENO_BENCH_SEED='0',PYTHONDONTWRITEBYTECODE='1')
        env.pop('CUBLAS_WORKSPACE_CONFIG',None);env.pop('INTEGRATED_GPU_LOCKED',None)
        entry={'command':cmd,'environment':{k:env.get(k) for k in ['CUDA_VISIBLE_DEVICES','OMP_NUM_THREADS','PYTHONPATH','ARENO_BENCH_SEED','CUBLAS_WORKSPACE_CONFIG']},'cwd':str(REPO),'started_at':now(),'contaminated':False,'foreign_pids':[],'gpu_uuid':card['uuid'],'output':str(output)}
        log=(output/'launcher.log').open('w')
        proc=subprocess.Popen(cmd,cwd=REPO,env=env,stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True,pass_fds=(lock.fileno(),))
        entry['pid']=proc.pid;manifest['methods'][method]=entry;write(HERE/'RUN_MANIFEST.json',manifest)
        print('START '+method+' pid='+str(proc.pid),flush=True)
        owned={proc.pid};started=time.monotonic()
        with (output/'nvml-audit.jsonl').open('w') as nvml:
            while True:
                owned|=descendants(proc.pid)
                row=inventory();foreign={p['pid'] for p in row['processes']}-owned
                row['owned_pids']=sorted(owned);row['foreign_pids']=sorted(foreign)
                nvml.write(json.dumps(row)+'\n');nvml.flush()
                if foreign:
                    entry['contaminated']=True;entry['foreign_pids']=sorted(foreign);stop_owned(proc,owned);break
                if proc.poll() is not None:break
                if time.monotonic()-started>900:
                    entry['error']='900second runtime budget';stop_owned(proc,owned);break
                time.sleep(1)
        log.close();entry['returncode']=proc.wait();entry['ended_at']=now();entry['source_unchanged']=source_hash()==EXPECTED
        summary=output/'summary.json'
        if summary.exists():entry['summary']=json.loads(summary.read_text());entry['summary_sha256']=sha(summary)
        entry['accepted']=entry['returncode']==0 and not entry['contaminated'] and entry['source_unchanged'] and entry.get('summary',{}).get('status')=='complete'
        write(HERE/'RUN_MANIFEST.json',manifest)
        print('END '+method+' accepted='+str(entry['accepted']),flush=True)
        if not entry['accepted']:
            manifest['status']='stopped';break
        # Allow own exited process contexts to disappear without overlapping the next method.
        deadline=time.monotonic()+15
        while inventory()['processes'] and time.monotonic()<deadline:time.sleep(1)
    if all(manifest['methods'].get(m,{}).get('accepted') for m in ['adamw','adam8','galore']):manifest['status']='complete'
    manifest['ended_at']=now();manifest['final_inventory']=inventory();write(HERE/'RUN_MANIFEST.json',manifest)
    write(HERE/'LOCKED.json',{'locked':False,'released_at':now(),'gpu':1,'gpu_uuid':initial['uuid'],'pid':os.getpid()})
    fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
    print('GPU1 RELEASED status='+manifest['status'],flush=True)

if __name__=='__main__':main()
