"""Audit all three raw runs and report only the preregistered measured subset."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
manifest=json.loads((HERE/'RUN_MANIFEST.json').read_text())
assert manifest['status']=='complete','wait for actual runs to finish'
assert json.loads((HERE/'LOCKED.json').read_text())['locked'] is False
methods={};batches={};first_losses={}
for method in ['adamw','adam8','galore']:
    entry=manifest['methods'][method];assert entry['accepted'] and not entry['contaminated']
    output=Path(entry['output']);rows=[json.loads(x) for x in (output/'steps.jsonl').read_text().splitlines()]
    metadata=json.loads((output/'metadata.json').read_text());summary=json.loads((output/'summary.json').read_text())
    assert len(rows)==402 and [r['step'] for r in rows]==list(range(402))
    assert [r['step'] for r in rows if r['warmup']]==[0,1]
    assert all(r['update_optimizer_steps']==1 and r['logp_abs_diff_mean']==0 for r in rows)
    assert summary['measured_updates']==400 and summary['native_logp_abs_diff_max']==0
    assert summary['refresh_steps']==([200,400] if method=='galore' else [])
    assert metadata['source_sha256']==manifest['source_sha256']
    assert set(metadata['data_sha256'])=={'train'} and metadata['data_sha256']['train']==manifest['training_data_sha256']
    assert metadata['cuda_visible_devices']=='1' and metadata['cpu_affinity']==[40,41,42,43]
    assert metadata['cublas_workspace_config'] is None
    for name,h in metadata['wrapper_sha256'].items():assert hashlib.sha256((HERE/name).read_bytes()).hexdigest()==h
    audits=[json.loads(x) for x in (output/'nvml-audit.jsonl').read_text().splitlines()]
    assert audits and all(not a['foreign_pids'] and a['uuid']==manifest['gpu_uuid'] for a in audits)
    peak=max(a['memory_mib'] for a in audits)
    methods[method]={'summary':summary,'metadata':metadata,'nvml_samples':len(audits),'nvml_sampled_memory_peak_mib_lower_bound':peak,'foreign_pid_observed':False,'first_loss':rows[0]['loss'],'raw_steps_sha256':hashlib.sha256((output/'steps.jsonl').read_bytes()).hexdigest(),'nvml_audit_sha256':hashlib.sha256((output/'nvml-audit.jsonl').read_bytes()).hexdigest()}
    batches[method]=[(r['batch_sha256'],r['target_tokens'],r['sample_indices']) for r in rows]
    first_losses[method]=rows[0]['loss']
assert batches['adamw']==batches['adam8']==batches['galore']
assert len(set(first_losses.values()))==1,first_losses
assert not list(HERE.rglob('*.pt')) and not list(HERE.rglob('*.safetensors'))
bytes_used=sum(p.stat().st_size for p in HERE.rglob('*') if p.is_file())
assert bytes_used<100*1024**2,bytes_used
result={'status':'complete','measurement':'matched-single-physical-GPU fresh-process training-only path','gpu':1,'gpu_uuid':manifest['gpu_uuid'],'source_sha256':manifest['source_sha256'],'measured_updates_per_method':400,'warmup_updates_per_method':2,'all_batches_targets_identical':True,'initial_forward_loss_identical':True,'initial_forward_loss':next(iter(first_losses.values())),'native_logp_abs_diff_max':0,'methods':methods,'disk_bytes_before_report':bytes_used,'saved_checkpoints':False,'read_validation_or_test':False,'quality_result':None,'limitations':['one seed and one sequential process per method; no repeated timing confidence interval','other GPUs run independent parent jobs; this card is exclusive, the entire node is not','framework allocated/reserved peaks are max of per-microbatch training profiles','cuda_step_time_s is synchronized perf_counter training-segment time, not kernel-only CUDA-event elapsed time','NVML one-second samples are lower bounds on whole-process memory peaks','wall throughput includes actor scoring and public train calls, excludes batch preparation/logging/model initialization']}
g=methods['galore']['summary']['all']
result['galore_comparisons']={}
for baseline in ['adamw','adam8']:
    b=methods[baseline]['summary']['all']
    result['galore_comparisons'][baseline]={'allocated_reduction_fraction':1-g['allocated_peak_bytes']/b['allocated_peak_bytes'],'reserved_reduction_fraction':1-g['reserved_peak_bytes']/b['reserved_peak_bytes'],'wall_time_ratio':g['score_plus_train_s']['mean']/b['score_plus_train_s']['mean'],'cuda_time_ratio':g['cuda_time_s']['mean']/b['cuda_time_s']['mean'],'wall_throughput_ratio':g['target_tokens_per_wall_second']/b['target_tokens_per_wall_second']}
(HERE/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
lines=['# Selected scale2/all-matrix same-GPU performance', '', f"GPU1 `{manifest['gpu_uuid']}`, source `{manifest['source_sha256']}`. Each method ran in a fresh process with 2 warmups + 400 measured updates. All 402 input batch hashes/target counts and the initial forward loss matched. Native SFT diagnostic was 0 throughout. No foreign PID was observed on this GPU. No validation/test or checkpoint I/O was performed.", '', '| Method | Allocated GiB | Reserved GiB | Sync train profile ms/update | Actor-score+train ms/update | Targets/s (score+train) | Measured refreshes |', '|---|---:|---:|---:|---:|---:|---:|']
for method,data in methods.items():
    s=data['summary'];a=s['all'];lines.append(f"| {method} | {a['allocated_peak_bytes']/2**30:.3f} | {a['reserved_peak_bytes']/2**30:.3f} | {a['cuda_time_s']['mean']*1000:.2f} | {a['score_plus_train_s']['mean']*1000:.2f} | {a['target_tokens_per_wall_second']:.2f} | {s['refresh']['updates']} |")
lines += ['', f"GaLore reduced peak allocated memory by {result['galore_comparisons']['adamw']['allocated_reduction_fraction']*100:.2f}% versus AdamW and {result['galore_comparisons']['adam8']['allocated_reduction_fraction']*100:.2f}% versus 8-bit Adam. Actor-score+train time increased by {(result['galore_comparisons']['adamw']['wall_time_ratio']-1)*100:.2f}% and {(result['galore_comparisons']['adam8']['wall_time_ratio']-1)*100:.2f}%, respectively. It exchanges lower allocated memory for slower updates in this workload.", '', 'The selected GaLore uses rank128/gap200/scale2/transport/vocabulary-included/recycled+QR+compact+fused. Other model/runtime/lr/beta/clip/batch/context/seed settings are matched. Actual measured refresh steps are 200 and 400; the initial step 0 refresh is inside warmup and excluded from timing summaries.', '', '| GaLore subset | Updates | Sync train profile ms/update | Score+train ms/update | Allocated GiB |', '|---|---:|---:|---:|---:|']
for subset in ['normal','refresh']:
    a=methods['galore']['summary'][subset];lines.append(f"| {subset} | {a['updates']} | {a['cuda_time_s']['mean']*1000:.2f} | {a['score_plus_train_s']['mean']*1000:.2f} | {a['allocated_peak_bytes']/2**30:.3f} |")
lines+=['', 'The raw cuda_step_time_s field uses perf_counter bracketed by torch.cuda.synchronize, summed across microbatches; it is synchronized training-segment wall time, not kernel-only CUDA-event time. Framework memory peaks aggregate max over per-microbatch training profiles; sampled NVML memory is separately recorded as a lower bound. Other GPUs carried independent jobs, so this is card-exclusive rather than node-exclusive. There is one sequential timing trial per method and no quality comparison. Actor-score+train throughput excludes logging, batch preparation and model initialization. No timing claim is inferred from the mocked CPU smoke.', '', 'Raw outputs: [AdamW](outputs/adamw/steps.jsonl), [8-bit Adam](outputs/adam8/steps.jsonl), [GaLore](outputs/galore/steps.jsonl). Each output directory retains metadata, encoding, launcher, summary and one-second nvml-audit files. Exact commands/environment/model/source/wrapper/data identities are in [RUN_MANIFEST.json](RUN_MANIFEST.json). Complete machine-readable results and ratios are in [summary.json](summary.json).', '']
(HERE/'REPORT.md').write_text('\n'.join(lines))
(HERE/'done.json').write_text(json.dumps({'status':'complete','gpu_released':True,'report':'REPORT.md','summary_sha256':hashlib.sha256((HERE/'summary.json').read_bytes()).hexdigest(),'all_methods_402_updates':True,'measured_updates_per_method':400,'actual_galore_measured_refreshes':2,'source_sha256':manifest['source_sha256'],'foreign_pid_observed':False,'native_logp_abs_diff_max':0,'disk_bytes_before_report':bytes_used},indent=2)+'\n')
print(json.dumps({'methods':{k:v['summary']['all'] for k,v in methods.items()},'ratios':result['galore_comparisons']},indent=2))
