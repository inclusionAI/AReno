"""Matched training-only performance path; never saves/evaluates a checkpoint."""
from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import statistics
import time
from datetime import datetime, timezone

import common
import torch
from areno.api import sft_loss_fn

EXPECTED_SOURCE = '142c7be2c33f871badad4105bd682d4e34da3d3c32e17278dba67324e45c21e1'


def source_hash(repo):
    h=hashlib.sha256()
    for p in sorted((Path(repo)/'areno').rglob('*.py')):
        h.update(str(p.relative_to(repo)).encode());h.update(p.read_bytes())
    return h.hexdigest()


def measure(rows):
    def distribution(key):
        values=sorted(r[key] for r in rows)
        return {'mean':statistics.mean(values),'median':statistics.median(values),'p95':values[math.ceil(.95*len(values))-1],'min':min(values),'max':max(values)} if values else None
    wall=sum(r['score_plus_train_seconds'] for r in rows)
    cuda=sum(r['update_cuda_time_s'] for r in rows)
    tokens=sum(r['target_tokens'] for r in rows)
    return {'updates':len(rows),'target_tokens':tokens,'score_plus_train_wall_seconds':wall,'cuda_seconds':cuda,'target_tokens_per_wall_second':tokens/wall if wall else None,'target_tokens_per_cuda_second':tokens/cuda if cuda else None,'cuda_time_s':distribution('update_cuda_time_s'),'score_plus_train_s':distribution('score_plus_train_seconds'),'scoring_s':distribution('scoring_seconds'),'allocated_peak_bytes':max((r['update_peak_allocated_bytes'] for r in rows),default=None),'reserved_peak_bytes':max((r['update_peak_reserved_bytes'] for r in rows),default=None)}


def main():
    p=common.parser(__doc__)
    p.add_argument('--measured-updates',type=int,default=400)
    p.add_argument('--warmup-updates',type=int,default=2)
    args=p.parse_args()
    if args.measured_updates<400 or args.warmup_updates!=2:p.error('this preregistered measurement requires warm2 + at least400 updates')
    if args.seed!=0 or args.context!=512 or args.batch!=4 or args.micro_batch!=2:p.error('matched seed0 ctx512 batch4 micro2 required')
    log=common.setup(args,'train-perf')
    import areno
    repo=Path(areno.__file__).resolve().parent.parent
    actual_source=source_hash(repo)
    assert actual_source==EXPECTED_SOURCE,actual_source
    assert common.digest(Path(__file__).with_name('common.py'))=='3248d7a542c8358ce7c78a5c6e264cde44cca136ec3e2238a41ad3824b21e424'
    train_sha=common.digest(args.data_dir/'train.jsonl')
    assert train_sha=='41765eb786b76354f4a7630d5101d46ba1ae08a2eabc35724db462f2d6d93447'
    info={'timestamp':datetime.now(timezone.utc).isoformat(),'arguments':{k:str(v) if isinstance(v,Path) else v for k,v in vars(args).items()},'source_root':str(repo),'source_sha256':actual_source,'torch_version':torch.__version__,'cuda_version':torch.version.cuda,'gpu':torch.cuda.get_device_name(0),'cuda_visible_devices':os.getenv('CUDA_VISIBLE_DEVICES'),'cpu_affinity':sorted(os.sched_getaffinity(0)),'cublas_workspace_config':os.getenv('CUBLAS_WORKSPACE_CONFIG'),'native_extension_sha256':common.digest(next((repo/'areno/accel').glob('_areno_accel*.so'))),'data_sha256':{'train':train_sha},'wrapper_sha256':{n:common.digest(Path(__file__).with_name(n)) for n in ['common.py','train_perf.py']},'saved_checkpoints':False,'read_validation_or_test':False,'note':'profile sum CUDA time / max per-microbatch allocator peaks; no model quality evaluation'}
    common.write(args.output_dir/'metadata.json',info)
    engine=common.trainer(args,resume=False)
    rows=[];orders={};started=time.perf_counter()
    try:
        engine.init()
        training,stats=common.encode(engine.get_tokenizer(),args,'train')
        common.write(args.output_dir/'encoding.json',stats)
        start=engine._ctx.global_step+1
        assert start==0,start
        with (args.output_dir/'steps.jsonl').open('w') as raw:
            for index in range(args.warmup_updates+args.measured_updates):
                indices=common.batch_indices(index,args.seed,len(training),args.batch,orders)
                batch=[training[i] for i in indices]
                stamp=datetime.now(timezone.utc).isoformat();begin=time.perf_counter()
                scored=engine.score_logprobs('actor',[s.tokens for s in batch],microbatch_size=args.micro_batch)
                for sample,values in zip(batch,scored,strict=True):sample.logprobs=list(values)
                scored_at=time.perf_counter()
                result=engine.train(batch,sft_loss_fn,mini_bs=args.micro_batch)
                elapsed=time.perf_counter()-begin
                assert result.get('update_optimizer_steps')==1,result
                assert math.isfinite(result['loss']) and result['logp_abs_diff_mean']==0,result
                row={'timestamp':stamp,'step':index,'sample_indices':indices,'batch_sha256':hashlib.sha256(json.dumps([(s.tokens,s.prompt_len) for s in batch],separators=(',',':')).encode()).hexdigest(),'target_tokens':sum(len(s.tokens)-s.prompt_len for s in batch),'warmup':index<args.warmup_updates,'scoring_seconds':scored_at-begin,'score_plus_train_seconds':elapsed,**result}
                raw.write(json.dumps(row)+'\n');raw.flush();rows.append(row)
                log.info('step %s',json.dumps(row))
        measured=rows[args.warmup_updates:];normal=[r for r in measured if not r['update_refresh_any']];refresh=[r for r in measured if r['update_refresh_any']]
        expected_refreshes=2 if args.optimizer=='galore' else 0
        assert len(refresh)==expected_refreshes,[r['step'] for r in refresh]
        summary={'status':'complete','optimizer':args.optimizer,'seed':args.seed,'completed_updates':len(rows),'warmup_updates':args.warmup_updates,'measured_updates':len(measured),'refresh_steps':[r['step'] for r in refresh],'all':measure(measured),'normal':measure(normal),'refresh':measure(refresh),'native_logp_abs_diff_max':max(r['logp_abs_diff_mean'] for r in rows),'elapsed_seconds':time.perf_counter()-started,'saved_checkpoints':False,'read_validation_or_test':False,'source_sha256':actual_source}
        common.write(args.output_dir/'summary.json',summary);log.info('complete %s',json.dumps(summary))
    finally:engine.close()


if __name__=='__main__':main()
