"""Verify complete raw evidence without extracting untrusted archive paths."""

import hashlib
import json
import tarfile
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root / "manifest.json").read_text())
archive = root / "raw-evidence.tar.xz"
assert archive.stat().st_size == manifest["archive_bytes"]
assert hashlib.sha256(archive.read_bytes()).hexdigest() == manifest["archive_sha256"]
seen = set()
with tarfile.open(archive, "r:xz") as tar:
    for entry in tar:
        assert entry.isfile() and entry.name not in seen
        seen.add(entry.name)
        data = tar.extractfile(entry).read()
        expected = manifest["raw_files"][entry.name]
        assert len(data) == expected["bytes"]
        assert hashlib.sha256(data).hexdigest() == expected["sha256"]
assert seen == set(manifest["raw_files"])
print(f"verified {len(seen)} complete raw files")
