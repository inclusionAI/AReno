"""Build bounded reviewer evidence only from complete, strictly audited final runs.

No Torch import, subprocess, training, index mutation or network access.
"""

from __future__ import annotations

import argparse
import hashlib
import io
import importlib.metadata
import platform
import re
import shlex
import json
import math
import statistics
import tarfile
import tempfile
from datetime import UTC, datetime
from pathlib import Path

GROUP = "final-sft512-1024"
METHODS = ("adamw", "adam8", "galore")
SOURCE = "142c7be2c33f871badad4105bd682d4e34da3d3c32e17278dba67324e45c21e1"
PROFILE = "sum-per-microbatch-time-max-per-microbatch-peaks-v1"
ENV_KEYS = {
    "CUDA_VISIBLE_DEVICES",
    "OMP_NUM_THREADS",
    "PYTHONPATH",
    "ARENO_BENCH_SEED",
    "CUBLAS_WORKSPACE_CONFIG",
    "PYTHONDONTWRITEBYTECODE",
}
REQUIRED_TRAIN = {
    "steps.jsonl",
    "curve.jsonl",
    "train.log",
    "launcher.log",
    "metadata.json",
    "summary.json",
    "encoding.json",
}
REQUIRED_EVAL = {"eval.log", "launcher.log", "metadata.json", "summary.json"}


class NotReady(ValueError):
    """Evidence is incomplete or fails a concrete audit."""


def require(ok, message):
    if not ok:
        raise NotReady(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def json_bytes(value):
    return (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()


def runtime_sha(repo):
    sha = hashlib.sha256()
    for path in sorted((repo / "areno").rglob("*.py")):
        sha.update(str(path.relative_to(repo)).encode())
        sha.update(path.read_bytes())
    return sha.hexdigest()


def accepted_rows(state):
    accepted = {}
    for attempt in state["attempts"]:
        if attempt["phase"] != "train":
            continue
        lo, hi = attempt["accepted_start_step"], attempt["accepted_end_step"]
        for line in (
            (Path(attempt["output_dir"]) / "steps.jsonl").read_text().splitlines()
        ):
            row = json.loads(line)
            step = row["step"]
            if lo <= step < hi:
                require(step not in accepted, f"overlapping accepted step{step}")
                row = dict(row, contaminated=attempt.get("contaminated", False))
                accepted[step] = row
    require(
        sorted(accepted) == list(range(1024)),
        "accepted cursor coverage must be exactly[0,1024)",
    )
    return [accepted[i] for i in range(1024)]


def profile(rows):
    clean = [
        r
        for r in rows
        if r["step"] >= 2 and not r.get("warmup") and not r["contaminated"]
    ]
    require(len(clean) == 1022, "all1022 post-warmup steps must be clean")
    keys = (
        "update_cuda_time_s",
        "update_peak_allocated_bytes",
        "update_peak_reserved_bytes",
        "update_optimizer_steps",
        "update_refresh_any",
        "score_plus_train_seconds",
        "target_tokens",
    )
    for row in clean:
        require(
            all(
                k in row and isinstance(row[k], (int, float)) and math.isfinite(row[k])
                for k in keys
            ),
            "missing/nonfinite actual per-update sum/max profile; legacy averaged native metrics are insufficient",
        )
        require(
            row["update_optimizer_steps"] == 1
            and row["update_cuda_time_s"] > 0
            and row["score_plus_train_seconds"] > 0,
            "invalid update/time contract",
        )
    result = {
        "warmup_updates_excluded": 2,
        "measured_updates": len(clean),
        "target_tokens_all": sum(r["target_tokens"] for r in rows),
    }
    for name, flag in (("normal", False), ("refresh", True)):
        subset = [r for r in clean if bool(r["update_refresh_any"]) == flag]
        result[f"{name}_updates"] = len(subset)
        result[f"{name}_seconds"] = (
            statistics.mean(r["update_cuda_time_s"] for r in subset) if subset else None
        )
        for field in ("allocated", "reserved"):
            result[f"{name}_{field}_gib"] = (
                max(r[f"update_peak_{field}_bytes"] for r in subset) / 2**30
                if subset
                else None
            )
    result["target_tokens_per_compute_second"] = sum(
        r["target_tokens"] for r in clean
    ) / sum(r["score_plus_train_seconds"] for r in clean)
    result["score_plus_train_seconds"] = sum(
        r["score_plus_train_seconds"] for r in clean
    )
    return result


def load_final(root):
    raw = {
        name: (root / name).read_bytes()
        for name in (
            "jobs.json",
            "status.json",
            "analysis.json",
            "launch-commands.json",
        )
    }
    jobs, status, analysis, launches = (json.loads(raw[n]) for n in raw)
    require(
        analysis["jobs_manifest_sha256"] == digest(raw["jobs.json"]),
        "analysis stale relative to jobs.json; rerun strict analyzer",
    )
    require(
        analysis["status_snapshot_sha256"] == digest(raw["status.json"]),
        "analysis stale relative to status.json; rerun strict analyzer",
    )
    analyzer = root.parent / "overnight_20261029/analyze.py"
    require(
        analysis["analyzer_sha256"] == digest(analyzer.read_bytes()),
        "strict analyzer source hash changed",
    )
    require(
        not analysis["input_errors"],
        f"strict analyzer input errors: {analysis['input_errors']}",
    )
    chosen = {j["id"]: j for j in jobs["jobs"] if j["group"] == GROUP}
    expected = {f"{GROUP}__{m}__s{s}" for m in METHODS for s in range(3)}
    require(
        set(chosen) == expected,
        "final group must contain exactly methods adamw/adam8/galore x seeds0/1/2",
    )
    audited = {j["id"]: j for j in analysis["jobs"] if j["group"] == GROUP}
    require(set(audited) == expected, "strict analysis does not cover all final jobs")
    group = next(g for g in analysis["groups"] if g["group"] == GROUP)
    conditions = {c["condition"]: c for c in group["conditions"]}
    require(set(conditions) == set(METHODS), "unexpected final conditions")
    for method in METHODS:
        c = conditions[method]
        require(
            c["paired_quality_eligible"] and c["all_three_seeds_complete"],
            f"{method}: three-seed pairing not yet eligible",
        )
        require(
            len(c["paired_audits"]) == 3
            and all(
                p["passed"] and p["compared_steps"] == 1024 for p in c["paired_audits"]
            ),
            f"{method}: exact1024-update paired audit failed",
        )
    entries = {
        (e["job_id"], e["attempt_index"], e["phase"]): e for e in launches["entries"]
    }
    trajectories, metadata, metrics = {}, {}, {}
    for job_id, job in chosen.items():
        state, row = status["jobs"][job_id], audited[job_id]
        require(
            state["status"] == "complete"
            and row["qualified_complete"]
            and not row["errors"],
            f"{job_id}: not qualified complete",
        )
        require(
            job["target_steps"] == 1024 and not job.get("resume_dependency"),
            f"{job_id}: wrong budget/lineage",
        )
        require(
            job["expected_source_sha256"]
            == SOURCE
            == row["source_sha256"]
            == state["resolved_source_sha256"],
            f"{job_id}: source contract mismatch",
        )
        require(
            row["test_examples"] == 743
            and row["test_target_tokens"] == 55562
            and row["validation_examples"] == 708
            and row["validation_target_tokens"] == 52181,
            f"{job_id}: evaluation counts changed",
        )
        meta = read(Path(state["train_summary_file"]).with_name("metadata.json"))
        require(
            meta["profiler_policy"] == PROFILE, f"{job_id}: wrong profile aggregation"
        )
        require(
            meta["source_sha256"] == SOURCE
            and meta["arguments"]["context"] == 512
            and meta["arguments"]["batch"] == 4
            and meta["arguments"]["micro_batch"] == 2,
            f"{job_id}: metadata contract mismatch",
        )
        if job["condition"] == "galore":
            require(
                meta["arguments"]["scale"] == 2
                and meta["arguments"]["rank"] == 128
                and meta["arguments"]["gap"] == 200
                and not meta["arguments"]["retained"]
                and json.loads(meta["arguments"]["extra_config_json"]) == {},
                "final GaLore must be registered scale2/rank128/gap200/transport/all-matrix",
            )
        for attempt in state["attempts"]:
            key = (job_id, attempt["index"], attempt["phase"])
            require(
                key in entries,
                f"{job_id}: missing captured actual command for attempt{attempt['index']}",
            )
            launch = entries[key]
            require(
                set(launch["environment"]) <= ENV_KEYS
                and launch["cwd"] == job["source_repo"]
                and attempt["output_dir"] in launch["command"],
                f"{job_id}: captured launch mismatch/nonwhitelisted environment",
            )
            required = REQUIRED_TRAIN if attempt["phase"] == "train" else REQUIRED_EVAL
            require(
                all((Path(attempt["output_dir"]) / f).is_file() for f in required),
                f"{job_id}: raw{attempt['phase']} artifacts missing",
            )
        trajectories[job_id] = accepted_rows(state)
        metadata[job_id] = meta
        metrics[job_id] = profile(trajectories[job_id])
        require(
            metrics[job_id]["target_tokens_all"]
            == row["metrics"]["target_tokens_accepted"],
            f"{job_id}: accepted target count mismatch",
        )
    for seed in range(3):
        base = trajectories[f"{GROUP}__adamw__s{seed}"]
        for method in METHODS:
            candidate = trajectories[f"{GROUP}__{method}__s{seed}"]
            require(
                all(
                    a["batch_sha256"] == b["batch_sha256"]
                    and a["target_tokens"] == b["target_tokens"]
                    for a, b in zip(base, candidate, strict=True)
                ),
                f"{method}/seed{seed}: exact paired batch/target audit failed",
            )
    for field in (
        "data_sha256",
        "wrapper_sha256",
        "encoding_policy",
        "order_policy",
        "native_extension_sha256",
    ):
        require(
            len({json.dumps(m[field], sort_keys=True) for m in metadata.values()}) == 1,
            f"{field}: final jobs differ",
        )
    repo = Path(next(iter(chosen.values()))["source_repo"])
    require(
        runtime_sha(repo) == SOURCE,
        "current runtime no longer equals final training source",
    )
    harness = Path(next(iter(chosen.values()))["harness_dir"])
    wrappers = next(iter(metadata.values()))["wrapper_sha256"]
    require(
        all(
            digest((harness / name).read_bytes()) == sha
            for name, sha in wrappers.items()
        ),
        "frozen GPU wrapper source changed",
    )
    measured = next(iter(metadata.values()))
    data_dir = Path(next(iter(chosen.values()))["data_dir"])
    require(
        all(
            digest((data_dir / f"{name}.jsonl").read_bytes()) == sha
            for name, sha in measured["data_sha256"].items()
        ),
        "actual data files changed",
    )
    extension = next((repo / "areno/accel").glob("_areno_accel*.so"))
    require(
        digest(extension.read_bytes()) == measured["native_extension_sha256"],
        "actual CUDA extension changed",
    )
    return dict(
        raw=raw,
        definition=jobs,
        states=status,
        analysis=analysis,
        jobs=chosen,
        rows=audited,
        group=group,
        metadata=metadata,
        metrics=metrics,
        repo=repo,
        harness=harness,
        analyzer=analyzer,
    )


class Bundle:
    def __init__(self):
        self.files = {}
        self.origins = {}

    def add(self, name, data, origin):
        require(name not in self.files, f"duplicate archive name:{name}")
        self.files[name] = data
        self.origins[name] = origin

    def file(self, name, path):
        path = Path(path)
        require(
            path.is_file() and not path.is_symlink(),
            f"raw evidence missing/symlink:{path}",
        )
        self.add(name, path.read_bytes(), str(path))

    def archive(self, path):
        # A solid xz stream retains duplicate logs without truncation or omission.
        with tarfile.open(path, "w:xz", preset=9) as tar:
            for name, data in sorted(self.files.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), 0o644, 0
                tar.addfile(info, io.BytesIO(data))
        return {
            name: {
                "sha256": digest(data),
                "bytes": len(data),
                "original_path": self.origins[name],
            }
            for name, data in sorted(self.files.items())
        }


def pack_sources(root, context, bundle):
    for name, data in context["raw"].items():
        bundle.add(f"queue/{name}", data, str(root / name))
    for name in ("train.py", "eval.py", "common.py"):
        bundle.file(f"frozen-harness/{name}", context["harness"] / name)
    bundle.file("audit/strict-analyzer.py", context["analyzer"])
    bundle.file("audit/evidence_writer.py", Path(__file__))
    bundle.file(
        "audit/evidence_verify.py", Path(__file__).with_name("evidence_verify.py")
    )
    for name in (
        "PLAN.md",
        "candidate-source-freeze.json",
        "final-registration.json",
        "same-source-controls-ready.json",
        "capture_launches.py",
        "guardian.py",
        "events.jsonl",
    ):
        if (root / name).is_file():
            bundle.file(f"queue/{name}", root / name)
    for job_id in sorted(context["jobs"]):
        for attempt in context["states"]["jobs"][job_id]["attempts"]:
            directory = Path(attempt["output_dir"])
            for path in sorted(directory.rglob("*")):
                if path.is_file():
                    require(
                        not any(s in path.name for s in ("safetensors", ".pt", ".pth")),
                        f"weight/checkpoint unexpectedly in output:{path}",
                    )
                    bundle.file(
                        f"runs/{job_id}/{attempt['phase']}-attempt-{attempt['index']}/{path.relative_to(directory)}",
                        path,
                    )
    for path in sorted((root / "performance").rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc":
            bundle.file(f"performance/{path.relative_to(root / 'performance')}", path)
    checks = root / "checks"
    for name in (
        "CANDIDATE_FINAL_CHECKS.json",
        "candidate-pr-full-cpu.log",
        "candidate-pr-offline-tests.log",
        "candidate-pr-offline-proof.json",
        "candidate-pr-ruff-final.log",
        "candidate-pr-format-final.log",
        "candidate-pr-hooks-final.json",
        "candidate-pr-final-source-manifest.json",
    ):
        bundle.file(f"checks/{name}", checks / name)
    # Acceptance is appended when finalized; no status is invented from partial files.
    for path in sorted((root / "acceptance").rglob("*")):
        relative = path.relative_to(root / "acceptance")
        if "prefix" in relative.parts or "__pycache__" in relative.parts:
            continue
        if path.is_file() and path.suffix in {
            ".json",
            ".jsonl",
            ".py",
            ".sh",
            ".log",
            ".md",
            ".txt",
            ".patch",
            ".diff",
        }:
            bundle.file(
                f"acceptance/{relative}",
                path,
            )
    data_root = Path(next(iter(context["jobs"].values()))["data_dir"]).parent
    for name in (
        "provenance.json",
        "DONE.json",
        "integrity.json",
        "PLAN.md",
        "prepare.py",
        "verify_data.py",
        "replay-comparison.json",
    ):
        bundle.file(f"data-provenance/{name}", data_root / name)
    # Historical summaries/metadata retain all screened outcomes, without claiming
    # that the full old trajectories are bundled alongside the complete final nine.
    historical = [r for r in context["analysis"]["jobs"] if r["group"] != GROUP]
    for row in historical:
        for phase in ("train", "eval"):
            summary = row.get(f"{phase}_summary_file")
            if summary and Path(summary).is_file():
                for name in ("summary.json", "metadata.json"):
                    path = Path(summary).with_name(name)
                    if path.is_file():
                        bundle.file(f"history/{row['id']}/{phase}/{name}", path)
    old = root.parent / "overnight_20261029/morning_supplement/analysis-reviewed.json"
    bundle.file("history/overnight-analysis-reviewed.json", old)
    # Hash model assets, bundle no weights/tokenizer/dataset payloads.
    model = Path(next(iter(context["metadata"].values()))["arguments"]["model"])
    pin = context["definition"]["model_pin"]
    require(
        (model / "model.safetensors").stat().st_size == pin["size"]
        and (model / "model.safetensors").stat().st_mtime_ns == pin["mtime_ns"],
        "model weight stat changed from pinned hash",
    )
    identities = {
        p.name: {"bytes": p.stat().st_size, "sha256": digest(p.read_bytes())}
        for p in sorted(model.iterdir())
        if p.is_file() and p.name != "model.safetensors"
    }
    identities["model.safetensors"] = {
        "bytes": pin["size"],
        "sha256": pin["sha256"],
        "verification": "previously pinned full hash; size and mtime rechecked now",
    }
    bundle.add(
        "provenance/model-files.json",
        json_bytes(identities),
        "derived from pinned model assets",
    )
    bundle.file("provenance/model-LICENSE", model / "LICENSE")
    software = {
        "python": platform.python_version(),
        "recorded_gpu_training": {
            k: next(iter(context["metadata"].values()))[k]
            for k in ("torch_version", "cuda_version", "gpu", "native_extension_sha256")
        },
        "writer_environment_versions": {},
    }
    for name in (
        "torch",
        "triton",
        "transformers",
        "tokenizers",
        "safetensors",
        "numpy",
        "datasets",
        "modelscope",
        "pytest",
    ):
        try:
            software["writer_environment_versions"][name] = importlib.metadata.version(
                name
            )
        except importlib.metadata.PackageNotFoundError:
            software["writer_environment_versions"][name] = None
    bundle.add(
        "provenance/software.json",
        json_bytes(software),
        "recorded train metadata and installed distribution metadata; no module imports",
    )
    return identities


def table(headers, rows):
    return (
        ".. csv-table::\n   :header: "
        + ", ".join(json.dumps(x) for x in headers)
        + "\n\n"
        + "\n".join("   " + ", ".join(json.dumps(str(x)) for x in row) for row in rows)
        + "\n"
    )


def fmt(x):
    return "n/a" if x is None else f"{x:.6f}"


def memory_appendix(root):
    path = root / "acceptance/real-memory/summary.json"
    if not path.exists():
        return ""
    measured = read(path)
    require(
        measured["status"] == "passed"
        and measured["primary_source_sha256"] == SOURCE
        and measured["staged_equals_unmodified_recycled_bitexact"]
        and measured["same_real_clipped_gradient_full_svd_completed"]
        and not measured["new_checkpoint_written"]
        and not measured["validation_or_test_evaluated"],
        "real-gradient memory probe contract differs",
    )
    require(
        measured["full_clipped_fp32_gradient_bytes"] == 2384199680
        and measured["gradient_identity"]["bytes"] == 622329856
        and measured["entry"]["main_grad_unique_bytes"] == 2384199680
        and measured["exit"]["main_grad_unique_bytes"] == 0,
        "real-gradient lifecycle accounting differs",
    )
    lines = []
    for label, key in [
        ("Recycled, unmodified helper", "recycled.unmodified_end_to_end"),
        ("Full reduced SVD, same gradient", "exact_SVD.decompose_same_real_gradient"),
    ]:
        stage = measured["stages"][key]
        lines.append(
            f'   "{label}", "{stage["peak_increase_over_entry_bytes"]}", '
            f'"{stage["peak_increase_over_entry_bytes"] / 2**20:.3f}", '
            f'"{stage["transient_above_entry_exit_lower_bound_bytes"] / 2**20:.3f}"'
        )
    return """Full gradients and decomposition footprint
------------------------------------------

A separate instrumented probe restores the actual selected seed0 checkpoint
at1,024 completed updates with the final runtime. Its tiny repository-text
probe uses context64/batch2, rather than the Dolly quality batch. It makes one
in-memory update, saves no checkpoint and performs no validation/test evaluation.
Its intentional peak resets invalidate ordinary timing; it is not another
quality replicate or the primary whole-model performance measurement.

Observed full FP32 gradients are2,384,199,680 bytes and remain live through
global clipping. They fall to zero after optimizer consumers finish. Unique
model storage is1,192,230,912 bytes; optimizer GPU buffers at entry are
1,922,482,176 bytes, with an additional4-byte writeback flag at exit. CPU
private-projector RNG is571,328 bytes, separately counted; no optimizer CPU
offload is used. These are actual storage inventories, not a replacement for
the allocated/reserved peak measurements above.

On the same real clipped151936-by-1024 FP32 vocabulary gradient
(622,329,856 bytes), the staged recycled sequence matches the unmodified helper
bit for bit. The allocator-visible decomposition measurements are:

.. csv-table::
   :header: "Operation", "Entry-to-peak bytes", "Entry-to-peak MiB", "Transient above entry/exit lower bound MiB"

""" + "\n".join(lines) + """

These include returned outputs and intermediate allocations; they are not
exclusive internal cuSolver workspace sizes. The large QR, final R-only QR
and small Ritz-SVD stage increases are158.472/84.862/0.692MiB. Sampled NVML
stage endpoints are lower bounds and cannot isolate external solver memory.
Raw stage records, original probe/helper code and the actual-import source
manifest are bundled. The old instrumentation's legacy metadata source digest
points to its historical tree; the independent launch manifest verifies the
actual imported final runtime and preserves this distinction explicitly.

For the required1024-by-1024 FP32/rank128 state check, the independent audit
measures1,572,864 bytes of moments plus basis and5,056 bytes of CPU private
RNG, totaling1,577,920 state bytes versus8,388,608 bytes for two FP32 AdamW
moments. Masters, full gradients, model storage and decomposition transients
are reported separately; compressed optimizer state is not total-memory saving.

"""


def report(context, manifest):
    rows, metrics, group = context["rows"], context["metrics"], context["group"]
    cond = {c["condition"]: c for c in group["conditions"]}
    losses = [
        [
            m,
            s,
            fmt(rows[f"{GROUP}__{m}__s{s}"]["validation_loss"]),
            fmt(rows[f"{GROUP}__{m}__s{s}"]["test_loss"]),
        ]
        for m in METHODS
        for s in range(3)
    ]
    aggregate, performance = [], []
    for method in METHODS:
        c = cond[method]
        aggregate.append(
            [
                method,
                fmt(c["validation_loss_mean"]),
                fmt(c["validation_loss_sample_std"]),
                fmt(c["validation_relative_change_percent"]),
                fmt(c["test_loss_mean"]),
                str(c["quality_gate_pass"]),
            ]
        )
        for seed in range(3):
            p = metrics[f"{GROUP}__{method}__s{seed}"]
            performance.append(
                [
                    method,
                    seed,
                    fmt(p["normal_seconds"]),
                    fmt(p["refresh_seconds"]),
                    fmt(p["normal_allocated_gib"]),
                    fmt(p["refresh_allocated_gib"]),
                    fmt(p["normal_reserved_gib"]),
                    fmt(p["refresh_reserved_gib"]),
                    fmt(p["target_tokens_per_compute_second"]),
                    p["target_tokens_all"],
                ]
            )
    meta = next(iter(context["metadata"].values()))
    suite = context["post_oracle_suite"]
    clean = context["clean_performance"]
    clean_rows = []
    for method in METHODS:
        summary = clean["methods"][method]["summary"]
        for category in ("all", "normal", "refresh"):
            c = summary[category]
            if c["updates"]:
                clean_rows.append(
                    [
                        method,
                        category,
                        c["updates"],
                        fmt(c["score_plus_train_s"]["mean"] * 1000),
                        fmt(c["cuda_time_s"]["mean"] * 1000),
                        fmt(c["allocated_peak_bytes"] / 2**30),
                        fmt(c["reserved_peak_bytes"] / 2**30),
                        fmt(c["target_tokens_per_wall_second"]),
                    ]
                )
    contrasts = clean["galore_comparisons"]
    return f"""Qwen3-0.6B GaLore SFT evidence
=============================

This report describes one exploratory selected configuration on one fixed Dolly
split and budget. It does not establish a general algorithm advantage. Endpoint
quality is independently evaluated after 1,024 optimizer updates; test results
are secondary descriptive endpoints and were not used to choose the configuration.
All nine final runs use the same runtime source and frozen GPU harness, with seeds
0, 1 and 2 paired by every batch hash and response target count.

Configuration and provenance
----------------------------

Model: Qwen3-0.6B, ModelScope revision
09b42cad3d112e832108974449ccb5e8e0f5b5d1, tied 596,049,920 parameters,
BF16 with FP32 norms. Dataset:
ModelScope AI-ModelScope/databricks-dolly-15k, revision
40789acc12fc986e9145f87d159f19e2f1d75c6a, CC-BY-SA-3.0. Exact normalized
context/instruction-proxy groups are disjoint after exact deduplication;
this does not guarantee article, near-duplicate or pretraining-data separation.
Splits contain 13,544 training, 708 validation and 743 test examples.
Context512 uses response-preserving head/tail prompt truncation.
Final validation/test respectively score 52,181/55,562 response tokens.
Batch4, microbatch2; constant lr1e-5, betas(0.9,0.95), decay0.01, clip1.
GaLore: all eligible matrices, rank128, gap200, scale2, recycled projector with
oversampling16/one iteration/finalQR, exact compact masters, tiled fused
writeback, consumed-gradient release and experimental coordinate-moment transport.
Vocabulary exclusion is false for these final runs. All original weights train.
8-bit AdamW uses the existing repository implementation, not bitsandbytes.

Runtime SHA256: ``{SOURCE}``.
PyTorch ``{meta["torch_version"]}``, CUDA ``{meta["cuda_version"]}``, device
``{meta["gpu"]}``; source/extension/model/data/wrapper hashes and actual command
vectors with whitelisted launch settings are in the evidence archive. The model
weight hash is ``{context["definition"]["model_pin"]["sha256"]}``.
The raw frozen harness scripts retain original local default paths as evidence;
use ``../../scripts/galore_sft/README.md`` for the portable entry. The portable
entry has CPU mathematical AST and byte-for-byte data equivalence, but these
formal GPU runs used the external frozen scripts bundled here.

Final endpoint results
----------------------

{table(["Method", "Seed", "Validation NLL", "Test NLL"], losses)}
{table(["Method", "Validation mean", "Sample SD", "Relative mean vs AdamW (%)", "Test mean", "Quality gate <=2%"], aggregate)}
Relative mean is100*(method mean/AdamW mean-1), not a mean of seedwise ratios.
Three seeds are individual replicates; no ensemble or statistical significance
claim is made. Full-fold evaluation is token weighted, with the same counts for
all methods. The128-example inline monitor is descriptive and never an endpoint
selector; the final budget was fixed before the final group ran.

.. figure:: galore-sft-figures/quality_memory.svg
   :alt: Three-seed endpoint losses and allocator peaks for the nine final runs

   Dots are individual seeds and horizontal lines are means. Memory bars use
   the full three-seed runs; the separate same-card probe is tabulated below.

.. figure:: galore-sft-figures/learning_curves.svg
   :alt: Fixed validation-monitor curves and reported training batch losses

   Shading is the seed range, not a confidence interval. Monitor and training
   batch-loss curves are descriptive and do not replace full-fold endpoints.

Training performance
--------------------

The primary comparison uses three fresh sequential processes on the same physical
GPU1, UUID ``{clean["gpu_uuid"]}``, with no foreign PID observed in the sampled
NVML audit. Each method runs402 updates, excluding2 warm-up updates;400 measured
batches, targets and the first forward loss are identical. GaLore includes the
two actual refreshes at steps200/400. No checkpoint, validation or test is read
or saved in this probe. This is a single-seed timing measurement, not an extra
quality replicate or a repeated-timing confidence interval.

{table(["Method", "Category", "Updates", "Score+train ms/update", "Synchronized train ms/update", "Allocated peak GiB", "Reserved peak GiB", "Target tokens/s incl scoring"], clean_rows)}
The timer is synchronized ``perf_counter`` around the training segment, using
``cuda.synchronize``; the legacy field name ``cuda_time_s`` does not mean CUDA
Events or kernel-only timing. Wall time also includes actor scoring and the
public training call, excluding batch preparation, logging and model init.
NVML one-second process-memory samples are lower bounds; allocator allocated
and reserved values above are distinct from those samples.

GaLore allocated-peak reduction is
{100 * contrasts["adamw"]["allocated_reduction_fraction"]:.3f}% vs AdamW and
{100 * contrasts["adam8"]["allocated_reduction_fraction"]:.3f}% vs8-bit. Scoring-plus-
training step time changes by
{100 * (contrasts["adamw"]["wall_time_ratio"] - 1):+.3f}% and
{100 * (contrasts["adam8"]["wall_time_ratio"] - 1):+.3f}%, respectively; corresponding
throughput changes are
{100 * (contrasts["adamw"]["wall_throughput_ratio"] - 1):+.3f}% and
{100 * (contrasts["adam8"]["wall_throughput_ratio"] - 1):+.3f}%. A step-time increase
is not the same percentage as a throughput decrease. The entire node was not
exclusive: other GPUs ran independent jobs.

The formal three-seed runs on their assigned GPUs are retained below as a
secondary timing/memory appendix; they remain the quality endpoints above.

{table(["Method", "Seed", "Normal s/update", "Refresh s/update", "Normal allocated GiB", "Refresh allocated GiB", "Normal reserved GiB", "Refresh reserved GiB", "Target tokens/s incl scoring", "All training target tokens"], performance)}
The first two optimizer updates are excluded. Time sums all microbatch timings
per optimizer update; memory takes their maximum. Table times are arithmetic
means of normal/refresh update times; allocator columns are maxima within that
category. Throughput divides measured response targets by scoring-plus-training
wall time, including the native scorer, excluding monitor, checkpoint and final
evaluation I/O. Reserved memory is the allocator reservation, not live allocation.
Normal/refresh are distinguished using the actual per-update refresh flag.
Warm-up and contaminated steps are never silently added. Concurrent GPU jobs can
still affect shared CPU/host behavior; the clean same-card probe above is the
primary performance result, distinct from these full-budget quality runs.

{context.get("memory_appendix", "")}
Exploratory history and limits
------------------------------

The old all-matrix scale4 configuration failed the <=2% mean validation target:
+2.977129% at1,024 updates and +4.350% at4,096. Exact-vocabulary fallback at scale4
passed narrowly at +1.949812% at1,024, with a different memory tradeoff. Separate
seed0 development screens tested scale2, retained moments and rank256. Scale2
was selected after observing its training behavior and full validation
(2.206458 vs the old matched AdamW seed0's2.224296). This is exploratory validation
selection, not untouched-validation discovery. The final fixed scale2 group
reran all three seeds and all controls on the final source; seed0 is not an
additional independent development sample. Historical summaries/metadata and
the original audited reports are retained; they are not relabeled final passes.
No test endpoint was used to choose scale2. Native CUDA BF16 backward includes
existing nondeterministic operations: exact checkpoint restoration is not a
promise of bitwise identical full training trajectories. Strict small FP32
reference/resume tests use their original tolerances. Scope remains single-GPU
dense training; wider models, datasets, budgets and distributed execution have
not been established by this result.

Review and local checks
-----------------------

The post-oracle final-tree ordinary ``pytest tests/ -k cpu`` selection passed
{suite["passed"]} tests and{suite["subtests_passed"]} subtests, with
{suite["skipped"]} skips and{suite["deselected"]} deselected. This final-tree
result supersedes the earlier check snapshot, which remains bundled unchanged. Independent offline
reproduction passed18 overlapping tests with CUDA hidden, reproducing nine
files byte for byte. Whole-repo pinned Ruff0.15.17 lint/format and changed-file
whitespace/security/size hooks passed. This is local Python3.12 Linux/CUDA-host
evidence, not the full published GitHub CI matrix or every GPU test. Numerical
and public-Trainer resume artifacts are included as actually recorded; a partial
or failed probe is not converted to a pass by this report. The independent final
acceptance covers six CPU and six CUDA numerical cases and actual four-update
prefix/two-update public-Trainer continuation with immediate full-state equality.
The old auxiliary assertion equating a direct-B-SVD basis with the registered
QR(R.T)-SVD coordinates failed at6.616e-6 and is retained with its raw log. The
reviewed tests-only correction removes that different-factorization assumption;
production-versus-same-rule parameter, basis and moment comparisons retain all
original tolerances. The post-oracle whole-suite result is bundled separately.

The adjacent ``galore-sft-evidence/manifest.json`` lists every original raw file's
SHA256, byte length and archived path. ``raw-evidence.tar.xz`` contains complete
final-run attempts, including steps, curves, summaries, metadata, train/eval and
launcher logs, and event files; no training trajectory was truncated. It also
contains exact registered configuration, captured commands, audit implementation,
frozen wrappers, local checks and available independent acceptance artifacts.
Historical runs retain summary/metadata and audit snapshots, not their complete
old trajectories. Weights, checkpoints and the full Dolly corpus are excluded.
The archive is {manifest["archive_bytes"]:,} bytes; the5MB target is
{"met" if manifest["archive_bytes"] < 5_000_000 else "exceeded to preserve complete original evidence"}.

Extract with ``tar -xJf raw-evidence.tar.xz``. Verify each raw file against the
manifest, or use the bundled verifier. Paths in original configs are provenance,
not the sole means of accessing the bundled evidence. No full process environment
was captured. The manifest records snapshot hashes, complete pairing audits and
all numerical table values; local source paths need not exist to read the evidence.
"""


def clean_performance(root):
    directory = root / "performance"
    result = read(directory / "summary.json")
    require(
        result["status"] == "complete" and result["source_sha256"] == SOURCE,
        "clean performance incomplete/source changed",
    )
    require(
        result["measured_updates_per_method"] == 400
        and result["warmup_updates_per_method"] == 2
        and result["all_batches_targets_identical"]
        and result["initial_forward_loss_identical"]
        and result["native_logp_abs_diff_max"] == 0
        and not result["saved_checkpoints"]
        and not result["read_validation_or_test"],
        "clean performance protocol failed",
    )
    require(set(result["methods"]) == set(METHODS), "clean performance methods differ")
    trajectories = {}
    for method, evidence in result["methods"].items():
        folder = directory / "outputs" / method
        require(
            digest((folder / "steps.jsonl").read_bytes())
            == evidence["raw_steps_sha256"]
            and digest((folder / "nvml-audit.jsonl").read_bytes())
            == evidence["nvml_audit_sha256"],
            "clean performance raw hashes changed",
        )
        meta = evidence["metadata"]
        require(
            meta["source_sha256"] == SOURCE
            and meta["cuda_visible_devices"] == str(result["gpu"])
            and not evidence["foreign_pid_observed"],
            "clean performance source/GPU/contamination mismatch",
        )
        require(
            all(
                digest((directory / name).read_bytes()) == sha
                for name, sha in meta["wrapper_sha256"].items()
            ),
            "clean performance wrapper changed",
        )
        nvml = [
            json.loads(line)
            for line in (folder / "nvml-audit.jsonl").read_text().splitlines()
        ]
        require(
            nvml
            and all(
                not row["foreign_pids"] and row["uuid"] == result["gpu_uuid"]
                for row in nvml
            ),
            "foreign process or GPU UUID mismatch in clean profile",
        )
        points = [
            json.loads(line)
            for line in (folder / "steps.jsonl").read_text().splitlines()
        ]
        require(
            [p["step"] for p in points] == list(range(402))
            and [p["step"] for p in points if p["warmup"]] == [0, 1],
            "clean performance cursor/warmup mismatch",
        )
        trajectories[method] = points
        measured = points[2:]
        require(
            all(
                p["update_optimizer_steps"] == 1 and p["logp_abs_diff_mean"] == 0
                for p in measured
            ),
            "clean performance update/native loss contract failed",
        )
        summary = evidence["summary"]
        require(
            summary["completed_updates"] == 402
            and not summary["saved_checkpoints"]
            and not summary["read_validation_or_test"],
            "clean performance budget/IO differs",
        )
        for category, rows in (
            ("all", measured),
            ("normal", [p for p in measured if not p["update_refresh_any"]]),
            ("refresh", [p for p in measured if p["update_refresh_any"]]),
        ):
            recorded = summary[category]
            require(
                recorded["updates"] == len(rows)
                and recorded["target_tokens"] == sum(p["target_tokens"] for p in rows),
                "clean performance summary counts differ from raw",
            )
            if rows:
                for field, key in (
                    ("score_plus_train_seconds", "score_plus_train_wall_seconds"),
                    ("update_cuda_time_s", "cuda_seconds"),
                ):
                    require(
                        math.isclose(
                            sum(p[field] for p in rows), recorded[key], rel_tol=1e-12
                        ),
                        "clean performance sum profile differs from raw",
                    )
                require(
                    math.isclose(
                        recorded["score_plus_train_s"]["mean"],
                        sum(p["score_plus_train_seconds"] for p in rows) / len(rows),
                        rel_tol=1e-12,
                    ),
                    "clean wall-time mean differs from raw",
                )
                require(
                    math.isclose(
                        recorded["cuda_time_s"]["mean"],
                        sum(p["update_cuda_time_s"] for p in rows) / len(rows),
                        rel_tol=1e-12,
                    ),
                    "clean training-time mean differs from raw",
                )
                require(
                    math.isclose(
                        recorded["target_tokens_per_wall_second"],
                        sum(p["target_tokens"] for p in rows)
                        / sum(p["score_plus_train_seconds"] for p in rows),
                        rel_tol=1e-12,
                    ),
                    "clean throughput differs from raw",
                )
                for field in ("allocated", "reserved"):
                    require(
                        recorded[f"{field}_peak_bytes"]
                        == max(p[f"update_peak_{field}_bytes"] for p in rows),
                        "clean performance peak aggregation differs from raw",
                    )
        require(
            summary["refresh_steps"] == ([200, 400] if method == "galore" else []),
            "clean measured refresh schedule mismatch",
        )
    base = trajectories["adamw"]
    for method, points in trajectories.items():
        require(
            points[0]["loss"] == base[0]["loss"]
            and all(
                a["batch_sha256"] == b["batch_sha256"]
                and a["target_tokens"] == b["target_tokens"]
                for a, b in zip(base, points, strict=True)
            ),
            f"clean performance paired batches/targets/initial loss differ:{method}",
        )
    galore = result["methods"]["galore"]["summary"]["all"]
    for control in ("adamw", "adam8"):
        base = result["methods"][control]["summary"]["all"]
        calculated = {
            "allocated_reduction_fraction": 1
            - galore["allocated_peak_bytes"] / base["allocated_peak_bytes"],
            "reserved_reduction_fraction": 1
            - galore["reserved_peak_bytes"] / base["reserved_peak_bytes"],
            "wall_time_ratio": galore["score_plus_train_s"]["mean"]
            / base["score_plus_train_s"]["mean"],
            "wall_throughput_ratio": galore["target_tokens_per_wall_second"]
            / base["target_tokens_per_wall_second"],
        }
        require(
            all(
                math.isclose(
                    value, result["galore_comparisons"][control][key], rel_tol=1e-12
                )
                for key, value in calculated.items()
            ),
            "clean memory/time/throughput comparison ratios differ",
        )
    return result


def independent_acceptance(root):
    directory = root / "acceptance/scale2"
    summary, done = read(directory / "summary.json"), read(directory / "done.json")
    expected_status = "numerical_and_public_trainer_acceptance_passed_quality_separate"
    require(
        summary["status"] == expected_status == done["status"],
        "independent scale2 acceptance incomplete",
    )
    require(
        summary["runtime_repo_sha256"] == done["runtime_repo_sha256"] == SOURCE,
        "independent acceptance source mismatch",
    )
    require(
        summary["independent_cases_cpu"] == summary["independent_cases_cuda"] == 6
        and summary["criterion"] == {"atol": 1e-6, "rtol": 1e-4},
        "independent reference counts/tolerances changed",
    )
    require(
        summary["byte_proof"]["criterion_pass"],
        "independent persistent-byte proof failed",
    )
    trainer = summary["public_trainer"]
    require(
        trainer["status"] == "passed"
        and trainer["complete_immediate_state"]["exact_match"]
        and trainer["next_batch_exact"]
        and trainer["probe_exact"]
        and trainer["prefix_completed_updates"] == 4
        and trainer["continuation_updates"] == [4, 5]
        and trainer["actual_refreshed_update4"],
        "public Trainer state/prefix/resume proof incomplete",
    )
    for name, sha in summary["files"].items():
        require(
            digest((directory / name).read_bytes()) == sha,
            f"independent acceptance file changed:{name}",
        )
    correction = summary["test_oracle_correction"]
    require(
        digest((directory / correction["patch"]).read_bytes())
        == correction["patch_sha256"],
        "oracle correction patch hash changed",
    )
    require(
        bool(summary["earlier_attempts"])
        and all((directory / a["log"]).is_file() for a in summary["earlier_attempts"]),
        "earlier auxiliary failure evidence missing",
    )
    return summary


def post_suite(root):
    """Require the actual post-oracle final-tree suite, retaining prior evidence."""
    path = root / "acceptance/post-oracle-full-suite.json"
    result = read(path)
    require(
        result["status"] == "passed" and result["exit_code"] == 0,
        "post-oracle final-tree suite has not passed",
    )
    require(
        result["runtime_source_sha256"] == SOURCE,
        "post-oracle suite runtime source mismatch",
    )
    require(
        result["passed"] >= 1805
        and result["skipped"] <= 28
        and result["subtests_passed"] == 12
        and result["deselected"] == 2222,
        "post-oracle suite selection/counts differ",
    )
    command = (
        shlex.split(result["command"])
        if isinstance(result["command"], str)
        else result["command"]
    )
    require(
        "-k" in command
        and command[command.index("-k") + 1] == "cpu"
        and any(c in ("tests", "tests/") for c in command),
        "post-oracle suite command is not ordinary tests/ -k cpu",
    )
    allowed = ENV_KEYS | {
        "ARENO_CHECK_TOKEN_IDS",
        "PYTEST_DISABLE_PLUGIN_AUTOLOAD",
        "TOKENIZERS_PARALLELISM",
        "RAYON_NUM_THREADS",
        "CUDA_MODULE_LOADING",
    }
    require(
        set(result["environment"]) <= allowed,
        "post-oracle suite environment is not whitelisted",
    )
    log = Path(result["log_file"])
    if not log.is_absolute():
        log = root / log
    require(
        log.resolve().is_relative_to((root / "acceptance").resolve()),
        "post-oracle log must live within acceptance",
    )
    text = log.read_text()
    for field, label in (
        ("passed", "passed"),
        ("skipped", "skipped"),
        ("subtests_passed", "subtests passed"),
        ("deselected", "deselected"),
    ):
        require(
            re.search(rf"(?<![0-9]){result[field]} {label}\b", text),
            f"post-oracle log lacks recorded{field} count",
        )
    return result


def pr_draft(context):
    conditions = {c["condition"]: c for c in context["group"]["conditions"]}
    lines = [
        "Title: feat(optim): add resumable GaLore AdamW for single-GPU dense training",
        "",
        "This adds an opt-in GaLore AdamW path for eligible dense matrices, with ordinary AdamW fallback for other parameters and public-Trainer checkpoints that preserve masters, bases, moments, configuration, counters and RNG across projector refreshes. The selected measured configuration is rank128/gap200/scale2 with the recycled projector, exact compact masters, tiled fused writeback, consumed-gradient release and experimental coordinate-moment transport. All original weights remain trainable. Optional vocabulary fallback has its own versioned target-identity checkpoint contract; it is false in these final measurements.",
        "",
        "Common Qwen3 tied-owner/export corrections apply identically to all controls; their savings are not credited to GaLore. Finite scalar/checkpoint validation and repairs to existing topology/mock/variance-owner tests are separate reviewable changes with numerical tolerances preserved.",
        "",
        "Final Qwen3-0.6B / Dolly results use the same frozen runtime142c7be2… and GPU harness, context512, batch4/micro2, fixed1024 updates, seeds0/1/2. Every paired batch hash and target count passes the strict audit. Full validation/test score52181/55562 response tokens on708/743 examples.",
        "",
        "| Method | Validation mean | Relative vs AdamW | Test mean | Training allocated peak GiB | Training reserved peak GiB | Target tokens/s incl scoring |",
        "| --- | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    for method in METHODS:
        c = conditions[method]
        clean = context["clean_performance"]["methods"][method]["summary"]["all"]
        allocated = clean["allocated_peak_bytes"] / 2**30
        reserved = clean["reserved_peak_bytes"] / 2**30
        throughput = clean["target_tokens_per_wall_second"]
        lines.append(
            f"| {method} | {c['validation_loss_mean']:.6f} | {c['validation_relative_change_percent']:+.3f}% | {c['test_loss_mean']:.6f} | {allocated:.3f} | {reserved:.3f} | {throughput:.1f} |"
        )
    passed = conditions["galore"]["quality_gate_pass"]
    lines.extend(
        [
            "",
            f"The preregistered <=2% three-seed mean-validation gate {'passes' if passed else 'FAILS; keep this as a draft'}. Performance columns use the primary same-physical-GPU1 training-only probe:402 updates per method, two excluded warm-up updates, identical batches/targets and no foreign PID observed. Allocator columns are the maximum training peaks; throughput includes scoring and training. This one-seed timing probe is not an extra quality replicate. The report retains per-seed normal/refresh timing and allocator values. Checkpoint/monitor/evaluation I/O is excluded from those compute metrics.",
            "",
            "Scale2 was chosen exploratorily after seed0 training and validation screens; this is not untouched-validation model selection. Old scale4 all-matrix failures (+2.977% at1024 and+4.350% at4096), exact-vocabulary scale4's narrow+1.950% result, and every screened outcome remain evidence. The final fixed scale2 group includes fresh same-source controls; test endpoints were not used to choose it. One model/corpus/budget does not establish general optimizer superiority, and native BF16 CUDA trajectories are not promised bitwise reproducible.",
            "",
            "Validation: ordinary local `pytest tests/ -k cpu`1805 passed/28 skipped/12 subtests,2222 deselected; independent18-case offline replay reproduces nine files byte for byte (overlapping counts). Pinned Ruff0.15.17 whole-repo lint/format and changed-file whitespace/private-key/size hooks pass. This is local Python3.12 Linux/CUDA-host evidence, not every CI matrix target or every CUDA test. The bundled independent reference/byte-accounting/public-Trainer acceptance artifacts retain their actual statuses and original tolerances.",
            "",
            "See `docs/reports/galore-sft-qwen3.rst` and `docs/reports/galore-sft-evidence/` for per-seed endpoints, registered configuration, actual commands, frozen wrapper source, complete final raw logs/trajectories, hashes and independent checks. `scripts/galore_sft/` is the portable entry with verified CPU mathematical/data equivalence; the formal GPU runs used the bundled frozen external wrappers. No remote commit, push or PR has been created.",
        ]
    )
    return "\n".join(lines) + "\n"


def generate(root, *, write=False):
    context = load_final(root)
    context["memory_appendix"] = memory_appendix(root)
    context["post_oracle_suite"] = post_suite(root)
    context["independent_acceptance"] = independent_acceptance(root)
    context["clean_performance"] = clean_performance(root)
    formal = next(iter(context["metadata"].values()))
    for method in METHODS:
        meta = context["clean_performance"]["methods"][method]["metadata"]
        require(
            meta["native_extension_sha256"] == formal["native_extension_sha256"]
            and meta["data_sha256"]["train"] == formal["data_sha256"]["train"]
            and all(
                meta["arguments"][k] == formal["arguments"][k]
                for k in ("model", "context", "batch", "micro_batch")
            ),
            "clean-performance model/data/extension/context differs from formal quality group",
        )
    manifest = read(root / "performance/RUN_MANIFEST.json")
    require(
        manifest["base_model_sha256"] == context["definition"]["model_pin"]["sha256"],
        "clean-performance pinned base-model hash differs",
    )
    if not write:
        return {
            "status": "ready",
            "group": GROUP,
            "jobs": 9,
            "quality_gate_pass": next(
                c["quality_gate_pass"]
                for c in context["group"]["conditions"]
                if c["condition"] == "galore"
            ),
            "written": False,
        }
    bundle = Bundle()
    model = pack_sources(root, context, bundle)
    evidence = context["repo"] / "docs/reports/galore-sft-evidence"
    report_path = evidence.parent / "galore-sft-qwen3.rst"
    evidence.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="evidence-build-", dir=root) as temporary:
        archive = Path(temporary) / "raw-evidence.tar.xz"
        files = bundle.archive(archive)
        manifest = {
            "schema": "areno-galore-review-evidence-v1",
            "generated_at": datetime.now(UTC).isoformat(),
            "group": GROUP,
            "runtime_source_sha256": SOURCE,
            "snapshots": {k: digest(v) for k, v in context["raw"].items()},
            "archive_sha256": digest(archive.read_bytes()),
            "archive_bytes": archive.stat().st_size,
            "raw_bytes": sum(f["bytes"] for f in files.values()),
            "raw_files": files,
            "groups": context["group"],
            "jobs": list(context["rows"].values()),
            "per_update_metrics": context["metrics"],
            "model_files": model,
            "omissions": [
                "weights/checkpoints",
                "full Dolly corpus",
                "historical full trajectories; historical summaries/metadata/audits are included",
            ],
            "clean_performance": context["clean_performance"],
            "post_oracle_suite": context["post_oracle_suite"],
            "independent_acceptance": context["independent_acceptance"],
            "acceptance_snapshot": "source/hash-checked independent reference/bytes/public-Trainer acceptance plus actual post-oracle full suite; earlier failed auxiliary assertion retained",
        }
        outputs = {
            "manifest.json": json_bytes(manifest),
            "README.md": b"# Raw GaLore SFT evidence\n\nExtract `raw-evidence.tar.xz` with `tar -xJf`. All final attempts, including full logs/event files, are present. `manifest.json` records original SHA256/lengths and snapshot identities. Run `python verify.py` to verify the compressed archive and every entry without extracting. Model weights, checkpoints and the full dataset are omitted. Frozen original wrappers are provenance, not the portable entry point.\n",
            "verify.py": VERIFY.encode(),
        }
        for name, data in outputs.items():
            path = evidence / name
            temp = path.with_suffix(path.suffix + ".next")
            temp.write_bytes(data)
            temp.replace(path)
        archive.replace(evidence / archive.name)
        report_tmp = report_path.with_suffix(".rst.next")
        report_tmp.write_text(report(context, manifest))
        report_tmp.replace(report_path)
        draft = root / "checks/PR_DRAFT.md"
        if draft.exists():
            previous = draft.with_name("PR_DRAFT.pre-final-evidence.md")
            if not previous.exists():
                previous.write_bytes(draft.read_bytes())
        draft.write_text(pr_draft(context))
    return {
        "status": "written",
        "report": str(report_path),
        "evidence": str(evidence),
        "archive_bytes": manifest["archive_bytes"],
        "raw_files": len(files),
        "quality_gate_pass": next(
            c["quality_gate_pass"]
            for c in context["group"]["conditions"]
            if c["condition"] == "galore"
        ),
    }


VERIFY = Path(__file__).with_name("evidence_verify.py").read_text()


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument(
        "--write",
        action="store_true",
        help="write report/evidence only after all readiness audits pass",
    )
    args = parser.parse_args()
    try:
        result = generate(args.root, write=args.write)
    except (
        NotReady,
        OSError,
        KeyError,
        StopIteration,
        TypeError,
        json.JSONDecodeError,
    ) as error:
        print(
            json.dumps({"status": "not_ready", "reason": str(error), "written": False}),
            flush=True,
        )
        raise SystemExit(2) from None
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
