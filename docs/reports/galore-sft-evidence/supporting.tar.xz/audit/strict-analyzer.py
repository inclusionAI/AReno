"""Read-only overnight evidence audit and atomic morning report (stdlib only)."""

from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import io
import json
import math
import statistics
import tempfile
from collections import Counter, defaultdict
from datetime import UTC, datetime
from functools import lru_cache
from pathlib import Path
from zoneinfo import ZoneInfo

VERIFIED_WRAPPERS = (
    {
        "train.py": "d885e4ad4cb69ea5e378e1d616e466666332f3f64b8f3bbf5140f751666d5384",
        "eval.py": "20d6a7719980dd6db92bf9a19a2535a50c2998beb01a81172cb7a2ed02f4900d",
        "common.py": "3248d7a542c8358ce7c78a5c6e264cde44cca136ec3e2238a41ad3824b21e424",
    },
    {
        "train.py": "93cf64d6a6a3edd9cca3fc1e0752f298f482ba5539090de9d37415d393c07e4b",
        "eval.py": "20d6a7719980dd6db92bf9a19a2535a50c2998beb01a81172cb7a2ed02f4900d",
        "common.py": "3248d7a542c8358ce7c78a5c6e264cde44cca136ec3e2238a41ad3824b21e424",
    },
)
WRAPPER_EQUIVALENCE_NOTE = "verified frozen harness_v1/v2 equivalence: only final redundant recovery save skipped; training/quality and per-update profiles equal, checkpoint-I/O wall time not equivalent"


@lru_cache(maxsize=1)
def wrapper_version_evidence():
    """Whitelist two exact byte versions, then prove the sole AST change."""
    base = Path(__file__).resolve().parent
    try:
        trees = []
        for version, expected in zip(("harness_v1", "harness_v2"), VERIFIED_WRAPPERS, strict=True):
            directory = base / version
            for name, digest in expected.items():
                if hashlib.sha256((directory / name).read_bytes()).hexdigest() != digest:
                    return False
            if (
                hashlib.sha256((directory / "test_harness.py").read_bytes()).hexdigest()
                != "ecb2842f6c53cd0145d6cde2d26729472caf2f99998944d5b159e17be91b9939"
            ):
                return False
            trees.append(ast.parse((directory / "train.py").read_text()))
        old = ast.parse("args.checkpoint_every and (step + 1) % args.checkpoint_every == 0", mode="eval").body
        new = ast.parse(
            "args.checkpoint_every and (step + 1) % args.checkpoint_every == 0 and index + 1 < args.steps", mode="eval"
        ).body
        matches = [
            node for node in ast.walk(trees[1]) if isinstance(node, ast.If) and ast.dump(node.test) == ast.dump(new)
        ]
        if len(matches) != 1:
            return False
        matches[0].test = old
        return ast.dump(trees[0]) == ast.dump(trees[1])
    except (OSError, SyntaxError, ValueError):
        return False


def wrappers_equivalent(first, second):
    if first == second:
        return True
    return first in VERIFIED_WRAPPERS and second in VERIFIED_WRAPPERS and wrapper_version_evidence()


def number(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def load(path, default=None):
    if not path:
        return default
    try:
        return json.loads(Path(path).read_text())
    except (OSError, ValueError):
        return default


def atomic(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w", dir=path.parent, prefix=f".{path.name}.", delete=False) as handle:
        handle.write(text)
        temporary = Path(handle.name)
    temporary.replace(path)


def jsonl(path, warnings, errors, strict=False):
    try:
        lines = Path(path).read_text().splitlines()
    except OSError:
        return []
    rows = []
    for index, line in enumerate(lines):
        try:
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError("row is not an object")
            rows.append(value)
        except ValueError:
            message = f"invalid JSONL line{index + 1}: {path}"
            (warnings if index == len(lines) - 1 and not strict else errors).append(message)
    return rows


def digest_signature(metadata):
    hashes = dict(metadata.get("data_sha256", {}))
    for split in ("train", "validation", "test"):
        if metadata.get(f"{split}_sha256"):
            hashes[split] = metadata[f"{split}_sha256"]
    return hashes


def arguments(metadata):
    args = metadata.get("arguments", {})
    return {
        "context": args.get("context", metadata.get("context_cap")),
        "batch": args.get("batch", metadata.get("batch_size")),
        "micro_batch": args.get("micro_batch", metadata.get("batch_size")),
        "model": args.get("model"),
        "seed": args.get("seed"),
    }


def source_contract(job, state, metadata, errors, warnings):
    actual = metadata.get("source_sha256")
    expected = job.get("expected_source_sha256") or state.get("resolved_source_sha256")
    if not actual:
        errors.append("missing measured source_sha256")
    if expected and actual != expected:
        errors.append(f"source hash differs from declared/guardian-resolved hash: {actual} != {expected}")
    if job.get("expected_source_sha256") and state.get("resolved_source_sha256"):
        if job["expected_source_sha256"] != state["resolved_source_sha256"]:
            errors.append("job expected and guardian-resolved source hashes disagree")
    if not expected:
        warnings.append("source hash was recorded but no independently expected hash was supplied")
    return actual, expected


def find_summary(job, state, phase):
    direct = state.get(f"{phase}_summary_file")
    if direct and Path(direct).exists():
        return Path(direct)
    attempts = [a for a in state.get("attempts", []) if a.get("phase") == phase]
    for attempt in reversed(attempts):
        path = Path(attempt.get("output_dir", "")) / "summary.json"
        if path.exists():
            return path
    key = "base_output_dir" if phase == "train" else "eval_output_dir"
    path = Path(job.get(key, "")) / "summary.json"
    return path if path.exists() else None


def find_metadata(state, phase, summary_path):
    for attempt in reversed(state.get("attempts", [])):
        if attempt.get("phase") == phase:
            candidate = Path(attempt.get("output_dir", "")) / "metadata.json"
            if candidate.exists():
                return load(candidate, {})
    return load(summary_path.parent / "metadata.json", {}) if summary_path else {}


def step_number(row):
    value = row.get("step")
    return int(value) if number(value) and int(value) == value else None


def time_seconds(value):
    if number(value):
        return float(value)
    if isinstance(value, str):
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00")).timestamp()
        except ValueError:
            return None
    return None


def attempt_wall(attempts, phase):
    total = 0.0
    found = False
    for attempt in attempts:
        if attempt.get("phase") != phase:
            continue
        start, end = time_seconds(attempt.get("start_time")), time_seconds(attempt.get("end_time"))
        if start is not None and end is not None and end >= start:
            total += end - start
            found = True
    return total if found else None


def trajectory(job_id, jobs, states, cache, stack=()):
    if job_id in cache:
        return cache[job_id]
    if job_id in stack:
        return {}, {}, [], ["resume_dependency cycle"]
    job, state = jobs[job_id], states.get(job_id, {})
    rows, curves, warnings, errors = {}, {}, [], []
    parent_id = job.get("resume_dependency")
    if parent_id:
        if parent_id not in jobs:
            errors.append(f"missing resume_dependency {parent_id}")
        else:
            prior, prior_curves, prior_warnings, prior_errors = trajectory(
                parent_id, jobs, states, cache, stack + (job_id,)
            )
            rows, curves = dict(prior), dict(prior_curves)
            warnings.extend(f"ancestor {parent_id}: {w}" for w in prior_warnings)
            errors.extend(f"ancestor {parent_id}: {e}" for e in prior_errors)
            parent = jobs[parent_id]
            for field in ("seed", "condition", "track", "comparison_contract"):
                default = "native-backward" if field == "comparison_contract" else None
                if parent.get(field, default) != job.get(field, default):
                    errors.append(f"resume lineage changes {field}")
            if state.get("status") == "complete" and states.get(parent_id, {}).get("status") != "complete":
                errors.append("resume_dependency lacks complete status")
    attempts = [a for a in state.get("attempts", []) if a.get("phase") == "train"]
    if not attempts:
        summary_path = find_summary(job, state, "train")
        if summary_path:
            summary = load(summary_path, {})
            attempts = [
                {
                    "phase": "train",
                    "output_dir": str(summary_path.parent),
                    "accepted_start_step": summary.get("start_step", 0),
                    "accepted_end_step": summary.get("next_step"),
                    "contaminated": False,
                }
            ]
    final_summary_path = find_summary(job, state, "train")
    final_metadata = find_metadata(state, "train", final_summary_path)
    if parent_id in jobs and final_metadata:
        parent_state = states.get(parent_id, {})
        parent_metadata = find_metadata(parent_state, "train", find_summary(jobs[parent_id], parent_state, "train"))
        if parent_metadata:
            for field in ("source_sha256", "wrapper_sha256", "encoding_policy", "order_policy"):
                if parent_metadata.get(field) != final_metadata.get(field):
                    if field == "wrapper_sha256" and wrappers_equivalent(
                        parent_metadata.get(field), final_metadata.get(field)
                    ):
                        warnings.append(WRAPPER_EQUIVALENCE_NOTE)
                    else:
                        errors.append(f"resume_dependency changes {field}")
            if digest_signature(parent_metadata) != digest_signature(final_metadata) or arguments(
                parent_metadata
            ) != arguments(final_metadata):
                errors.append("resume_dependency changes data/seed/model/context/batch")
    for attempt in attempts:
        directory = Path(attempt.get("output_dir", ""))
        summary = load(directory / "summary.json", {})
        strict_attempt = summary.get("status") == "complete"
        current = jsonl(directory / "steps.jsonl", warnings, errors, strict=strict_attempt)
        low = attempt.get("accepted_start_step")
        if not number(low):
            low = summary.get(
                "start_step", min((step_number(r) for r in current if step_number(r) is not None), default=len(rows))
            )
        high = attempt.get("accepted_end_step")
        if not number(high):
            high = summary.get("next_step")
        low = int(low)
        # A restart from an older recovery checkpoint invalidates its former tail.
        rows = {step: row for step, row in rows.items() if step < low}
        curves = {step: row for step, row in curves.items() if step <= low}
        seen = set()
        for row in current:
            step = step_number(row)
            if step is None:
                (errors if strict_attempt else warnings).append(f"noninteger/missing step in {directory}")
                continue
            if step < low or high is not None and step >= high:
                continue
            if step in seen:
                errors.append(f"duplicate step{step} within {directory}")
            seen.add(step)
            copy = dict(row)
            copy["_contaminated"] = bool(attempt.get("contaminated"))
            copy["_attempt_output_dir"] = str(directory)
            rows[step] = copy
        for row in jsonl(directory / "curve.jsonl", warnings, errors):
            step = step_number(row)
            if step is not None and step >= low and (high is None or step <= high):
                curves[step] = row
        metadata = load(directory / "metadata.json", {})
        if metadata and final_metadata:
            for field in ("source_sha256", "wrapper_sha256", "encoding_policy", "order_policy"):
                if metadata.get(field) != final_metadata.get(field):
                    if field == "wrapper_sha256" and wrappers_equivalent(
                        metadata.get(field), final_metadata.get(field)
                    ):
                        warnings.append(WRAPPER_EQUIVALENCE_NOTE)
                    else:
                        errors.append(f"attempt lineage changes {field}: {directory}")
            if digest_signature(metadata) != digest_signature(final_metadata) or arguments(metadata) != arguments(
                final_metadata
            ):
                errors.append(f"attempt lineage changes data/seed/model/context/batch: {directory}")
        resume = attempt.get("resume_from")
        if resume:
            checkpoint = load(Path(resume) / "training_state.json", {})
            if number(checkpoint.get("global_step")) and checkpoint["global_step"] != low:
                errors.append(f"resume checkpoint cursor differs from accepted start in {directory}")
    cache[job_id] = rows, curves, warnings, errors
    return cache[job_id]


def mean(values):
    return statistics.mean(values) if values else None


def target_count(row, args):
    value = row.get("target_tokens")
    if not number(value) and args.get("batch") == args.get("micro_batch"):
        value = row.get("sft_target_tokens")
    return value if number(value) else None


def compute_time(row):
    value = row.get("score_plus_train_seconds", row.get("iteration_compute_seconds"))
    return value if number(value) else None


def metrics(rows, args):
    accepted = [rows[key] for key in sorted(rows)]
    measured = [row for row in accepted if not row.get("warmup", False) and not row.get("_contaminated")]

    def refresh(row):
        return bool(row.get("update_refresh_any", row.get("galore_projection_refresh", False)))

    output = {
        "accepted_steps": len(accepted),
        "measured_clean_steps": len(measured),
        "accepted_contaminated_steps": sum(row.get("_contaminated", False) for row in accepted),
        "refresh_count_all": sum(refresh(row) for row in accepted),
        "refresh_count_measured_clean": sum(refresh(row) for row in measured),
    }
    for label, predicate in (("normal", lambda row: not refresh(row)), ("refresh", refresh)):
        selected = [row for row in measured if predicate(row)]
        times, allocated, reserved = [], [], []
        for row in selected:
            if number(row.get("update_cuda_time_s")):
                times.append(row["update_cuda_time_s"])
            elif args.get("batch") == args.get("micro_batch") and number(row.get("cuda_step_time_s")):
                times.append(row["cuda_step_time_s"])
            for primary, legacy, target in (
                ("update_peak_allocated_bytes", "cuda_peak_allocated_bytes", allocated),
                ("update_peak_reserved_bytes", "cuda_peak_reserved_bytes", reserved),
            ):
                value = row.get(primary, row.get(legacy) if args.get("batch") == args.get("micro_batch") else None)
                if number(value):
                    target.append(value)
        output[f"{label}_seconds"] = mean(times)
        output[f"{label}_allocated_gib"] = max(allocated) / 2**30 if allocated else None
        output[f"{label}_reserved_gib"] = max(reserved) / 2**30 if reserved else None
    target_rows = [r for r in measured if target_count(r, args) is not None and compute_time(r) is not None]
    denominator = sum(compute_time(r) for r in target_rows)
    output["target_tokens_per_compute_second"] = (
        sum(target_count(r, args) for r in target_rows) / denominator if denominator else None
    )
    output["samples_per_compute_second"] = (
        len(target_rows) * args["batch"] / denominator if denominator and number(args.get("batch")) else None
    )
    output["target_tokens_accepted"] = sum(target_count(r, args) for r in accepted if target_count(r, args) is not None)
    losses = [r["loss"] for r in accepted[-64:] if number(r.get("loss"))]
    output["trailing_train_loss_batch_mean"] = mean(losses)
    output["first_train_loss"] = accepted[0].get("loss") if accepted else None
    errors = [r["logp_abs_diff_mean"] for r in accepted if number(r.get("logp_abs_diff_mean"))]
    output["native_logp_abs_diff_max"] = max(errors) if errors else None
    norms = [r["grad_norm"] for r in accepted if number(r.get("grad_norm"))]
    output["clip_fraction_at_norm1"] = sum(norm > 1 for norm in norms) / len(norms) if norms else None
    return output


def audit_job(job, state, jobs, states, cache):
    warnings, errors = [], []
    train_path, eval_path = find_summary(job, state, "train"), find_summary(job, state, "eval")
    training, evaluation = load(train_path, {}), load(eval_path, {})
    metadata = find_metadata(state, "train", train_path)
    rows, curves, prior_warnings, prior_errors = trajectory(job["id"], jobs, states, cache)
    warnings += prior_warnings
    errors += prior_errors
    args = arguments(metadata)
    actual_sha, expected_sha = source_contract(job, state, metadata, errors, warnings) if metadata else (None, None)
    value = evaluation.get("final_validation_loss", evaluation.get("validation", {}).get("loss"))
    test = evaluation.get("test", {}).get("loss")
    complete = state.get("status") == "complete"
    target = job.get("target_steps")
    if complete:
        if training.get("status") != "complete" or evaluation.get("status") != "complete":
            errors.append("guardian complete but train/eval complete artifacts missing")
        if not number(value):
            errors.append("missing/nonfinite independently reloaded final validation loss")
        if training.get("next_step") != target:
            errors.append(f"final next_step {training.get('next_step')} != target_steps {target}")
        if not isinstance(target, int) or set(rows) != set(range(target)):
            errors.append("accepted lineage does not cover every absolute step0..target_steps-1")
        if args.get("seed") != job.get("seed"):
            errors.append("measured seed differs from job seed")
        if not digest_signature(metadata):
            errors.append("missing measured data hashes")
        for row in rows.values():
            if not number(row.get("loss")):
                errors.append("nonfinite/missing training loss")
                break
        if any(not number(row.get("logp_abs_diff_mean")) for row in rows.values()):
            errors.append("missing/nonfinite native SFT diagnostic in accepted trajectory")
        eval_metadata = load(eval_path.parent / "metadata.json", {}) if eval_path else {}
        if eval_metadata and metadata:
            if eval_metadata.get("source_sha256") != metadata.get("source_sha256") or digest_signature(
                eval_metadata
            ) != digest_signature(metadata):
                errors.append("independent eval source/data differs from training")
            for field in ("wrapper_sha256", "encoding_policy", "order_policy"):
                if eval_metadata.get(field) != metadata.get(field):
                    if field == "wrapper_sha256" and wrappers_equivalent(eval_metadata.get(field), metadata.get(field)):
                        warnings.append(WRAPPER_EQUIVALENCE_NOTE)
                    else:
                        errors.append(f"independent eval changes {field}")
            eval_args = arguments(eval_metadata)
            for field in ("seed", "context", "batch", "micro_batch"):
                if eval_args[field] is not None and args[field] is not None and eval_args[field] != args[field]:
                    errors.append(f"independent eval changes {field}")
        if job.get("track") == "sft":
            for split in ["validation", "test"] if job.get("test") else ["validation"]:
                scores = evaluation.get(split, {})
                encoding = scores.get("encoding", {})
                if not number(scores.get("target_tokens")) or scores["target_tokens"] <= 0:
                    errors.append(f"independent full {split} target count missing/empty")
                if encoding and (
                    scores.get("target_tokens") != encoding.get("targets")
                    or scores.get("examples") != encoding.get("rows")
                ):
                    errors.append(f"independent {split} score counts differ from full encoded fold")
        restored = evaluation.get("restored_sdk_step", evaluation.get("restored_sdk_step_index"))
        if number(restored) and restored != target - 1:
            errors.append("independent eval restored SDK cursor differs from endpoint")
    performance = metrics(rows, args)
    if performance["accepted_contaminated_steps"]:
        warnings.append("foreign-contaminated accepted steps excluded from performance summaries")
    if performance["native_logp_abs_diff_max"] is not None and performance["native_logp_abs_diff_max"] > 1e-6:
        warnings.append("native same-model logprob error exceeds1e-6; not a serialization/trajectory tolerance change")
    if test is not None and not job.get("test"):
        warnings.append("test result exists although job did not declare test evaluation; never used for selection")
    result = {
        "id": job["id"],
        "track": job.get("track"),
        "group": job.get("group"),
        "comparison_contract": job.get("comparison_contract", "native-backward"),
        "condition": job.get("condition"),
        "baseline_condition": job.get("baseline_condition", "adamw"),
        "seed": job.get("seed"),
        "target_steps": target,
        "status": state.get("status", "pending"),
        "phase": state.get("phase"),
        "gpu": state.get("gpu"),
        "pid": state.get("pid"),
        "qualified_complete": complete and not errors,
        "validation_loss": value if number(value) else None,
        "test_loss": test if number(test) else None,
        "validation_target_tokens": evaluation.get("validation", {}).get("target_tokens"),
        "validation_examples": evaluation.get("validation", {}).get("examples", evaluation.get("validation_rows")),
        "test_target_tokens": evaluation.get("test", {}).get("target_tokens"),
        "test_examples": evaluation.get("test", {}).get("examples"),
        "train_summary_file": str(train_path) if train_path else None,
        "eval_summary_file": str(eval_path) if eval_path else None,
        "source_repo": job.get("source_repo"),
        "source_sha256": actual_sha,
        "expected_source_sha256": expected_sha,
        "data_sha256": digest_signature(metadata),
        "arguments": args,
        "encoding_policy": metadata.get("encoding_policy", metadata.get("data_cursor")),
        "order_policy": metadata.get("order_policy", metadata.get("data_cursor")),
        "wrapper_sha256": metadata.get("wrapper_sha256"),
        "resume_dependency": job.get("resume_dependency"),
        "train_attempt_wall_seconds": attempt_wall(state.get("attempts", []), "train"),
        "eval_attempt_wall_seconds": attempt_wall(state.get("attempts", []), "eval"),
        "metrics": performance,
        "curves": [curves[key] for key in sorted(curves)],
        "warnings": list(dict.fromkeys(warnings)),
        "errors": list(dict.fromkeys(errors)),
        "guardian_error": state.get("error"),
    }
    if result["curves"] and number(performance["trailing_train_loss_batch_mean"]):
        monitor = result["curves"][-1]
        if number(monitor.get("loss")):
            result["monitor_minus_trailing_train"] = monitor["loss"] - performance["trailing_train_loss_batch_mean"]
            result["latest_monitor_step"] = monitor.get("step")
            result["latest_monitor_loss"] = monitor["loss"]
            if number(result["curves"][0].get("loss")):
                result["monitor_loss_change"] = monitor["loss"] - result["curves"][0]["loss"]
    return result, rows


def pair_audit(baseline, candidate, trajectories):
    errors, notes = [], []
    for field in (
        "data_sha256",
        "arguments",
        "encoding_policy",
        "order_policy",
        "wrapper_sha256",
        "validation_target_tokens",
        "validation_examples",
    ):
        if baseline[field] != candidate[field]:
            if field == "wrapper_sha256" and wrappers_equivalent(baseline[field], candidate[field]):
                notes.append(WRAPPER_EQUIVALENCE_NOTE)
            else:
                errors.append(f"paired {field} differs")
    if baseline["source_sha256"] != candidate["source_sha256"]:
        if baseline["source_repo"] == candidate["source_repo"]:
            errors.append("same declared repository has different paired source hashes")
        elif not candidate["expected_source_sha256"] or not baseline["expected_source_sha256"]:
            errors.append("variant source difference lacks explicit expected/resolved source hashes")
        else:
            notes.append(
                "intentional variant source difference: separate declared repositories and expected hashes verified"
            )
    left, right = trajectories[baseline["id"]], trajectories[candidate["id"]]
    for step in sorted(set(left) & set(right)):
        first, second = left[step], right[step]
        a = first.get("batch_sha256", first.get("batch_token_sha256"))
        b = second.get("batch_sha256", second.get("batch_token_sha256"))
        if not a or a != b:
            errors.append(f"batch/mask hash differs or missing at step{step}")
            break
        first_targets = target_count(first, baseline["arguments"])
        second_targets = target_count(second, candidate["arguments"])
        if first_targets is None or second_targets is None or first_targets != second_targets:
            errors.append(f"target count differs or missing at step{step}")
            break
    a, b = baseline["metrics"]["first_train_loss"], candidate["metrics"]["first_train_loss"]
    if number(a) and number(b) and abs(a - b) > 1e-6:
        errors.append("initial paired forward loss differs beyond1e-6")
    return {"passed": not errors, "errors": errors, "notes": notes, "compared_steps": len(set(left) & set(right))}


def group_results(evidence, trajectories):
    buckets = defaultdict(list)
    for row in evidence:
        key = (row["track"], row["group"], row["comparison_contract"], row["target_steps"])
        buckets[key].append(row)
    output = []
    for key, rows in sorted(buckets.items(), key=lambda item: str(item[0])):
        conditions = defaultdict(list)
        for row in rows:
            conditions[row["condition"]].append(row)
        baseline_names = {row["baseline_condition"] for row in rows}
        baseline_name = next(iter(baseline_names)) if len(baseline_names) == 1 else None
        baseline = conditions.get(baseline_name, [])
        baseline_seeds = {row["seed"]: row for row in baseline}
        results = []
        for condition, members in sorted(conditions.items(), key=lambda item: str(item[0])):
            by_seed = {row["seed"]: row for row in members}
            complete = (
                set(by_seed) == {0, 1, 2} and len(members) == 3 and all(row["qualified_complete"] for row in members)
            )
            pairs = []
            if (
                complete
                and set(baseline_seeds) == {0, 1, 2}
                and len(baseline) == 3
                and all(row["qualified_complete"] for row in baseline)
            ):
                for seed in (0, 1, 2):
                    audit = pair_audit(baseline_seeds[seed], by_seed[seed], trajectories)
                    pairs.append(
                        {
                            "seed": seed,
                            "baseline_id": baseline_seeds[seed]["id"],
                            "candidate_id": by_seed[seed]["id"],
                            **audit,
                        }
                    )
            paired_complete = complete and len(pairs) == 3 and all(pair["passed"] for pair in pairs)
            losses = [row["validation_loss"] for row in members if row["qualified_complete"]]
            result = {
                "condition": condition,
                "baseline_condition": baseline_name,
                "qualified_seeds": sorted(row["seed"] for row in members if row["qualified_complete"]),
                "all_three_seeds_complete": complete,
                "paired_audits": pairs,
                "paired_quality_eligible": paired_complete,
                "validation_loss_mean": mean(losses),
                "validation_loss_sample_std": statistics.stdev(losses) if len(losses) > 1 else None,
                "validation_relative_change_percent": None,
                "quality_gate_pass": None,
                "test_loss_mean": mean(
                    [row["test_loss"] for row in members if row["qualified_complete"] and row["test_loss"] is not None]
                ),
                "test_seeds": sorted(
                    row["seed"] for row in members if row["qualified_complete"] and row["test_loss"] is not None
                ),
                "per_seed": [
                    {
                        "seed": row["seed"],
                        "job_id": row["id"],
                        "validation_loss": row["validation_loss"],
                        "qualified_complete": row["qualified_complete"],
                    }
                    for row in sorted(members, key=lambda row: row["seed"])
                ],
            }
            if paired_complete:
                denominator = statistics.mean(baseline_seeds[seed]["validation_loss"] for seed in (0, 1, 2))
                result["validation_relative_change_percent"] = (result["validation_loss_mean"] / denominator - 1) * 100
                result["quality_gate_pass"] = result["validation_loss_mean"] <= denominator * 1.02
            results.append(result)
        output.append(
            {
                "track": key[0],
                "group": key[1],
                "comparison_contract": key[2],
                "target_steps": key[3],
                "conditions": results,
            }
        )
    return output


def fmt(value, digits=4):
    return f"{value:.{digits}f}" if number(value) else "—"


def markdown(analysis):
    lines = [
        "# Overnight experiment snapshot",
        "",
        f"Generated {analysis['generated_at_local']}. Guardian status: {analysis['status_counts']}.",
        f"Guardian PID {analysis['guardian_pid']}; alive={analysis['guardian_alive_at_snapshot']}; status age {fmt(analysis['guardian_status_age_seconds'], 1)} seconds.",
        "",
        "These are preregistered condition comparisons, not an ensemble or a test-set model selection. Incomplete/failed/unpaired three-seed groups receive no quality verdict. The ≤2% validation-loss target is specific to each matched data/budget/forward-backward contract.",
        "",
    ]
    for group in analysis["groups"]:
        lines += [
            f"## {group['track']} / {group['group']} / {group['comparison_contract']} / {group['target_steps']} updates",
            "",
            "| Condition | Qualified seeds | Mean val loss | Relative to baseline | Fixed-job test mean (seeds) | ≤2% gate |",
            "|---|---|---:|---:|---:|---|",
        ]
        for row in group["conditions"]:
            verdict = (
                "PASS"
                if row["quality_gate_pass"] is True
                else "FAIL"
                if row["quality_gate_pass"] is False
                else "pending / audit blocked"
            )
            relative = fmt(row["validation_relative_change_percent"], 2)
            lines.append(
                f"| {row['condition']} | {row['qualified_seeds']} | {fmt(row['validation_loss_mean'])} | {relative}{'%' if relative != '—' else ''} | {fmt(row['test_loss_mean'])} {row['test_seeds']} | {verdict} |"
            )
            failures = [error for pair in row["paired_audits"] for error in pair["errors"]]
            if failures:
                lines += ["", f"Pairing blocked for {row['condition']}: {'; '.join(dict.fromkeys(failures))}.", ""]
        lines.append("")
    lines += [
        "## Per-job progress and compute",
        "",
        "| Job | Status | Accepted updates | Val loss | Normal / refresh s | Normal / refresh allocated GiB | Normal / refresh reserved GiB | Native logp max |",
        "|---|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in analysis["jobs"]:
        value = row["metrics"]
        lines.append(
            f"| {row['id']} | {row['status']} | {value['accepted_steps']}/{row['target_steps']} | {fmt(row['validation_loss'])} | {fmt(value['normal_seconds'])} / {fmt(value['refresh_seconds'])} | {fmt(value['normal_allocated_gib'], 2)} / {fmt(value['refresh_allocated_gib'], 2)} | {fmt(value['normal_reserved_gib'], 2)} / {fmt(value['refresh_reserved_gib'], 2)} | {fmt(value['native_logp_abs_diff_max'], 7)} |"
        )
    monitored = [row for row in analysis["jobs"] if row.get("latest_monitor_loss") is not None]
    if monitored:
        lines += [
            "",
            "## Learning monitors (descriptive only)",
            "",
            "| Job | Latest monitor update | Monitor loss | Change from initial monitor | Trailing train batch-mean | Monitor minus train | Clip fraction |",
            "|---|---:|---:|---:|---:|---:|---:|",
        ]
        for row in monitored:
            value = row["metrics"]
            lines.append(
                f"| {row['id']} | {row['latest_monitor_step']} | {fmt(row['latest_monitor_loss'])} | {fmt(row.get('monitor_loss_change'))} | {fmt(value['trailing_train_loss_batch_mean'])} | {fmt(row.get('monitor_minus_trailing_train'))} | {fmt(value['clip_fraction_at_norm1'], 3)} |"
            )
    problems = [
        (row["id"], row["errors"], row["warnings"], row["guardian_error"])
        for row in analysis["jobs"]
        if row["errors"] or row["warnings"] or row["guardian_error"]
    ]
    lines += [
        "",
        "## Audit notes",
        "",
        "- Native profiles use per-update sums of microbatch time and maxima of peaks. Legacy averaged metrics are accepted only for a single microbatch. Compute throughput includes actor scoring and training, excludes validation monitoring, logging, checkpointing and initialization; attempt wall time is separate.",
        "- Refresh/normal peaks are allocator peaks, not isolated solver workspace or whole-device memory. Contaminated accepted steps are excluded from performance aggregates.",
        "- The trailing train readout averages batch token-means. Monitor-minus-trailing-train is descriptive, not a statistically estimated generalization gap. Monitor curves never choose a winner or replace independent full-fold endpoints.",
        "- Native CUDA backward nondeterminism remains a separate trajectory limitation. No tolerance is widened here. Three seeds do not support a multiple-comparison significance claim.",
        "- Exactly two frozen wrapper versions are accepted as training-equivalent only after full SHA and AST checks: v2 skips the final redundant recovery checkpoint. Their checkpoint-I/O/wall times are not equivalent; unknown wrapper differences remain blocked.",
    ]
    for job, errors, warnings, guardian in problems:
        lines += [
            "",
            f"**{job}**: "
            + "; ".join([*(f"ERROR: {error}" for error in errors), *warnings, *([str(guardian)] if guardian else [])]),
        ]
    if analysis["input_errors"]:
        lines += ["", "Input errors: " + "; ".join(analysis["input_errors"])]
    return "\n".join(lines) + "\n"


def run(root):
    root = Path(root)

    def input_document(path):
        try:
            blob = path.read_bytes()
            return json.loads(blob), hashlib.sha256(blob).hexdigest()
        except (OSError, ValueError):
            return {}, None

    definition, jobs_sha256 = input_document(root / "jobs.json")
    snapshot, status_sha256 = input_document(root / "status.json")
    input_errors = []
    specs = definition.get("jobs", [])
    if not isinstance(specs, list):
        specs = []
        input_errors.append("jobs.json jobs must be a list")
    if not specs:
        input_errors.append("jobs.json missing, unreadable or empty")
    if not snapshot:
        input_errors.append("status.json missing or unreadable; all jobs treated pending")
    jobs = {job["id"]: job for job in specs if isinstance(job, dict) and "id" in job}
    if len(jobs) != len(specs):
        input_errors.append("missing/duplicate job IDs")
    states = snapshot.get("jobs", {})
    if not isinstance(states, dict):
        states = {}
        input_errors.append("status jobs must be an object")
    evidence, trajectories, cache = [], {}, {}
    for job in jobs.values():
        try:
            result, rows = audit_job(job, states.get(job["id"], {}), jobs, states, cache)
            evidence.append(result)
            trajectories[job["id"]] = rows
        except (OSError, ValueError, TypeError, KeyError) as error:
            input_errors.append(f"{job['id']}: audit failed safely: {type(error).__name__}: {error}")
    now = datetime.now(UTC)
    updated = time_seconds(snapshot.get("updated_at"))
    guardian_pid = snapshot.get("guardian_pid")
    guardian_alive = (
        Path(f"/proc/{guardian_pid}").exists() if isinstance(guardian_pid, int) and guardian_pid > 0 else None
    )
    analysis = {
        "generated_at": now.isoformat(),
        "generated_at_local": now.astimezone(ZoneInfo("Asia/Shanghai")).isoformat(),
        "report_at": definition.get("report_at"),
        "guardian_updated_at": snapshot.get("updated_at"),
        "guardian_pid": snapshot.get("guardian_pid"),
        "guardian_alive_at_snapshot": guardian_alive,
        "guardian_status_age_seconds": max(0, now.timestamp() - updated) if updated is not None else None,
        "analyzer_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "wrapper_version_equivalence": {
            "verified": wrapper_version_evidence(),
            "versions": VERIFIED_WRAPPERS,
            "scope": WRAPPER_EQUIVALENCE_NOTE,
        },
        "jobs_manifest_sha256": jobs_sha256,
        "status_snapshot_sha256": status_sha256,
        "status_counts": dict(Counter(states.get(job_id, {}).get("status", "pending") for job_id in jobs)),
        "input_errors": input_errors,
        "jobs": evidence,
        "groups": group_results(evidence, trajectories),
        "interpretation": "Incomplete or unpaired three-seed groups have no final quality verdict; no ensemble or holdout-based selection.",
    }

    def clean_json(value):
        if isinstance(value, float) and not math.isfinite(value):
            return None
        if isinstance(value, dict):
            return {key: clean_json(item) for key, item in value.items()}
        if isinstance(value, list):
            return [clean_json(item) for item in value]
        return value

    analysis = clean_json(analysis)
    atomic(root / "analysis.json", json.dumps(analysis, indent=2, allow_nan=False) + "\n")
    columns = [
        "id",
        "track",
        "group",
        "comparison_contract",
        "condition",
        "seed",
        "status",
        "qualified_complete",
        "target_steps",
        "validation_loss",
        "test_loss",
        "validation_target_tokens",
        "validation_examples",
        "test_target_tokens",
        "test_examples",
        "source_sha256",
        "accepted_steps",
        "normal_seconds",
        "refresh_seconds",
        "normal_allocated_gib",
        "refresh_allocated_gib",
        "normal_reserved_gib",
        "refresh_reserved_gib",
        "target_tokens_per_compute_second",
        "samples_per_compute_second",
        "target_tokens_accepted",
        "refresh_count_all",
        "accepted_contaminated_steps",
        "trailing_train_loss_batch_mean",
        "latest_monitor_step",
        "latest_monitor_loss",
        "monitor_loss_change",
        "monitor_minus_trailing_train",
        "train_attempt_wall_seconds",
        "eval_attempt_wall_seconds",
        "native_logp_abs_diff_max",
        "clip_fraction_at_norm1",
    ]
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=columns, extrasaction="ignore")
    writer.writeheader()
    for row in evidence:
        writer.writerow({**row, **row["metrics"]})
    atomic(root / "results.csv", buffer.getvalue())
    atomic(root / "MORNING_REPORT.md", markdown(analysis))
    return analysis


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    result = run(args.root)
    eligible = sum(row["paired_quality_eligible"] for group in result["groups"] for row in group["conditions"])
    print(
        json.dumps(
            {
                "status_counts": result["status_counts"],
                "paired_complete_conditions": eligible,
                "input_errors": result["input_errors"],
                "report": str(args.root / "MORNING_REPORT.md"),
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
