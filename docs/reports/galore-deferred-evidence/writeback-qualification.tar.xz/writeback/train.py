"""Matched training-only performance path; never saves/evaluates a checkpoint."""

from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import statistics
import time
from datetime import datetime, timezone

# Before importing CUDA-capable modules, acknowledge our registered process
# group. Spawned workers inherit the same group and execute this too.
if os.getenv("ARENO_CONFIRM_CONTROLLER_PID"):
    for _ in range(60):
        try:
            status = json.loads(
                (Path(__file__).resolve().parent / "STATUS.json").read_text()
            )
            active = status["active"][os.environ["CUDA_VISIBLE_DEVICES"]]
            if active["pid"] == os.getpgrp() and status["pid"] == int(
                os.environ["ARENO_CONFIRM_CONTROLLER_PID"]
            ):
                break
        except (FileNotFoundError, KeyError, json.JSONDecodeError):
            pass
        time.sleep(0.5)
    else:
        raise RuntimeError("controller did not register this process group")

import common
import torch
from areno.api import sft_loss_fn

from contract import verify


def source_hash(repo):
    h = hashlib.sha256()
    for p in sorted((Path(repo) / "areno").rglob("*.py")):
        h.update(str(p.relative_to(repo)).encode())
        h.update(p.read_bytes())
    return h.hexdigest()


def measure(rows):
    def distribution(key):
        values = sorted(r[key] for r in rows)
        return (
            {
                "mean": statistics.mean(values),
                "median": statistics.median(values),
                "p95": values[math.ceil(0.95 * len(values)) - 1],
                "min": min(values),
                "max": max(values),
            }
            if values
            else None
        )

    wall = sum(r["score_plus_train_seconds"] for r in rows)
    cuda = sum(r["update_cuda_time_s"] for r in rows)
    tokens = sum(r["target_tokens"] for r in rows)
    return {
        "updates": len(rows),
        "target_tokens": tokens,
        "score_plus_train_wall_seconds": wall,
        "cuda_seconds": cuda,
        "target_tokens_per_wall_second": tokens / wall if wall else None,
        "target_tokens_per_cuda_second": tokens / cuda if cuda else None,
        "cuda_time_s": distribution("update_cuda_time_s"),
        "optimizer_cuda_event_s": distribution("update_optimizer_time_s"),
        "optimizer_cpu_time_s": distribution("update_optimizer_cpu_s"),
        "optimizer_host_launch_wall_s": distribution("update_optimizer_launch_wall_s"),
        "worker_cpu_time_s": distribution("update_worker_cpu_s"),
        "score_plus_train_s": distribution("score_plus_train_seconds"),
        "scoring_s": distribution("scoring_seconds"),
        "allocated_peak_bytes": max(
            (r["update_peak_allocated_bytes"] for r in rows), default=None
        ),
        "reserved_peak_bytes": max(
            (r["update_peak_reserved_bytes"] for r in rows), default=None
        ),
    }


def main():
    p = common.parser(__doc__)
    p.add_argument("--measured-updates", type=int, default=400)
    p.add_argument("--warmup-updates", type=int, default=2)
    args = p.parse_args()
    if args.measured_updates != 400 or args.warmup_updates != 2:
        p.error("this preregistered measurement requires warm2 + exactly400 updates")
    if (
        args.seed != 0
        or args.context != 512
        or args.batch != 4
        or args.micro_batch != 4
    ):
        p.error("matched seed0 ctx512 batch4 micro4 required")
    if args.rank != 128 or args.gap != 200 or args.scale != 1 or args.retained:
        p.error("registered rank128/gap200/scale1/transport required")
    expected_flag = os.getenv("ARENO_EXPERIMENT_DEFERRED_PROJECTION")
    if expected_flag not in ("0", "1") or (
        args.optimizer != "galore" and expected_flag != "0"
    ):
        p.error("explicit per-method deferred flag mismatch")
    if any(
        name.startswith("ARENO_EXPERIMENT_")
        and name
        not in {
            "ARENO_EXPERIMENT_DEFERRED_PROJECTION",
            "ARENO_EXPERIMENT_FUSED_SCALE_WRITEBACK",
        }
        for name in os.environ
    ):
        p.error("unregistered private experimental flag")
    if json.loads(args.extra_config_json) not in (
        {},
        {"optimizer": {"galore_exclude_vocab": False}},
    ):
        p.error("no runtime or optimizer override outside the registered target policy")
    expected_fused = os.getenv("ARENO_EXPERIMENT_FUSED_SCALE_WRITEBACK")
    assert expected_fused in ("0", "1")
    log = common.setup(args, "train-perf")
    import areno

    repo = Path(areno.__file__).resolve().parent.parent
    manifest = verify()
    actual_source = source_hash(repo)
    assert repo == Path(__file__).resolve().parent / "repo"
    assert actual_source == manifest["source_sha256"], actual_source
    assert Path(args.model).resolve() == Path(manifest["model_path"]).resolve()
    assert not args.checkpoint_dir.exists(), "performance-only run cannot resume/save"
    train_sha = common.digest(args.data_dir / "train.jsonl")
    assert (
        train_sha == "41765eb786b76354f4a7630d5101d46ba1ae08a2eabc35724db462f2d6d93447"
    )
    info = {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "arguments": {
            k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()
        },
        "source_root": str(repo),
        "source_sha256": actual_source,
        "model_revision": manifest["model_revision"],
        "model_asset_manifest_sha256": manifest["model_asset_manifest_sha256"],
        "deferred_projection_flag": os.getenv("ARENO_EXPERIMENT_DEFERRED_PROJECTION"),
        "fused_scale_writeback_flag": os.getenv(
            "ARENO_EXPERIMENT_FUSED_SCALE_WRITEBACK"
        ),
        "torch_version": torch.__version__,
        "cuda_version": torch.version.cuda,
        "gpu": torch.cuda.get_device_name(0),
        "cuda_visible_devices": os.getenv("CUDA_VISIBLE_DEVICES"),
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "cublas_workspace_config": os.getenv("CUBLAS_WORKSPACE_CONFIG"),
        "native_extension_sha256": common.digest(
            next((repo / "areno/accel").glob("_areno_accel*.so"))
        ),
        "data_sha256": {"train": train_sha},
        "wrapper_sha256": {
            n: common.digest(Path(__file__).with_name(n))
            for n in ["common.py", "train.py"]
        },
        "private_experiment_policy": "deferred-only-default-off",
        "authoritative_master_policy": "strict-fp32-master-compact-lossless"
        if args.optimizer == "galore"
        else "unchanged-native-control",
        "execution_entry_sha256": common.digest(Path(__file__)),
        "saved_checkpoints": False,
        "read_validation_or_test": False,
        "note": "Matched micro4 single-pack native synchronized train timing; optimizer events read after existing synchronization only. Deferred projection runs inside backward, so optimizer-only time excludes moved work and cannot establish total speedup. No quality evaluation.",
    }
    common.write(args.output_dir / "metadata.json", info)
    os.environ["ARENO_SCALE_OUTPUT_DIR"] = str(args.output_dir)
    engine = common.trainer(args, resume=False)
    rows = []
    orders = {}
    started = time.perf_counter()
    try:
        engine.init()
        training, stats = common.encode(engine.get_tokenizer(), args, "train")
        common.write(args.output_dir / "encoding.json", stats)
        start = engine._ctx.global_step + 1
        assert start == 0, start
        with (args.output_dir / "steps.jsonl").open("w") as raw:
            for index in range(args.warmup_updates + args.measured_updates):
                indices = common.batch_indices(
                    index, args.seed, len(training), args.batch, orders
                )
                batch = [training[i] for i in indices]
                stamp = datetime.now(timezone.utc).isoformat()
                begin = time.perf_counter()
                scored = engine.score_logprobs(
                    "actor", [s.tokens for s in batch], microbatch_size=args.micro_batch
                )
                for sample, values in zip(batch, scored, strict=True):
                    sample.logprobs = list(values)
                scored_at = time.perf_counter()
                result = engine.train(batch, sft_loss_fn, mini_bs=args.micro_batch)
                elapsed = time.perf_counter() - begin
                assert result.get("update_optimizer_steps") == 1, result
                assert result["optimizer_fused_scale_writeback_enabled"] == int(
                    expected_fused
                )
                assert (
                    result["update_worker_step"] == index + 1
                    and engine._ctx.global_step == index
                )
                assert bool(result["update_refresh_any"]) == (
                    args.optimizer == "galore" and index % 200 == 0
                )
                assert result["optimizer_deferred_projection_enabled"] == (
                    int(expected_flag) if args.optimizer == "galore" else 0
                )
                if args.optimizer == "galore":
                    assert (
                        result["galore_master_bytes"] > 0
                        and result["optimizer_model_owned_master_enabled"] == 0
                    )
                assert (
                    math.isfinite(result["loss"]) and result["logp_abs_diff_mean"] == 0
                ), result
                target_tokens = sum(len(s.tokens) - s.prompt_len for s in batch)
                assert result["sft_pack_count"] == 1
                assert result["sft_dp_shards_per_pack"] == 1
                assert result["sft_total_target_tokens"] == target_tokens
                assert result["sft_grad_scale"] == 1
                if expected_flag == "1":
                    assert result["deferred_owner_count"] == 226
                    assert result["deferred_barrier_versions_unchanged"] == 1
                    assert result["deferred_full_leaf_bytes_after_backward"] == 0
                    assert result["deferred_cache_empty_after_step"] == 1
                row = {
                    "timestamp": stamp,
                    "step": index,
                    "sample_indices": indices,
                    "batch_sha256": hashlib.sha256(
                        json.dumps(
                            [(s.tokens, s.prompt_len) for s in batch],
                            separators=(",", ":"),
                        ).encode()
                    ).hexdigest(),
                    "target_tokens": sum(len(s.tokens) - s.prompt_len for s in batch),
                    "warmup": index < args.warmup_updates,
                    "scoring_seconds": scored_at - begin,
                    "score_plus_train_seconds": elapsed,
                    **result,
                }
                raw.write(json.dumps(row) + "\n")
                raw.flush()
                rows.append(row)
                log.info("step %s", json.dumps(row))
        measured = rows[args.warmup_updates :]
        normal = [r for r in measured if not r["update_refresh_any"]]
        refresh = [r for r in measured if r["update_refresh_any"]]
        expected_refreshes = 2 if args.optimizer == "galore" else 0
        assert len(refresh) == expected_refreshes, [r["step"] for r in refresh]
        summary = {
            "status": "complete",
            "optimizer": args.optimizer,
            "seed": args.seed,
            "completed_updates": len(rows),
            "warmup_updates": args.warmup_updates,
            "measured_updates": len(measured),
            "refresh_steps": [r["step"] for r in refresh],
            "all": measure(measured),
            "cold_step0": measure(rows[:1]),
            "cold_step0_refresh": bool(rows[0]["update_refresh_any"]),
            "normal": measure(normal),
            "refresh": measure(refresh),
            "native_logp_abs_diff_max": max(r["logp_abs_diff_mean"] for r in rows),
            "elapsed_seconds": time.perf_counter() - started,
            "saved_checkpoints": False,
            "read_validation_or_test": False,
            "source_sha256": actual_source,
            "deferred_projection_flag": os.getenv(
                "ARENO_EXPERIMENT_DEFERRED_PROJECTION"
            ),
            "private_experiment_policy": "deferred-only-default-off",
            "all_galore_master_bytes_positive": all(
                r.get("galore_master_bytes") > 0 for r in rows
            )
            if args.optimizer == "galore"
            else None,
        }
        assert not args.checkpoint_dir.exists(), "performance run saved a checkpoint"
        assert source_hash(repo) == actual_source
        common.write(args.output_dir / "summary.json", summary)
        log.info("complete %s", json.dumps(summary))
    finally:
        engine.close()


if __name__ == "__main__":
    main()
