"""Same-input compact CUDA writeback for rounding, offsets and nonfinite flags."""

import argparse
import json
from pathlib import Path

import torch

from areno.engine.optim.compact_writeback import compact_writeback
from areno.engine.optim.galore import GaLoreAdamW
from areno.engine.optim.master_storage import decode_fp32_master


def bits_equal(a, b):
    assert a.dtype == b.dtype and a.shape == b.shape
    assert torch.equal(
        a.contiguous().reshape(-1).view(torch.uint8),
        b.contiguous().reshape(-1).view(torch.uint8),
    )


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    words = torch.tensor(
        [
            0,
            -2147483648,
            1,
            -2147483647,
            8388607,
            8388608,
            1065353216,
            -1082130432,
            2139095039,
            -8388609,
            1065385983,
            1065385984,
            1065385985,
            1065451519,
            1065451520,
            1065451521,
        ],
        dtype=torch.int32,
        device="cuda",
    )
    values = words.view(torch.float32)
    cases = []
    for scale in (0.5, 1.0, 2.0, 4.0, 1.3, 0.1):
        for offset, count in ((0, 10), (8, 19), (0, 1025), (8, 2049)):
            for layout in ("contiguous", "strided"):
                for alpha in (-0.003, 0.0):
                    total = offset + count
                    source = values.repeat(
                        (count + values.numel() - 1) // values.numel()
                    )[:count]
                    update = (
                        source.clone()
                        if layout == "contiguous"
                        else torch.stack((source, source), -1)[:, 0]
                    )
                    original = torch.linspace(-0.5, 0.5, total, device="cuda")
                    a, ac = GaLoreAdamW._checked_encode(original)
                    b, bc = GaLoreAdamW._checked_encode(original)
                    af = torch.zeros((), dtype=torch.int32, device="cuda")
                    bf = torch.zeros_like(af)
                    scaled = update.clone().mul_(scale)
                    compact_writeback(a, ac, scaled, offset, 0.9999, alpha, af)
                    compact_writeback(
                        b, bc, update, offset, 0.9999, alpha, bf, scale=scale
                    )
                    for x, y in (
                        (a, b),
                        (ac.low_bits, bc.low_bits),
                        (ac.round_up_bits, bc.round_up_bits),
                        (af, bf),
                    ):
                        bits_equal(x, y)
                    bits_equal(decode_fp32_master(a, ac), decode_fp32_master(b, bc))
                    cases.append(
                        dict(
                            scale=scale,
                            offset=offset,
                            count=count,
                            layout=layout,
                            alpha=alpha,
                            invalid=int(af),
                        )
                    )
    args.output.write_text(
        json.dumps(
            dict(status="passed", cases=cases, tensor_bit_comparisons=6 * len(cases)),
            indent=2,
        )
        + "\n"
    )
    print(json.dumps(dict(status="passed", cases=len(cases))), flush=True)


if __name__ == "__main__":
    main()
