"""Evaluate only frozen native performance logs, without model/data access."""

from analyze import ROOT, analyze
from contract import write


if __name__ == "__main__":
    write(ROOT / "ANALYSIS.json", analyze())
