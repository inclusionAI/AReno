"""Frozen experiment harness: matched batches, response targets and public Trainer."""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import math
import os
import random
import time
from datetime import UTC, datetime
from pathlib import Path

import torch

import areno
from areno import Trainer
from areno.api import CudaConfig, TrainSequence
from areno.engine.training import TrainingManager

ALIAS = Path(__file__).resolve().parent
ROOT = Path("/mnt2/ling/areno-galore")
if "ARENO_BENCH_SEED" in os.environ:
    torch.manual_seed(int(os.environ["ARENO_BENCH_SEED"]))
    random.seed(int(os.environ["ARENO_BENCH_SEED"]))


def model_inventory(model, optimizer):
    """Tensor metadata only: no value copies, reductions, or host tensor reads."""
    named = [
        (name, parameter)
        for name, parameter in model.named_parameters()
        if parameter.requires_grad
    ]
    parameters = list(optimizer.model_params)
    assert [id(parameter) for _, parameter in named] == [
        id(parameter) for parameter in parameters
    ]
    rows = [
        {
            "index": index,
            "name": name,
            "shape": list(parameter.shape),
            "dtype": str(parameter.dtype),
            "numel": parameter.numel(),
            "device": str(parameter.device),
        }
        for index, (name, parameter) in enumerate(named)
    ]
    dtype_elements = {}
    dtype_owners = {}
    for row in rows:
        dtype_elements[row["dtype"]] = (
            dtype_elements.get(row["dtype"], 0) + row["numel"]
        )
        dtype_owners[row["dtype"]] = dtype_owners.get(row["dtype"], 0) + 1
    shape_order = [[row["name"], row["shape"], row["dtype"]] for row in rows]
    return {
        "model_parameter_owners": len(rows),
        "optimizer_parameter_owners": len(parameters),
        "optimizer_order_matches_named_owners": True,
        "unique_parameters": sum(row["numel"] for row in rows),
        "dtype_elements": dtype_elements,
        "dtype_owners": dtype_owners,
        "matrix_owners": sum(len(row["shape"]) == 2 for row in rows),
        "vector_owners": sum(len(row["shape"]) == 1 for row in rows),
        "shape_eligible_basis_owners_rank128": sum(
            len(parameter.shape) == 2
            and 128 < min(parameter.shape)
            and 128 * (2 * max(parameter.shape) + min(parameter.shape))
            < 2 * parameter.numel()
            for parameter in parameters
        ),
        "shape_order_dtype_sha256": hashlib.sha256(
            json.dumps(shape_order, separators=(",", ":")).encode()
        ).hexdigest(),
        "owners": rows,
        "scope": "actual runtime tensor metadata only; not weights/data, memory peaks or quality",
    }


def observe_initial_model(worker):
    first = not getattr(worker, "_scale_model_inventory_written", False)
    if first:
        actual = model_inventory(worker.model, worker.optimizer)
        expected = json.loads((ALIAS / "META_MODEL_EXPECTATION.json").read_text())
        for name in (
            "model_parameter_owners",
            "optimizer_parameter_owners",
            "unique_parameters",
            "dtype_elements",
            "dtype_owners",
            "shape_eligible_basis_owners_rank128",
            "shape_order_dtype_sha256",
        ):
            assert actual[name] == expected[name], (name, actual[name], expected[name])
        assert all(row["device"].startswith("cuda:") for row in actual["owners"])
        path = (
            Path(os.environ["ARENO_SCALE_OUTPUT_DIR"]) / "worker-model-inventory.json"
        )
        assert not path.exists()
        write(path, actual)
        worker._scale_model_inventory_written = True
    return first


def sft_normalization(payload):
    """Observe CPU scalar annotations before to_device; no tensor host reads."""
    packs = payload.data_packs_by_dp
    assert len(packs) == 1 and len(packs[0]) == 1
    pack = packs[0][0]
    total = pack.get("_sft_total_target_tokens")
    scale = pack.get("_sft_grad_scale")
    assert type(total) is int and type(scale) is int
    return {
        "sft_pack_count": len(packs),
        "sft_dp_shards_per_pack": len(packs[0]),
        "sft_total_target_tokens": total,
        "sft_grad_scale": scale,
    }


# Native profiles reset per microbatch. Preserve them and additionally expose
# sum(time)/max(peaks) per actual optimizer update, instead of averaging peaks.
if not getattr(TrainingManager.train, "_overnight_profile", False):
    _native_train = TrainingManager.train

    def _profile_update(self, payload):
        before = self.worker._global_step
        normalization = sft_normalization(payload)
        first_update = observe_initial_model(self.worker)
        optimizer = self.worker.optimizer
        original_step = optimizer.step
        optimizer_events, optimizer_cpu, optimizer_launch_wall = [], [], []

        def timed_step(*args, **kwargs):
            first = torch.cuda.Event(enable_timing=True)
            last = torch.cuda.Event(enable_timing=True)
            first.record()
            started, cpu = time.perf_counter(), time.process_time()
            result = original_step(*args, **kwargs)
            optimizer_launch_wall.append(time.perf_counter() - started)
            last.record()
            optimizer_events.append((first, last))
            optimizer_cpu.append(time.process_time() - cpu)
            return result

        optimizer.step = timed_step
        worker_cpu = time.process_time()
        try:
            results = _native_train(self, payload)
        finally:
            optimizer.step = original_step
        worker_cpu = time.process_time() - worker_cpu
        if first_update:
            states = getattr(optimizer, "state", {})
            observation = {
                "worker_step": self.worker._global_step,
                "basis_owners": sum(
                    state.get("basis") is not None for state in states.values()
                ),
                "optimizer_deferred_projection_enabled": bool(
                    getattr(optimizer, "_deferred_projection", False)
                ),
                "scope": "once after cold step0; metadata-only state count, outside measured updates",
            }
            write(
                Path(os.environ["ARENO_SCALE_OUTPUT_DIR"])
                / "worker-step0-state-inventory.json",
                observation,
            )
        # profile_training already synchronized each native microbatch.
        # Reading completed events adds no synchronization to the protocol.
        assert all(last.query() for _, last in optimizer_events)
        optimizer_times = [
            first.elapsed_time(last) / 1000 for first, last in optimizer_events
        ]

        rows = [
            row["metrics"] for row in results if row is not None and row.get("metrics")
        ]
        if rows:
            aggregate = {
                "update_cuda_time_s": sum(
                    row.get("cuda_step_time_s", 0) for row in rows
                ),
                "update_peak_allocated_bytes": max(
                    row.get("cuda_peak_allocated_bytes", 0) for row in rows
                ),
                "update_peak_reserved_bytes": max(
                    row.get("cuda_peak_reserved_bytes", 0) for row in rows
                ),
                "update_optimizer_steps": self.worker._global_step - before,
                "update_optimizer_time_s": sum(optimizer_times),
                "update_optimizer_cpu_s": sum(optimizer_cpu),
                "update_optimizer_launch_wall_s": sum(optimizer_launch_wall),
                "update_worker_cpu_s": worker_cpu,
                "optimizer_fused_scale_writeback_enabled": float(
                    getattr(optimizer, "_fused_scale_writeback", False)
                ),
                "optimizer_model_owned_master_enabled": float(
                    getattr(optimizer, "_model_owned_master", False)
                ),
                "optimizer_deferred_projection_enabled": float(
                    getattr(optimizer, "_deferred_projection", False)
                ),
                "deferred_cache_empty_after_step": float(
                    not getattr(optimizer, "_deferred_pending", {})
                ),
                **getattr(optimizer, "_deferred_last", {}),
                **normalization,
                "update_worker_step": self.worker._global_step,
                "update_refresh_any": float(
                    any(row.get("galore_projection_refresh", False) for row in rows)
                ),
            }
            for row in rows:
                row.update(aggregate)
        return results

    _profile_update._overnight_profile = True
    TrainingManager.train = _profile_update


def parser(description):
    p = argparse.ArgumentParser(description=description)
    p.add_argument("--data-dir", type=Path, required=True)
    p.add_argument("--checkpoint-dir", type=Path, required=True)
    p.add_argument("--output-dir", type=Path, required=True)
    p.add_argument("--model", default=str(ROOT / "models/Qwen3-1.7B"))
    p.add_argument(
        "--optimizer", choices=["adamw", "adam8", "galore"], default="galore"
    )
    p.add_argument("--seed", type=int, choices=[0, 1, 2], default=0)
    p.add_argument("--context", type=int, default=512)
    p.add_argument("--batch", type=int, default=4)
    p.add_argument("--micro-batch", type=int, default=4)
    p.add_argument("--rank", type=int, default=128)
    p.add_argument("--gap", type=int, default=200)
    p.add_argument("--scale", type=float, default=4)
    p.add_argument("--retained", action="store_true")
    p.add_argument("--extra-config-json", default="{}")
    return p


def setup(args, phase):
    args.output_dir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=[
            logging.FileHandler(args.output_dir / f"{phase}.log"),
            logging.StreamHandler(),
        ],
    )
    random.seed(args.seed)
    torch.manual_seed(args.seed)
    os.environ["ARENO_BENCH_SEED"] = str(args.seed)
    if args.context < 4 or args.batch < 1 or args.micro_batch < 1:
        raise ValueError("invalid context/batch")
    return logging.getLogger(phase)


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def metadata(args):
    package = Path(areno.__file__).resolve().parent
    sha = hashlib.sha256()
    for path in sorted(package.rglob("*.py")):
        sha.update(str(path.relative_to(package.parent)).encode())
        sha.update(path.read_bytes())
    return {
        "timestamp": datetime.now(UTC).isoformat(),
        "arguments": {
            k: str(v) if isinstance(v, Path) else v for k, v in vars(args).items()
        },
        "source_root": str(package.parent),
        "source_sha256": sha.hexdigest(),
        "torch_version": torch.__version__,
        "cuda_version": torch.version.cuda,
        "gpu": torch.cuda.get_device_name(0),
        "cuda_visible_devices": os.getenv("CUDA_VISIBLE_DEVICES"),
        "cublas_workspace_config": os.getenv("CUBLAS_WORKSPACE_CONFIG"),
        "native_extension_sha256": digest(
            next((package / "accel").glob("_areno_accel*.so"))
        ),
        "cpu_affinity": sorted(os.sched_getaffinity(0)),
        "data_sha256": {
            s: digest(args.data_dir / f"{s}.jsonl")
            for s in ["train", "validation", "test"]
            if (args.data_dir / f"{s}.jsonl").exists()
        },
        "wrapper_sha256": {
            s: digest(ALIAS / s) for s in ["train.py", "eval.py", "common.py"]
        },
        "encoding_policy": "response-reserve-min-half; head-tail-prompt; response-prefix; EOS-if-fit-v1",
        "order_policy": "absolute-cursor-epoch-shuffle-seed-plus-1000003epoch-v1",
        "model_identity": "tied1720574976-parameters; BF16-with-FP32-norms",
        "profiler_policy": "sum-per-microbatch-time-max-per-microbatch-peaks-v1",
    }


def trainer(args, *, resume=False, output=None):
    opt = dict(
        lr=1e-5,
        min_lr=1e-5,
        betas=(0.9, 0.95),
        weight_decay=0.01,
        grad_clip_norm=1.0,
        save_training_state=True,
        resume_training_state=resume,
    )
    if args.optimizer == "adam8":
        opt["adam_8bit"] = True
    if args.optimizer == "galore":
        opt.update(
            galore_rank=args.rank,
            galore_update_proj_gap=args.gap,
            galore_scale=args.scale,
            galore_projector_backend="recycled",
            galore_projector_oversampling=16,
            galore_projector_iterations=1,
            galore_projector_seed=args.seed,
            galore_projector_final_qr=True,
            galore_compact_master=True,
            galore_tile_rows=16384,
            galore_release_gradients=True,
            galore_fused_writeback=True,
            galore_transport_moments=not args.retained,
        )
    runtime = dict(
        attn_backend="native",
        compile_model=False,
        activation_checkpointing=True,
        keep_rollout_state=True,
        profile_training=True,
    )
    extra = json.loads(args.extra_config_json)
    if set(extra) - {"optimizer", "runtime"}:
        raise ValueError("extra config may only contain optimizer/runtime")
    opt.update(extra.get("optimizer", {}))
    runtime.update(extra.get("runtime", {}))
    return Trainer(
        world_size=1,
        model_path=str(args.checkpoint_dir if resume else args.model),
        custom_config=CudaConfig(
            devices=[0], tp_size=1, optimizer=opt, runtime=runtime
        ),
        metrics_log_dir=str((output or args.output_dir) / "events"),
    )


def encode(tokenizer, args, split):
    records = [
        json.loads(line)
        for line in (args.data_dir / f"{split}.jsonl").read_text().splitlines()
    ]
    encoded, stats = (
        [],
        dict(
            rows=len(records),
            prompt_truncated=0,
            response_truncated=0,
            tokens=0,
            targets=0,
        ),
    )
    for record in records:
        if "text" in record:
            tokens = tokenizer.encode(record["text"], add_special_tokens=False)[
                : args.context
            ]
            prompt_len = 1
        else:
            prompt = tokenizer.encode(record["prompt"], add_special_tokens=False)
            response = tokenizer.encode(record["response"], add_special_tokens=False)
            eos = tokenizer.eos_token_id
            if eos is not None and (not response or response[-1] != eos):
                response.append(eos)
            reserve = min(len(response), args.context // 2)
            cap = args.context - max(reserve, 1)
            if len(prompt) > cap:
                left = (cap + 1) // 2
                prompt = (
                    prompt[:left] + prompt[-(cap - left) :]
                    if cap > left
                    else prompt[:left]
                )
                stats["prompt_truncated"] += 1
            if not prompt:
                prompt = [tokenizer.bos_token_id or tokenizer.eos_token_id or 0]
            space = args.context - len(prompt)
            stats["response_truncated"] += int(len(response) > space)
            tokens = prompt + response[:space]
            prompt_len = len(prompt)
        if len(tokens) <= prompt_len:
            raise ValueError("encoding produced a response-free example")
        stats["tokens"] += len(tokens)
        stats["targets"] += len(tokens) - prompt_len
        encoded.append(
            TrainSequence(
                tokens=tokens,
                prompt_len=prompt_len,
                logprobs=[],
                scalar_advantage=1.0,
                reward=0.0,
                eos_token_id=tokenizer.eos_token_id,
            )
        )
    return encoded, stats


def batch_indices(step, seed, size, batch, orders):
    result = []
    for cursor in range(step * batch, (step + 1) * batch):
        epoch, offset = divmod(cursor, size)
        if epoch not in orders:
            order = list(range(size))
            random.Random(seed + 1000003 * epoch).shuffle(order)
            orders[epoch] = order
        result.append(orders[epoch][offset])
    return result


def evaluate(engine, examples, micro_batch):
    total, count = 0.0, 0
    for start in range(0, len(examples), micro_batch):
        batch = examples[start : start + micro_batch]
        scored = engine.score_logprobs(
            "actor", [s.tokens for s in batch], microbatch_size=micro_batch
        )
        for sample, values in zip(batch, scored, strict=True):
            targets = values[sample.prompt_len :]
            if not targets or not all(math.isfinite(v) for v in targets):
                raise ValueError("nonfinite/empty evaluation")
            total -= sum(targets)
            count += len(targets)
    return {"loss": total / count, "target_tokens": count, "examples": len(examples)}
