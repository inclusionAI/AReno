"""Independent stdlib replay of native raw records and frozen provenance."""

import ast
import hashlib
import json
import math
from pathlib import Path
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        while data := stream.read(8 * 1024 * 1024):
            h.update(data)
    return h.hexdigest()


def main():
    manifest_path = ROOT / "PREPARED.json"
    manifest = json.loads(manifest_path.read_text())
    freeze = json.loads((ROOT / "FREEZE.json").read_text())
    assert freeze["parent_approved"] is True
    assert freeze["prepared_sha256"] == digest(manifest_path)
    assert freeze["source_sha256"] == manifest["source_sha256"]
    for name, expected in manifest["files"].items():
        path = ROOT / name
        assert path.stat().st_size == expected["bytes"]
        assert digest(path) == expected["sha256"], name
    for name, expected in manifest["assets"].items():
        assert Path(name).stat().st_size == expected["bytes"]
        assert digest(name) == expected["sha256"], name
    for name, expected in manifest["proofs"].items():
        assert digest(name) == expected, name
    source = hashlib.sha256()
    for path in sorted((ROOT / "repo/areno").rglob("*.py")):
        source.update(str(path.relative_to(ROOT / "repo")).encode())
        source.update(path.read_bytes())
    assert source.hexdigest() == manifest["source_sha256"]
    edge = json.loads((ROOT / "FINAL_CUDA_EDGES.json").read_text())
    correction = json.loads((ROOT / "EDGE_COUNT_CORRECTION.json").read_text())
    tree = ast.parse((ROOT / "check_edges.py").read_text())
    compared_loop = next(
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.For)
        and isinstance(node.target, ast.Tuple)
        and [item.id for item in node.target.elts] == ["x", "y"]
    )
    all_calls = [
        node
        for node in ast.walk(tree)
        if isinstance(node, ast.Call)
        and isinstance(node.func, ast.Name)
        and node.func.id == "bits_equal"
    ]
    assert len(all_calls) == 2 and len(compared_loop.iter.elts) == 4
    assert len(compared_loop.body) == 1
    edge_comparisons = len(edge["cases"]) * (len(compared_loop.iter.elts) + 1)
    assert edge_comparisons == correction["actual_tensor_bit_comparisons"] == 480
    assert (
        correction["reported_tensor_bit_comparisons"]
        == edge["tensor_bit_comparisons"]
        == 576
    )
    assert correction["frozen_result_sha256"] == digest(ROOT / "FINAL_CUDA_EDGES.json")
    assert correction["frozen_script_sha256"] == digest(ROOT / "check_edges.py")
    status = json.loads((ROOT / "STATUS.json").read_text())
    assert (
        status["status"] == "complete"
        and status["active"] == {}
        and status["errors"] == []
    )
    assert len(status["completed"]) == 4
    records = {}
    paths = {}
    common_batches = None
    monitor_count = 0
    for method in manifest["order"]:
        path = ROOT / "outputs" / method
        metadata = json.loads((path / "metadata.json").read_text())
        assert metadata["source_sha256"] == manifest["source_sha256"]
        assert metadata["native_extension_sha256"] == manifest["native_sha256"]
        assert metadata["cuda_visible_devices"] == "2"
        assert type(metadata["arguments"]["scale"]) is float
        assert metadata["arguments"]["scale"] == 1.0
        assert metadata["cpu_affinity"] == [48, 49, 50, 51]
        assert metadata["saved_checkpoints"] is False
        assert metadata["read_validation_or_test"] is False
        assert (
            metadata["authoritative_master_policy"]
            == "strict-fp32-master-compact-lossless"
        )
        rows = [
            json.loads(line) for line in (path / "steps.jsonl").read_text().splitlines()
        ]
        assert len(rows) == 402
        batch_signatures = []
        for index, row in enumerate(rows):
            assert row["step"] == index
            assert row["warmup"] is (index < 2)
            assert row["update_worker_step"] == index + 1
            assert row["update_optimizer_steps"] == 1
            assert bool(row["update_refresh_any"]) is (index % 200 == 0)
            assert row["optimizer_deferred_projection_enabled"] == 1
            assert row["optimizer_fused_scale_writeback_enabled"] == int(
                method.startswith("candidate")
            )
            assert row["optimizer_model_owned_master_enabled"] == 0
            assert row["galore_master_bytes"] > 0
            assert row["logp_abs_diff_mean"] == 0 and math.isfinite(row["loss"])
            assert row["deferred_owner_count"] == 226
            assert row["deferred_barrier_versions_unchanged"] == 1
            assert row["deferred_full_leaf_bytes_after_backward"] == 0
            assert row["deferred_cache_empty_after_step"] == 1
            assert row["sft_total_target_tokens"] == row["target_tokens"] > 0
            assert (
                row["sft_pack_count"]
                == row["sft_dp_shards_per_pack"]
                == row["sft_grad_scale"]
                == 1
            )
            batch_signatures.append(
                (row["sample_indices"], row["batch_sha256"], row["target_tokens"])
            )
        if common_batches is None:
            common_batches = batch_signatures
        else:
            assert batch_signatures == common_batches
        measured = rows[2:]
        assert [row["step"] for row in measured if row["update_refresh_any"]] == [
            200,
            400,
        ]
        wall = sum(row["score_plus_train_seconds"] for row in measured) / 400
        allocated = max(row["update_peak_allocated_bytes"] for row in measured)
        records[method] = dict(
            whole_seconds=wall,
            allocated_bytes=allocated,
            reserved_bytes=max(row["update_peak_reserved_bytes"] for row in measured),
            optimizer_seconds=sum(row["update_optimizer_time_s"] for row in measured)
            / 400,
        )
        samples = [
            json.loads(line)
            for line in (path / "monitor.jsonl").read_text().splitlines()
        ]
        assert samples
        for sample in samples:
            assert sample["foreign_pids"] == []
            assert sample["free_disk_bytes"] >= 8 * 1024**3
            assert manifest["uuid"] in sample["gpu"]
        monitor_count += len(samples)
        assert not (ROOT / "unused-checkpoints" / method).exists()
        for output in path.rglob("*"):
            if output.is_file():
                paths[str(output.relative_to(ROOT))] = dict(
                    bytes=output.stat().st_size, sha256=digest(output)
                )
    pairs = []
    for control, candidate in (
        ("strict_first", "candidate_first"),
        ("strict_second", "candidate_second"),
    ):
        a, b = records[control], records[candidate]
        speed = (b["whole_seconds"] / a["whole_seconds"] - 1) * 100
        memory = b["allocated_bytes"] - a["allocated_bytes"]
        pairs.append(
            dict(
                control=control,
                candidate=candidate,
                whole_change_percent=speed,
                allocated_change_bytes=memory,
                speed_gate_passed=speed <= -1,
                memory_gate_passed=memory <= 0,
            )
        )
    passed = all(
        pair["speed_gate_passed"] and pair["memory_gate_passed"] for pair in pairs
    )
    analysis = json.loads((ROOT / "ANALYSIS.json").read_text())
    assert analysis["research_gate_passed"] is passed
    assert analysis["pairs"] == pairs and analysis["methods"] == records
    result = dict(
        status="independent_raw_audit_passed",
        timestamp=datetime.now(timezone.utc).isoformat(),
        source_sha256=source.hexdigest(),
        manifest_sha256=digest(manifest_path),
        frozen_files=len(manifest["files"]),
        assets=len(manifest["assets"]),
        proofs=len(manifest["proofs"]),
        raw_updates=1608,
        paired_steps=402,
        monitor_samples=monitor_count,
        methods=records,
        pairs=pairs,
        research_gate_passed=passed,
        registered_scale_python_type="float",
        scalar_typing_limit="Frozen kernel only qualified for registered ordinaryfloat scales; int/extreme scalar typing needs separate root fix before generic promotion",
        actual_cuda_edge_tensor_comparisons=edge_comparisons,
        edge_count_correction_sha256=digest(ROOT / "EDGE_COUNT_CORRECTION.json"),
        no_quality_measurement=True,
        compared_with_8bit=False,
        outputs=paths,
    )
    (ROOT / "AUDIT.json").write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps({key: value for key, value in result.items() if key != "outputs"}),
        flush=True,
    )


if __name__ == "__main__":
    main()
