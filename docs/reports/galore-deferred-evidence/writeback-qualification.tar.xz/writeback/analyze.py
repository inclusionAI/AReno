"""Pure stdlib prospective ABBA paired whole-call decision; no runtime imports."""

import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
METHODS = ("strict_first", "candidate_first", "candidate_second", "strict_second")


def analyze(root=ROOT):
    loaded = {}
    for name in METHODS:
        out = root / "outputs" / name
        rows = [
            json.loads(line) for line in (out / "steps.jsonl").read_text().splitlines()
        ]
        assert len(rows) == 402
        expected = int(name.startswith("candidate"))
        for i, r in enumerate(rows):
            assert r["step"] == i and r["warmup"] == (i < 2)
            assert r["update_worker_step"] == i + 1 and r["update_optimizer_steps"] == 1
            assert r["update_refresh_any"] == float(i % 200 == 0)
            assert r["optimizer_fused_scale_writeback_enabled"] == expected
            assert r["optimizer_deferred_projection_enabled"] == 1
            assert (
                r["optimizer_model_owned_master_enabled"] == 0
                and r["galore_master_bytes"] > 0
            )
            assert r["logp_abs_diff_mean"] == 0 and math.isfinite(r["loss"])
            assert (
                r["deferred_owner_count"] == 226
                and r["deferred_full_leaf_bytes_after_backward"] == 0
            )
            assert (
                r["deferred_cache_empty_after_step"] == 1
                and r["deferred_barrier_versions_unchanged"] == 1
            )
        for name2, ref in loaded.items():
            for a, b in zip(rows, ref["rows"], strict=True):
                for key in (
                    "sample_indices",
                    "batch_sha256",
                    "target_tokens",
                    "sft_total_target_tokens",
                    "sft_grad_scale",
                ):
                    assert a[key] == b[key], (name, name2, key)
        measured = rows[2:]
        assert [r["step"] for r in measured if r["update_refresh_any"]] == [200, 400]
        loaded[name] = dict(
            rows=rows,
            whole_seconds=sum(r["score_plus_train_seconds"] for r in measured) / 400,
            allocated_bytes=max(r["update_peak_allocated_bytes"] for r in measured),
            reserved_bytes=max(r["update_peak_reserved_bytes"] for r in measured),
            optimizer_seconds=sum(r["update_optimizer_time_s"] for r in measured) / 400,
        )
    pairs = []
    for control, candidate in (
        ("strict_first", "candidate_first"),
        ("strict_second", "candidate_second"),
    ):
        a, b = loaded[control], loaded[candidate]
        change = (b["whole_seconds"] / a["whole_seconds"] - 1) * 100
        pairs.append(
            dict(
                control=control,
                candidate=candidate,
                whole_change_percent=change,
                allocated_change_bytes=b["allocated_bytes"] - a["allocated_bytes"],
                speed_gate_passed=change <= -1,
                memory_gate_passed=b["allocated_bytes"] <= a["allocated_bytes"],
            )
        )
    return dict(
        status="valid_completed",
        methods={
            k: {a: b for a, b in v.items() if a != "rows"} for k, v in loaded.items()
        },
        pairs=pairs,
        raw_updates=1608,
        paired_steps=402,
        research_gate_passed=all(
            p["speed_gate_passed"] and p["memory_gate_passed"] for p in pairs
        ),
        compared_with_8bit=False,
        quality_measured=False,
    )


if __name__ == "__main__":
    result = analyze()
    (ROOT / "ANALYSIS.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)
