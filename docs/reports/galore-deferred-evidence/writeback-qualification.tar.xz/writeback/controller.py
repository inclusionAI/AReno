"""Parent-reviewed single-GPU ABBA with UUID exclusion and owned birth watchdog."""

import fcntl
import json
import os
import signal
import shutil
import subprocess
import sys
import time

import psutil

from contract import ROOT, PROJECT, now, verify, write

GPU = 2
UUID = "GPU-833bb0e5-2efb-bd4f-8f7f-21f792359487"
STATE = dict(
    status="starting",
    pid=os.getpid(),
    birth=psutil.Process().create_time(),
    active={},
    completed=[],
    errors=[],
)
STOP = False


def save():
    STATE["heartbeat"] = now()
    write(ROOT / "STATUS.json", STATE)


def query(*args):
    return subprocess.check_output(
        ["nvidia-smi", *args, "--format=csv,noheader,nounits"], text=True
    )


def owned(p, birth):
    try:
        return (
            psutil.Process(p.pid).create_time() == birth and os.getpgid(p.pid) == p.pid
        )
    except (ProcessLookupError, psutil.NoSuchProcess):
        return False


def stop(*_):
    global STOP
    STOP = True


def main():
    manifest = verify()
    assert not (ROOT / "outputs").exists()
    assert shutil.disk_usage(ROOT).free >= 9 * 1024**3
    signal.signal(signal.SIGINT, stop)
    signal.signal(signal.SIGTERM, stop)
    p = None
    birth = None
    with (
        (ROOT / "run.lock").open("a+") as ownlock,
        (PROJECT / "runs/gpu2.lock").open("a+") as devlock,
    ):
        fcntl.flock(ownlock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        fcntl.flock(devlock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert not any(
            line.startswith(UUID)
            for line in query(
                "--query-compute-apps=gpu_uuid,pid,used_memory"
            ).splitlines()
        )
        STATE["status"] = "running"
        save()
        watchdog = subprocess.Popen(
            [
                sys.executable,
                str(ROOT / "watchdog.py"),
                str(os.getpid()),
                str(STATE["birth"]),
            ],
            start_new_session=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        write(
            ROOT / "WATCHDOG.json",
            dict(pid=watchdog.pid, parent=os.getpid(), timestamp=now()),
        )
        try:
            for method in (
                "strict_first",
                "candidate_first",
                "candidate_second",
                "strict_second",
            ):
                verify()
                assert not STOP
                assert not any(
                    line.startswith(UUID)
                    for line in query(
                        "--query-compute-apps=gpu_uuid,pid,used_memory"
                    ).splitlines()
                )
                out = ROOT / "outputs" / method
                out.mkdir(parents=True, exist_ok=False)
                argv = [
                    "taskset",
                    "-c",
                    "48-51",
                    sys.executable,
                    str(ROOT / "train.py"),
                    "--data-dir",
                    str(PROJECT / "runs/experiments/overnight_20261029_data/data"),
                    "--checkpoint-dir",
                    str(ROOT / "unused-checkpoints" / method),
                    "--output-dir",
                    str(out),
                    "--model",
                    manifest["model_path"],
                    "--optimizer",
                    "galore",
                    "--seed",
                    "0",
                    "--context",
                    "512",
                    "--batch",
                    "4",
                    "--micro-batch",
                    "4",
                    "--rank",
                    "128",
                    "--gap",
                    "200",
                    "--scale",
                    "1",
                    "--extra-config-json",
                    '{"optimizer":{"galore_exclude_vocab":false}}',
                ]
                env = os.environ.copy()
                for k in list(env):
                    if k.startswith("ARENO_EXPERIMENT_"):
                        del env[k]
                env.pop("CUBLAS_WORKSPACE_CONFIG", None)
                env.update(
                    CUDA_VISIBLE_DEVICES="2",
                    PYTHONPATH=str(ROOT / "repo"),
                    ARENO_BENCH_SEED="0",
                    ARENO_EXPERIMENT_DEFERRED_PROJECTION="1",
                    ARENO_EXPERIMENT_FUSED_SCALE_WRITEBACK=str(
                        int(method.startswith("candidate"))
                    ),
                    ARENO_CONFIRM_CONTROLLER_PID=str(os.getpid()),
                    OMP_NUM_THREADS="4",
                    MKL_NUM_THREADS="4",
                    OPENBLAS_NUM_THREADS="4",
                )
                write(
                    out / "launch.json",
                    dict(
                        argv=argv,
                        timestamp=now(),
                        gpu_uuid=UUID,
                        env={
                            k: env[k]
                            for k in (
                                "CUDA_VISIBLE_DEVICES",
                                "PYTHONPATH",
                                "ARENO_EXPERIMENT_DEFERRED_PROJECTION",
                                "ARENO_EXPERIMENT_FUSED_SCALE_WRITEBACK",
                            )
                        },
                    ),
                )
                with (
                    (out / "launcher.log").open("x") as log,
                    (out / "monitor.jsonl").open("x") as mon,
                ):
                    p = subprocess.Popen(
                        argv,
                        env=env,
                        stdout=log,
                        stderr=subprocess.STDOUT,
                        start_new_session=True,
                    )
                    parent = psutil.Process(p.pid)
                    birth = parent.create_time()
                    start = time.monotonic()
                    STATE["active"] = {
                        "2": dict(pid=p.pid, birth=birth, method=method, children=[])
                    }
                    save()
                    while p.poll() is None:
                        raw = query("--query-compute-apps=gpu_uuid,pid,used_memory")
                        foreign = []
                        family = []
                        for proc in [parent] + parent.children(recursive=True):
                            try:
                                family.append(
                                    dict(
                                        pid=proc.pid,
                                        birth=proc.create_time(),
                                        rss=proc.memory_info().rss,
                                    )
                                )
                            except psutil.NoSuchProcess:
                                pass
                        for line in raw.splitlines():
                            c = [v.strip() for v in line.split(",")]
                            if c[0] != UUID:
                                continue
                            try:
                                if os.getpgid(int(c[1])) != p.pid:
                                    foreign.append(int(c[1]))
                            except ProcessLookupError:
                                pass
                        free = shutil.disk_usage(ROOT).free
                        sample = dict(
                            timestamp=now(),
                            apps=raw,
                            foreign_pids=foreign,
                            free_disk_bytes=free,
                            processes=family,
                            gpu=query(
                                "--query-gpu=index,uuid,memory.used,utilization.gpu,power.draw,clocks.sm,clocks.mem",
                                "--id=2",
                            ),
                        )
                        mon.write(json.dumps(sample) + "\n")
                        mon.flush()
                        STATE["active"]["2"]["children"] = family[1:]
                        save()
                        assert (
                            not foreign
                            and free >= 8 * 1024**3
                            and not STOP
                            and time.monotonic() - start < 900
                        ), sample
                        time.sleep(1)
                    assert p.returncode == 0, (method, p.returncode)
                STATE["completed"].append(
                    dict(method=method, return_code=p.returncode, timestamp=now())
                )
                STATE["active"] = {}
                save()
                p = None
            verify()
            subprocess.run([sys.executable, str(ROOT / "analyze.py")], check=True)
            STATE["status"] = "complete"
            STATE["research_gate_passed"] = json.loads(
                (ROOT / "ANALYSIS.json").read_text()
            )["research_gate_passed"]
            save()
        except BaseException as e:
            STATE["status"] = "execution_failed"
            STATE["errors"].append(repr(e))
            save()
            raise
        finally:
            if p is not None and p.poll() is None and owned(p, birth):
                os.killpg(p.pid, signal.SIGTERM)
                try:
                    p.wait(10)
                except subprocess.TimeoutExpired:
                    if owned(p, birth):
                        os.killpg(p.pid, signal.SIGKILL)
                    p.wait()


if __name__ == "__main__":
    main()
