"""Bounded owned-process CUDA gate on GPU2; no model/data/checkpoint access."""

import fcntl
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

import psutil

ROOT = Path(__file__).resolve().parent
UUID = "GPU-833bb0e5-2efb-bd4f-8f7f-21f792359487"


def apps():
    return subprocess.check_output(
        [
            "nvidia-smi",
            "--query-compute-apps=gpu_uuid,pid,used_memory",
            "--format=csv,noheader,nounits",
        ],
        text=True,
    )


def main():
    records = []
    with open("/mnt2/ling/areno-galore/runs/gpu2.lock", "a+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert not any(line.startswith(UUID) for line in apps().splitlines())
        assert shutil.disk_usage(ROOT).free >= 9 * 1024**3
        for script, output in (
            ("check_exact.py", "FINAL_CUDA_EXACT.json"),
            ("check_edges.py", "FINAL_CUDA_EDGES.json"),
        ):
            assert not (ROOT / output).exists()
            env = os.environ.copy()
            env.update(
                CUDA_VISIBLE_DEVICES="2",
                PYTHONPATH=str(ROOT / "repo"),
                OMP_NUM_THREADS="4",
                MKL_NUM_THREADS="4",
                OPENBLAS_NUM_THREADS="4",
            )
            p = None
            birth = None
            try:
                with (
                    (ROOT / (output + ".log")).open("x") as log,
                    (ROOT / (output + ".monitor.jsonl")).open("x") as monitor,
                ):
                    p = subprocess.Popen(
                        [
                            "taskset",
                            "-c",
                            "48-51",
                            sys.executable,
                            str(ROOT / script),
                            *(
                                ["--device", "cuda"]
                                if script == "check_exact.py"
                                else []
                            ),
                            "--output",
                            str(ROOT / output),
                        ],
                        env=env,
                        stdout=log,
                        stderr=subprocess.STDOUT,
                        start_new_session=True,
                    )
                    birth = psutil.Process(p.pid).create_time()
                    start = time.monotonic()
                    while p.poll() is None:
                        raw = apps()
                        foreign = []
                        for line in raw.splitlines():
                            cols = [v.strip() for v in line.split(",")]
                            if cols[0] != UUID:
                                continue
                            try:
                                if os.getpgid(int(cols[1])) != p.pid:
                                    foreign.append(int(cols[1]))
                            except ProcessLookupError:
                                pass
                        free = shutil.disk_usage(ROOT).free
                        monitor.write(
                            json.dumps(
                                dict(
                                    time=time.time(),
                                    apps=raw,
                                    foreign_pids=foreign,
                                    free_disk_bytes=free,
                                    pid=p.pid,
                                    birth=birth,
                                )
                            )
                            + "\n"
                        )
                        monitor.flush()
                        assert (
                            not foreign
                            and free >= 8 * 1024**3
                            and time.monotonic() - start < 300
                        )
                        time.sleep(1)
                    records.append(dict(output=output, return_code=p.returncode))
                    assert p.returncode == 0
                    result = json.loads((ROOT / output).read_text())
                    assert result["status"] == "passed"
                    if script == "check_exact.py":
                        assert result["device"] == "cuda"
            finally:
                if (
                    p is not None
                    and p.poll() is None
                    and psutil.Process(p.pid).create_time() == birth
                ):
                    os.killpg(p.pid, signal.SIGTERM)
                    try:
                        p.wait(10)
                    except subprocess.TimeoutExpired:
                        os.killpg(p.pid, signal.SIGKILL)
                        p.wait()
    (ROOT / "FINAL_NUMERICAL_RESULT.json").write_text(
        json.dumps(dict(status="passed", commands=records), indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
