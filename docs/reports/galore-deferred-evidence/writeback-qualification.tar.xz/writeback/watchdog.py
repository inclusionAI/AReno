"""If the detached controller disappears, terminate only registered own groups."""

from __future__ import annotations

import json
import os
import signal
import sys
import time

import psutil

from contract import ROOT, now, write


def matching(pid, birth):
    try:
        return abs(psutil.Process(pid).create_time() - birth) < 0.01
    except psutil.NoSuchProcess:
        return False


def owns_group(record):
    for member in [record, *record.get("children", [])]:
        if matching(member["pid"], member["birth"]):
            try:
                if os.getpgid(member["pid"]) == record["pid"]:
                    return True
            except ProcessLookupError:
                pass
    return False


def main():
    parent, birth = int(sys.argv[1]), float(sys.argv[2])
    while matching(parent, birth):
        time.sleep(2)
    status_path = ROOT / "STATUS.json"
    status = json.loads(status_path.read_text()) if status_path.exists() else {}
    killed = []
    for record in status.get("active", {}).values():
        pid = record["pid"]
        # An actual recorded process and create time must still identify the
        # group. Never infer ownership from a device occupancy alone.
        if owns_group(record):
            try:
                os.killpg(pid, signal.SIGTERM)
                killed.append(pid)
            except ProcessLookupError:
                pass
    if killed:
        time.sleep(5)
        for record in status.get("active", {}).values():
            pid = record["pid"]
            if pid not in killed or not owns_group(record):
                continue
            try:
                os.killpg(pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
    write(
        ROOT / "WATCHDOG_EXIT.json",
        {
            "timestamp": now(),
            "parent_status": status.get("status"),
            "terminated_owned_groups": killed,
        },
    )


if __name__ == "__main__":
    main()
