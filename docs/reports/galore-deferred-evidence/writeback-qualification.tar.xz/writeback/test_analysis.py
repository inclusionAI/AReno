"""Test that the prospective decision cannot promote one favorable order pair."""

import json

import pytest

from analyze import METHODS, analyze


def prepare(tmp_path, wall=None, memory=None):
    wall = wall or (1.0, 0.98, 0.98, 1.0)
    memory = memory or (100, 100, 100, 100)
    for index, name in enumerate(METHODS):
        out = tmp_path / "outputs" / name
        out.mkdir(parents=True)
        rows = []
        for step in range(402):
            rows.append(
                dict(
                    step=step,
                    warmup=step < 2,
                    update_worker_step=step + 1,
                    update_optimizer_steps=1,
                    update_refresh_any=float(step % 200 == 0),
                    optimizer_fused_scale_writeback_enabled=int(
                        name.startswith("candidate")
                    ),
                    optimizer_deferred_projection_enabled=1,
                    optimizer_model_owned_master_enabled=0,
                    galore_master_bytes=1,
                    logp_abs_diff_mean=0,
                    loss=1.0,
                    deferred_owner_count=226,
                    deferred_full_leaf_bytes_after_backward=0,
                    deferred_cache_empty_after_step=1,
                    deferred_barrier_versions_unchanged=1,
                    sample_indices=[step],
                    batch_sha256=str(step),
                    target_tokens=1,
                    sft_total_target_tokens=1,
                    sft_grad_scale=1,
                    score_plus_train_seconds=wall[index],
                    update_peak_allocated_bytes=memory[index],
                    update_peak_reserved_bytes=1000,
                    update_optimizer_time_s=0.1,
                )
            )
        (out / "steps.jsonl").write_text("".join(json.dumps(r) + "\n" for r in rows))


def test_two_order_pairs_both_required(tmp_path):
    prepare(tmp_path, wall=(1, 0.98, 1.01, 1))
    result = analyze(tmp_path)
    assert result["pairs"][0]["speed_gate_passed"]
    assert not result["pairs"][1]["speed_gate_passed"]
    assert not result["research_gate_passed"]


def test_allocated_even_one_byte_increase_rejected(tmp_path):
    prepare(tmp_path, memory=(100, 100, 101, 100))
    assert not analyze(tmp_path)["research_gate_passed"]


def test_both_speed_and_memory_pass(tmp_path):
    prepare(tmp_path)
    assert analyze(tmp_path)["research_gate_passed"]


@pytest.mark.parametrize(
    "field,value",
    [
        ("batch_sha256", "wrong"),
        ("update_refresh_any", 0),
        ("optimizer_fused_scale_writeback_enabled", 0),
    ],
)
def test_unpaired_or_wrong_runtime_rejected(tmp_path, field, value):
    prepare(tmp_path)
    p = tmp_path / "outputs/candidate_first/steps.jsonl"
    rows = [json.loads(r) for r in p.read_text().splitlines()]
    rows[200][field] = value
    p.write_text("".join(json.dumps(r) + "\n" for r in rows))
    with pytest.raises(AssertionError):
        analyze(tmp_path)
