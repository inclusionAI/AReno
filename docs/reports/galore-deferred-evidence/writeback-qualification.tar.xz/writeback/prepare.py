"""Bind final source, protocol, numerical proofs and inherited model/train inputs."""

import hashlib
import json
from pathlib import Path

from contract import ROOT, sha, now, write


def source_hash():
    h = hashlib.sha256()
    for p in sorted((ROOT / "repo/areno").rglob("*.py")):
        h.update(str(p.relative_to(ROOT / "repo")).encode())
        h.update(p.read_bytes())
    return h.hexdigest()


def main():
    assert not (ROOT / "PREPARED.json").exists()
    original = json.loads(
        Path(
            "/mnt2/ling/areno-galore/runs/deferred_scale_confirm_20261030/PREPARED.json"
        ).read_text()
    )
    cpu = json.loads((ROOT / "FINAL_CPU_EXACT.json").read_text())
    cuda = json.loads((ROOT / "FINAL_CUDA_EXACT.json").read_text())
    edges = json.loads((ROOT / "FINAL_CUDA_EDGES.json").read_text())
    source = source_hash()
    assert cpu["status"] == cuda["status"] == edges["status"] == "passed"
    assert cpu["source_sha256"] == cuda["source_sha256"] == source
    assert len(cpu["cases"]) == len(cuda["cases"]) == 24 and len(edges["cases"]) == 96
    checks = []
    for device, result in (("CPU", cpu), ("CUDA", cuda)):
        old = json.loads((ROOT / f"FINAL_{device}_80A_DEFAULT_OFF.json").read_text())
        assert old["source_sha256"] == original["source_sha256"]
        assert len(old["cases"]) == 24
        for a, b in zip(old["cases"], result["cases"], strict=True):
            for key in (
                "dtype",
                "scale",
                "tile_rows",
                "clip",
                "device",
                "updates",
                "default_off_step_hashes",
            ):
                assert a[key] == b[key], (device, key)
        checks.append(dict(device=device, cases=24, step_hashes=288, status="exact"))
    write(
        ROOT / "DEFAULT_OFF_COMPARISON.json",
        dict(
            status="passed",
            checks=checks,
            original_source_sha256=original["source_sha256"],
            candidate_source_sha256=source,
        ),
    )
    files = {}
    paths = (
        list((ROOT / "repo/areno").rglob("*.py"))
        + list(ROOT.glob("*.py"))
        + [
            ROOT / "PLAN.md",
            ROOT / "CHANGES.md",
            ROOT / "MODEL_MANIFEST.json",
            ROOT / "META_MODEL_EXPECTATION.json",
        ]
    )
    for p in sorted(paths):
        files[str(p.relative_to(ROOT))] = dict(bytes=p.stat().st_size, sha256=sha(p))
    proofs = {
        str(ROOT / p): sha(ROOT / p)
        for p in (
            "FINAL_CPU_EXACT.json",
            "FINAL_CUDA_EXACT.json",
            "FINAL_CUDA_EDGES.json",
            "FINAL_CPU_80A_DEFAULT_OFF.json",
            "FINAL_CUDA_80A_DEFAULT_OFF.json",
            "FINAL_NUMERICAL_RESULT.json",
            "ORIGINAL_CUDA_RESULT.json",
            "DEFAULT_OFF_COMPARISON.json",
            "scaffold.log",
            "lint-final.log",
        )
    }
    assets = original["assets"].copy()
    native = next((ROOT / "repo/areno/accel").glob("_areno_accel*.so"))
    assets[str(native)] = dict(bytes=native.stat().st_size, sha256=sha(native))
    assert sha(native) == original["native_sha256"]
    for p, expected in assets.items():
        assert (
            Path(p).stat().st_size == expected["bytes"] and sha(p) == expected["sha256"]
        ), p
    m = {
        k: original[k]
        for k in (
            "model_path",
            "model_revision",
            "model_asset_manifest_sha256",
            "train_sha256",
            "native_sha256",
            "software",
            "python",
            "torch_runtime",
            "cuda_runtime",
            "dataset_revision",
        )
    }
    m.update(
        status="prepared_not_started",
        timestamp=now(),
        source_sha256=source,
        original_source_sha256=original["source_sha256"],
        files=files,
        proofs=proofs,
        assets=assets,
        gpu=2,
        uuid="GPU-833bb0e5-2efb-bd4f-8f7f-21f792359487",
        cpus="48-51",
        order=["strict_first", "candidate_first", "candidate_second", "strict_second"],
        workload=dict(
            seed=0,
            context=512,
            batch=4,
            micro_batch=4,
            rank=128,
            gap=200,
            scale=1,
            lr=1e-5,
            warmup_updates=2,
            measured_updates=400,
            measured_refresh_steps=[200, 400],
        ),
        gate=dict(
            whole_speedup_min_percent=1,
            allocated_increase_max_bytes=0,
            both_order_pairs_required=True,
            not_official_acceptance_threshold=True,
        ),
        quality_measured=False,
        checkpoint_saved=False,
        validation_or_test_opened=False,
        estimated_wall_minutes=[15, 20],
    )
    write(ROOT / "PREPARED.json", m)
    print(
        json.dumps(
            dict(
                status=m["status"],
                source_sha256=source,
                files=len(files),
                assets=len(assets),
                proofs=len(proofs),
            )
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
