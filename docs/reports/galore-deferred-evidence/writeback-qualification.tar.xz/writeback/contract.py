"""Immutable source, input and numerical-proof checks for this single experiment."""

import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROJECT = Path("/mnt2/ling/areno-galore")


def now():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(8 * 1024**2), b""):
            h.update(block)
    return h.hexdigest()


def write(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + f".{os.getpid()}.tmp")
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")
    tmp.replace(path)


def verify(approved=True, assets=True):
    m = json.loads((ROOT / "PREPARED.json").read_text())
    if approved:
        a = json.loads((ROOT / "FREEZE.json").read_text())
        assert a["parent_approved"] is True
        assert a["prepared_sha256"] == sha(ROOT / "PREPARED.json")
        assert a["source_sha256"] == m["source_sha256"]
    for name, expected in m["files"].items():
        p = ROOT / name
        assert p.stat().st_size == expected["bytes"] and sha(p) == expected["sha256"], (
            name
        )
    for name, expected in m["proofs"].items():
        assert sha(name) == expected, name
    if assets:
        for name, expected in m["assets"].items():
            p = Path(name)
            assert (
                p.stat().st_size == expected["bytes"] and sha(p) == expected["sha256"]
            ), name
    return m
