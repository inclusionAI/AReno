# Scalar-safe optional fused-scale writeback

This separate fork preserves the original frozen `writeback` experiment. Its
runtime is `337c7612282e8fc5254d890ac7659c88c2f38a8e8430d5b3cdc84f6dc96b28b8`.
Exactly compact_writeback.py and deferred_projection.py differ from strict80a
and from the original fusion candidate. No delivery code was modified here.

A guarded GPU1 test reproduced incorrect output for Python integer `scale=1`
in the original fusion candidate. Triton passed integer bits directly into an
FP32 inline-assembly operand. The original failing test/log remains retained.

The repair explicitly casts the inline operand to FP32 before `mul.rn.f32`.
At optimizer construction only, fusion is limited to builtin positive finite
float/int/bool values with integers below 2**64. Other constructor-accepted scalar
objects and oversized integers follow unchanged PyTorch multiplication, retaining
its output and conversion exceptions. This adds no per-update eligibility check.

Fresh GPU checks pass: 24 original full-optimizer cases, 28 additional scalar
full-optimizer cases (18,872 exact tensor comparisons), 96 original edge cases
(480 actual comparisons; the inherited helper's 576 label remains disclosed),
32 initial scalar edge regressions, 6 scalar fallback cases, and 12 independent
reference cases. Six independent BF16 compact reference cases actually use the
repaired fused path; FP32 cases and CPU checks exercise fallback. The final
portable pytest file passes all 67 cases, including full optimizer refresh and
cross-flag resume. These cases overlap scientifically and are not summed as
independent replications.

The original and repaired normal-scale controls have exact CPU/CUDA default-off
snapshot identity to strict80a: 24 cases and 288 snapshots per device. Huge finite
float 1e300 converts to FP32 infinity in original PyTorch multiplication; isolated
fresh-process tests show both branches raise the original compact nonfinite
assertion. The original kernel already writes before that assertion; neither
branch promises rollback. Oversized integer conversion failures preserve state
and model equivalence to the original path, including its existing partial-step
semantics.

For normal float scales 1.0/1.3/.1, target SM80 kernel executable PTX, declarations,
operands and branches are identical for both terminal-tail and actual aligned
tile signatures. Only source pathname/line/debug-offset metadata, comments and
whitespace are excluded explicitly. Full original PTX and the initial differing
debug-inclusive comparison are retained. This supports a scoped kernel bridge to
the unchanged frozen ABBA; it is not a new complete performance measurement or a
claim that the final runtime is byte-identical to strict80a.

All GPU checks used GPU1, CPU40-43, the shared lock, UUID foreign-PID exclusion,
owned-process/birth-time timeouts and root disk guards. No foreign PID was found.
No native build, install, new native timing/quality run, or external write occurred.
GPU1 is released. Parent decides whether ABBA qualifies this optional flag.

`SCALARFIX_ACCEPTANCE.json` binds all runtime hashes, detailed results and proof
files. `test_fused_scale_writeback_cuda.py` is the standalone portable test file
ready for parent integration. Source and proofs are frozen at handoff.
