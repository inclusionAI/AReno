"""Capture compiled target kernel PTX without a native training run."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

import torch


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--aligned-warmup", action="store_true")
    args = parser.parse_args()
    sys.path.insert(0, str(args.source))
    from areno.engine.optim.compact_writeback import _writeback, compact_writeback
    from areno.engine.optim.galore import GaLoreAdamW

    args.output.mkdir(exist_ok=True)
    records = []
    for scale in (1.0, 1.3, 0.1):
        original = torch.linspace(-0.5, 0.5, 1025, device="cuda")
        model, storage = GaLoreAdamW._checked_encode(original)
        update = torch.ones_like(original)
        invalid = torch.zeros((), device="cuda", dtype=torch.int32)
        compact_writeback(model, storage, update, 0, 1 - 1e-5 * 0.01, -1e-5, invalid, scale=scale)
        torch.cuda.synchronize()
        if args.aligned_warmup:
            kernel = _writeback.warmup(
                model, storage.low_bits, storage.round_up_bits, update, invalid,
                33554432, 1 - 1e-5 * 0.01, -1e-5, SCALE=scale, BLOCK=1024,
                grid=(32768,), enable_fp_fusion=False,
            )
        else:
            kernels = list(_writeback.cache[torch.cuda.current_device()].values())
            kernel = kernels[-1]
        ptx = kernel.asm["ptx"]
        # Only file/line debug directives, comments and whitespace are ignored;
        # every remaining instruction, operand, branch and declaration remains.
        cleaned = []
        for line in ptx.splitlines():
            line = line.split("//", 1)[0].strip()
            if line.startswith((".file", ".loc")) or not line:
                continue
            cleaned.append(re.sub(r"\s+", " ", line))
        normalized = "\n".join(cleaned) + "\n"
        label = str(scale).replace(".", "_")
        (args.output / (label + ".ptx")).write_text(ptx)
        (args.output / (label + ".normalized.ptx")).write_text(normalized)
        records.append({"scale": scale, "ptx_sha256": hashlib.sha256(ptx.encode()).hexdigest(),
                        "normalized_sha256": hashlib.sha256(normalized.encode()).hexdigest(),
                        "source": str(args.source), "kernel_metadata": str(kernel.metadata),
                        "invalid": int(invalid), "instructions_include_mul_rn": "mul.rn.f32" in ptx})
    (args.output / "CAPTURE.json").write_text(json.dumps(records, indent=2) + "\n")
    print(json.dumps({"status": "passed", "captures": len(records)}), flush=True)


if __name__ == "__main__":
    main()
