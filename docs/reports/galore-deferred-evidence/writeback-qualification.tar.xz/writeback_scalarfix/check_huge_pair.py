"""Compare original/fused nonfinite failure in isolated CUDA contexts."""

import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
cases = []
for flag in (0, 1):
    env = os.environ.copy()
    env["CUDA_LAUNCH_BLOCKING"] = "1"
    command = [sys.executable, str(root / "check_huge_float_failure.py"), "--flag", str(flag)]
    result = subprocess.run(command, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=60)
    (root / ("huge-float-flag" + str(flag) + ".log")).write_text(result.stdout)
    assert result.returncode != 0
    assert "nonfinite or unsupported compact writeback" in result.stdout, result.stdout
    assert "'scalar_mul': inf" in result.stdout
    cases.append({"flag": flag, "return_code": result.returncode,
                  "same_original_assertion": True, "torch_scalar_conversion": "FP32 infinity"})
(root / "HUGE_FLOAT_EXCEPTION_EQUIVALENCE.json").write_text(json.dumps({
    "status": "passed", "cases": cases,
    "limit": "Original compact implementation writes before asynchronous assertion; neither branch promises rollback",
}, indent=2) + "\n")
print(json.dumps({"status": "passed", "cases": len(cases)}), flush=True)
