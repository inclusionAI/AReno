"""Same-input exact identity-scale elision across real optimizer steps."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
from datetime import datetime, timezone
from pathlib import Path

import torch
import areno

from areno.engine.optim.galore import GaLoreAdamW

FLAG = "ARENO_EXPERIMENT_FUSED_SCALE_WRITEBACK"


def exact(a, b):
    if isinstance(a, torch.Tensor):
        assert a.shape == b.shape and a.dtype == b.dtype
        assert torch.equal(
            a.detach().cpu().contiguous().reshape(-1).view(torch.uint8),
            b.detach().cpu().contiguous().reshape(-1).view(torch.uint8),
        )
        return 1
    if isinstance(a, dict):
        assert a.keys() == b.keys()
        return sum(exact(a[k], b[k]) for k in a)
    if isinstance(a, (list, tuple)):
        assert type(a) is type(b) and len(a) == len(b)
        return sum(exact(x, y) for x, y in zip(a, b, strict=True))
    assert a == b
    return 0


def snapshot_hash(value):
    h = hashlib.sha256()

    def visit(item):
        if isinstance(item, torch.Tensor):
            h.update(str((str(item.dtype), tuple(item.shape))).encode())
            h.update(
                item.detach()
                .cpu()
                .contiguous()
                .reshape(-1)
                .view(torch.uint8)
                .numpy()
                .tobytes()
            )
        elif isinstance(item, dict):
            for key, v in item.items():
                h.update(str(key).encode())
                visit(v)
        elif isinstance(item, (list, tuple)):
            for v in item:
                visit(v)
        else:
            h.update(repr(item).encode())

    visit(value)
    return h.hexdigest()


def create(initial, flag, *, scale=1, tile_rows=16):
    os.environ["ARENO_EXPERIMENT_DEFERRED_PROJECTION"] = "1"
    os.environ[FLAG] = str(int(flag))
    params = [torch.nn.Parameter(p.clone()) for p in initial]
    optimizer = GaLoreAdamW(
        params,
        lr=1e-5,
        betas=(0.9, 0.95),
        weight_decay=0.01,
        rank=8,
        update_proj_gap=2,
        scale=scale,
        projector_backend="recycled",
        projector_oversampling=4,
        projector_iterations=1,
        projector_seed=17,
        projector_final_qr=True,
        compact_master=True,
        tile_rows=tile_rows,
        release_gradients=True,
        fused_writeback=True,
        transport_moments=True,
    )
    return params, optimizer


def step(params, optimizer, gradients, clip):
    cpu_rng = torch.get_rng_state().clone()
    cuda_rng = (
        torch.cuda.get_rng_state(params[0].device).clone()
        if params[0].is_cuda
        else None
    )
    optimizer.begin_deferred_projection()
    terms = [
        (p.float() * g).sum()
        for p, g in zip(params, gradients, strict=True)
        if g is not None
    ]
    if terms:
        sum(terms).backward()
    optimizer.finish_deferred_backward()
    norm = optimizer.deferred_grad_norms()["global"]
    pending_before = [
        r["gradient"].clone() for r in optimizer._deferred_pending.values()
    ]
    optimizer.clip_deferred_gradients(norm, clip)
    pending_after = [
        r["gradient"].clone() for r in optimizer._deferred_pending.values()
    ]
    optimizer.step()
    assert not optimizer._deferred_pending and not optimizer._deferred_ready
    assert optimizer._deferred_last["deferred_barrier_versions_unchanged"] == 1
    assert optimizer._deferred_last["deferred_full_leaf_bytes_after_backward"] == 0
    exact(cpu_rng, torch.get_rng_state())
    if cuda_rng is not None:
        exact(cuda_rng, torch.cuda.get_rng_state(params[0].device))
    return norm, pending_before, pending_after


def run_case(dtype, clip, device, *, compare=True, scale=1, tile_rows=16):
    generator = torch.Generator().manual_seed(593)
    shapes = [(193, 257), (257, 193), (4, 5), (17,), ()]
    initial = [
        torch.randn(shape, generator=generator)
        .mul_(0.02)
        .to(device=device, dtype=dtype if len(shape) == 2 else torch.float32)
        for shape in shapes
    ]
    control_params, control = create(initial, False, scale=scale, tile_rows=tile_rows)
    params, candidate = (
        create(initial, True, scale=scale, tile_rows=tile_rows)
        if compare
        else (None, None)
    )
    resumed = None
    comparisons = 0
    hashes = []
    for index in range(12):
        gradients = []
        for owner, p in enumerate(control_params):
            if index == 5 or (owner == 0 and index == 3):
                gradients.append(None)
            elif index == 4:
                gradients.append(torch.zeros(p.shape, device=device))
            else:
                amplitude = 1e4 if index == 7 else 1e-8 if index == 9 else 1
                gradients.append(
                    torch.randn(p.shape, generator=generator).to(device) * amplitude
                )
        observed = step(control_params, control, gradients, clip)
        hashes.append(
            snapshot_hash(
                [control.state_dict(), [p.detach() for p in control_params], observed]
            )
        )
        if compare:
            actual = step(params, candidate, gradients, clip)
            comparisons += exact(observed, actual)
            comparisons += exact(
                [p.detach() for p in control_params], [p.detach() for p in params]
            )
            comparisons += exact(control.state_dict(), candidate.state_dict())
            comparisons += exact(
                control.state_memory_metrics(), candidate.state_memory_metrics()
            )
            if resumed is not None:
                rp, ro = resumed
                step(rp, ro, gradients, clip)
                comparisons += exact(candidate.state_dict(), ro.state_dict())
                comparisons += exact(
                    [p.detach() for p in params], [p.detach() for p in rp]
                )
            if index in (1, 6):
                stream = io.BytesIO()
                torch.save(candidate.state_dict(), stream)
                stream.seek(0)
                payload = torch.load(stream, weights_only=True)
                # Equivalent clipping implementations intentionally share v3.
                rp, ro = create(
                    [torch.zeros_like(p) for p in params],
                    not (index == 6),
                    scale=scale,
                    tile_rows=tile_rows,
                )
                ro.load_state_dict(payload)
                comparisons += exact(candidate.state_dict(), ro.state_dict())
                resumed = rp, ro
    assert control.state[control_params[0]]["projector_refreshes"] >= 4
    assert control.state[control_params[0]]["transport_count"] >= 3
    return dict(
        dtype=str(dtype),
        scale=scale,
        tile_rows=tile_rows,
        clip=clip,
        device=str(device),
        updates=12,
        tensor_bit_comparisons=comparisons,
        default_off_step_hashes=hashes,
    )


def identity_edges(device):
    # Raw FP32 bit patterns explicitly include signedzero and subnormal tails.
    bits = torch.tensor(
        [
            0,
            -2147483648,
            1,
            -2147483647,
            8388607,
            8388608,
            1065353216,
            -1082130432,
            2139095039,
            -8388609,
        ],
        dtype=torch.int32,
    )
    original = bits.view(torch.float32).to(device)
    multiplied = original.clone().mul_(1.0)
    exact(original, multiplied)
    return {
        "finite_identity_bit_comparisons": 1,
        "elements": original.numel(),
        "scope": "FP32 finite including signedzero/subnormal/minnormal/maxfinite, exact bit identity",
    }


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--default-off-only", action="store_true")
    args = parser.parse_args()
    torch.set_float32_matmul_precision("highest")
    cases = [
        run_case(
            dtype,
            1.0,
            args.device,
            compare=not args.default_off_only,
            scale=scale,
            tile_rows=tile_rows,
        )
        for dtype in (torch.float32, torch.bfloat16)
        for scale in (1, 2, True, 1e-40, 1e-300, 2**63, 2**64 - 1)
        for tile_rows in (0, 16)
    ]
    source = hashlib.sha256()
    package = Path(areno.__file__).resolve().parent
    for path in sorted(package.rglob("*.py")):
        source.update(str(path.relative_to(package.parent)).encode())
        source.update(path.read_bytes())
    result = dict(
        status="passed",
        timestamp=datetime.now(timezone.utc).isoformat(),
        source_sha256=source.hexdigest(),
        device=args.device,
        cases=cases,
        identity_edge_check=identity_edges(args.device)
        if not args.default_off_only
        else [],
        scope="Exact same-input flag0/flag1 full optimizer/model/RNG/clip with scale1/.5/2/4 tiled/untiled plus serialized continuation; not native-model quality/performance evidence.",
    )
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(
        json.dumps(
            {
                "status": result["status"],
                "device": args.device,
                "cases": len(cases),
                "tensor_bit_comparisons": sum(
                    c["tensor_bit_comparisons"] for c in cases
                ),
                "edges": result["identity_edge_check"],
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
