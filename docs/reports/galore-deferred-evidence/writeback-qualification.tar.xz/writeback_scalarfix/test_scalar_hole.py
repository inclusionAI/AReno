"""Proposed regression coverage; not installed or executed by this review."""

import pytest
import torch

from areno.engine.optim.compact_writeback import compact_writeback
from areno.engine.optim.galore import GaLoreAdamW
from areno.engine.optim.master_storage import decode_fp32_master

pytestmark = pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA required")


def assert_bits_equal(first, second):
    assert first.dtype == second.dtype and first.shape == second.shape
    assert torch.equal(
        first.contiguous().reshape(-1).view(torch.uint8),
        second.contiguous().reshape(-1).view(torch.uint8),
    )


@pytest.mark.parametrize("scale", [1, 2, 4, 0.1, 1.3, 1e-40, 1e-300, 1e300])
@pytest.mark.parametrize("offset,count", [(0, 10), (8, 1025)])
@pytest.mark.parametrize("alpha", [-0.003, 0.0])
def test_fused_scale_matches_pytorch_scalar_conversion(scale, offset, count, alpha):
    # Explicit positive and negative zero, tiny values and overflow-producing
    # updates; strided update exercises the existing contiguous-copy contract.
    words = torch.tensor(
        [0, -2147483648, 1, -2147483647, 8388607, 8388608,
         1065353216, -1082130432, 2139095039, -8388609],
        device="cuda", dtype=torch.int32,
    )
    source = words.view(torch.float32).repeat((count + 9) // 10)[:count]
    update = torch.stack([source, source], dim=1)[:, 0]
    original = torch.linspace(-0.5, 0.5, offset + count, device="cuda")
    control_model, control_storage = GaLoreAdamW._checked_encode(original)
    candidate_model, candidate_storage = GaLoreAdamW._checked_encode(original)
    control_invalid = torch.zeros((), device="cuda", dtype=torch.int32)
    candidate_invalid = torch.zeros_like(control_invalid)
    separately_scaled = update.clone().mul_(scale)
    compact_writeback(
        control_model, control_storage, separately_scaled, offset,
        0.9999, alpha, control_invalid,
    )
    compact_writeback(
        candidate_model, candidate_storage, update, offset,
        0.9999, alpha, candidate_invalid, scale=scale,
    )
    for control, candidate in (
        (control_model, candidate_model),
        (control_storage.low_bits, candidate_storage.low_bits),
        (control_storage.round_up_bits, candidate_storage.round_up_bits),
        (control_invalid, candidate_invalid),
        (decode_fp32_master(control_model, control_storage),
         decode_fp32_master(candidate_model, candidate_storage)),
    ):
        assert_bits_equal(control, candidate)
