"""One fresh process per branch for the original device nonfinite assertion."""

import argparse
import os

import torch

from check_exact import create, step

parser = argparse.ArgumentParser(__doc__)
parser.add_argument("--flag", type=int, choices=(0, 1), required=True)
args = parser.parse_args()
initial = [torch.ones((193, 257), device="cuda", dtype=torch.bfloat16)]
params, optimizer = create(initial, bool(args.flag), scale=1e300, tile_rows=16)
print({"flag": args.flag, "scalar_mul": float(torch.tensor(1.0).mul_(1e300)),
       "expected": "original compact invalid assertion after nonfinite write"}, flush=True)
step(params, optimizer, [torch.ones_like(params[0], dtype=torch.float32)], 1)
torch.cuda.synchronize()
raise AssertionError("nonfinite compact write unexpectedly accepted")
