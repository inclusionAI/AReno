"""Preserve original unsupported scalar conversion and exception behavior."""

import argparse
from fractions import Fraction
import json
from pathlib import Path

import numpy as np
import torch

from check_exact import create, exact, step


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    scalars = [2**64, 2**100, np.float32(1.3), np.float64(1.3), torch.tensor(1.3), Fraction(1, 2)]
    cases = []
    for scale in scalars:
        initial = [torch.linspace(-0.5, 0.5, 9 * 11, device="cuda").reshape(9, 11).bfloat16()]
        original_p, original = create(initial, False, scale=scale, tile_rows=16)
        fixed_p, fixed = create(initial, True, scale=scale, tile_rows=16)
        assert not fixed._fused_scale_writeback
        errors = []
        for params, optimizer in ((original_p, original), (fixed_p, fixed)):
            try:
                step(params, optimizer, [torch.ones_like(params[0], dtype=torch.float32)], 1)
            except (OverflowError, TypeError, RuntimeError) as exc:
                errors.append({"type": type(exc).__name__, "message": str(exc)})
                optimizer.abort_deferred_projection()
            else:
                errors.append(None)
        assert errors[0] == errors[1], (repr(scale), errors)
        comparisons = exact(original.state_dict(), fixed.state_dict())
        comparisons += exact(original_p, fixed_p)
        cases.append({"scale_type": type(scale).__name__, "scale_repr": repr(scale),
                      "error": errors[0], "tensor_bit_comparisons": comparisons,
                      "fusion_disabled_once_at_initialization": True})
    args.output.write_text(json.dumps({"status": "passed", "cases": cases}, indent=2) + "\n")
    print(json.dumps({"status": "passed", "cases": len(cases)}), flush=True)


if __name__ == "__main__":
    main()
